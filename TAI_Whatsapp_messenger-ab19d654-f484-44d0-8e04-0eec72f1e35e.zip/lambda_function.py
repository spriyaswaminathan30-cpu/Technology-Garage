import json
import os
import boto3
from typing import Dict, Any, Optional
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain.prompts import ChatPromptTemplate
from langchain_community.vectorstores import MongoDBAtlasVectorSearch
import openai

# Get environment variables (set by Lambda environment)
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
MONGO_URI = os.environ.get("MONGO_URI")
MONGO_DBNAME = os.environ.get("MONGO_DBNAME")
MONGO_COLLECTION = os.environ.get("MONGO_COLLECTION")
MONGO_vSEARCH = os.environ.get("MONGO_vSEARCH")
PHONE_NUMBER_ID = os.environ.get("PHONE_NUMBER_ID")

# Validate required environment variables
if not OPENAI_API_KEY:
    raise ValueError("OPENAI_API_KEY environment variable is required")
if not all([MONGO_URI, MONGO_DBNAME, MONGO_COLLECTION, MONGO_vSEARCH]):
    raise ValueError("MongoDB configuration environment variables are required")
if not PHONE_NUMBER_ID:
    raise ValueError("PHONE_NUMBER_ID environment variable is required")

# Initialize AWS Social Messaging client
social_messaging_client = boto3.client('socialmessaging')

def lambda_handler(event, context):
    """
    Main Lambda handler for processing WhatsApp messages and providing recipe responses
    """
    try:
        print("Received Event from SNS")
        print(event['Records'][0]['Sns']['Message'])
        customer_message = get_customer_message_details(event)
        
        if not customer_message:
            print("Not a customer text message")
            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Not a customer text message'})
            }
        
        print("Message received from customer")
        print(f"{customer_message}")
        # Acknowledge the message
        print(f"Sending acknowledgement......")
        await_acknowledge(customer_message)
        print(f"Acknowledgement Sent Successfully.")
        
        # Process and reply with recipe information
        await_reply_with_recipe(customer_message)
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Message processed successfully'})
        }
        
    except Exception as error:
        print(f"Error occurred while processing the request: {str(error)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Error occurred while processing the message'})
        }

def get_customer_message_details(event) -> Optional[Dict[str, Any]]:
    """
    Extract customer message details from SNS event
    """
    try:
        eum_message = json.loads(event['Records'][0]['Sns']['Message'])
        webhook_data = eum_message['whatsAppWebhookEntry']
        
        if isinstance(webhook_data, str):
            webhook_data_parsed = json.loads(webhook_data)
        else:
            webhook_data_parsed = webhook_data
        
        changes = webhook_data_parsed.get('changes', [])
        if not changes:
            return None
            
        value = changes[0].get('value', {})
        messages = value.get('messages', [])
        contacts = value.get('contacts', [])
        
        if not messages:
            print("No messages found in the webhook data")
            print(f"Webhook data: {webhook_data}")
            return None
            
        message = messages[0]
        message_text = None
        message_type = None
        button_id = None
        
        # Handle text messages
        if message.get('text'):
            message_text = message['text'].get('body')
            message_type = 'text'
        # Handle interactive button responses
        elif message.get('interactive'):
            interactive = message['interactive']
            if interactive.get('type') == 'button_reply':
                button_reply = interactive.get('button_reply', {})
                message_text = button_reply.get('title')  # Use button title as message
                message_type = 'button'
                # Store button ID for more specific handling
                button_id = button_reply.get('id')
        
        if not message_text:
            return None
            
        message_details = {
            'name': contacts[0]['profile']['name'] if contacts and contacts[0].get('profile') else None,
            'from': message.get('from'),
            'id': message.get('id'),
            'message': message_text,
            'type': message_type,
            'button_id': button_id if message_type == 'button' else None
        }
        
        return message_details if message_details['from'] else None
        
    except (KeyError, IndexError, json.JSONDecodeError) as e:
        print(f"Error parsing customer message: {str(e)}")
        return None

def await_acknowledge(customer_message: Dict[str, Any]):
    """
    Send read receipt for the customer message
    """
    meta_message = {
        'messaging_product': 'whatsapp',
        'message_id': customer_message['id'],
        'status': 'read'
    }
    send_message(meta_message)

def await_reply_with_recipe(customer_message: Dict[str, Any]):
    """
    Process customer message and reply with recipe information
    """
    message_text = customer_message.get('message', '').lower()
    message_type = customer_message.get('type', 'text')
    button_id = customer_message.get('button_id')
    
    # Check if it's a greeting (using word boundaries to avoid false matches)
    import re
    greeting_pattern = r['\b(hello|hi|hey|hiya)\b']
    if re.search(greeting_pattern, message_text, re.IGNORECASE):
        print(f"Greeting detected: {message_text}")
        react_to_message(customer_message)
        send_recipe_options(customer_message)
    elif message_type == 'button' and button_id:
        # Handle button clicks (convert to text queries for now)
        print(f"Button clicked: {button_id}, converting to text query")
        handle_button_response_as_text(customer_message, button_id)
    else:
        # Process the message as a recipe query
        print(f"Processing message as a recipe query: {message_text}")
        try:
            recipe_answer = perform_question_answering(customer_message['message'])
            send_recipe_response(customer_message, recipe_answer)
        except Exception as e:
            print(f"Error getting recipe answer: {str(e)}")
            send_error_response(customer_message)

def react_to_message(customer_message: Dict[str, Any]):
    """
    Send a wave emoji reaction to the customer message
    """
    wave_emoji = '👋'
    
    meta_message = {
        'messaging_product': 'whatsapp',
        'recipient_type': 'individual',
        'to': f"+{customer_message['from']}",
        'type': 'reaction',
        'reaction': {
            'message_id': customer_message['id'],
            'emoji': wave_emoji
        }
    }
    send_whatsapp_message(meta_message)

def send_recipe_options(customer_message: Dict[str, Any]):
    """
    Send greeting and recipe options to the customer (text-only for now)
    """
    # Send greeting text with recipe options
    greeting_message = {
        'messaging_product': 'whatsapp',
        'to': f"+{customer_message['from']}",
        'text': {
            'preview_url': False,
            'body': f"Hello {customer_message.get('name', 'there')}! I'm your recipe assistant. How can I help you with cooking today?\n\nYou can ask me about:\n• Breakfast recipes\n• Dinner recipes\n• Dessert recipes\n• Specific ingredients or dietary needs\n\nJust type what you're looking for!"
        }
    }
    send_whatsapp_message(greeting_message)

def send_recipe_options_with_buttons(customer_message: Dict[str, Any]):
    """
    Send greeting and recipe options with interactive buttons (disabled for now)
    This function is preserved for future use when display name approval is resolved
    """
    # Send greeting text
    greeting_message = {
        'messaging_product': 'whatsapp',
        'to': f"+{customer_message['from']}",
        'text': {
            'preview_url': False,
            'body': f"Hello {customer_message.get('name', 'there')}! I'm your recipe assistant. How can I help you with cooking today?"
        }
    }
    send_whatsapp_message(greeting_message)
    
    # Send interactive buttons
    interactive_message = {
        'messaging_product': 'whatsapp',
        'to': f"+{customer_message['from']}",
        'type': 'interactive',
        'interactive': {
            'type': 'button',
            'body': {
                'text': 'What would you like to cook?'
            },
            'action': {
                'buttons': [
                    {
                        'type': 'reply',
                        'reply': {
                            'id': 'RECIPE_BREAKFAST',
                            'title': 'Breakfast recipes'
                        }
                    },
                    {
                        'type': 'reply',
                        'reply': {
                            'id': 'RECIPE_DINNER',
                            'title': 'Dinner recipes'
                        }
                    },
                    {
                        'type': 'reply',
                        'reply': {
                            'id': 'RECIPE_DESSERT',
                            'title': 'Dessert recipes'
                        }
                    }
                ]
            }
        }
    }
    send_whatsapp_message(interactive_message)

def send_recipe_response(customer_message: Dict[str, Any], recipe_answer: str):
    """
    Send the recipe answer to the customer
    """
    # Truncate if too long for WhatsApp (4096 character limit)
    if len(recipe_answer) > 4000:
        recipe_answer = recipe_answer[:4000] + "...\n\nFor more details, please ask a more specific question!"
    
    meta_message = {
        'messaging_product': 'whatsapp',
        'to': f"+{customer_message['from']}",
        'text': {
            'preview_url': False,
            'body': recipe_answer
        }
    }
    send_whatsapp_message(meta_message)

def send_error_response(customer_message: Dict[str, Any]):
    """
    Send error response when recipe lookup fails
    """
    error_message = {
        'messaging_product': 'whatsapp',
        'to': f"+{customer_message['from']}",
        'text': {
            'preview_url': False,
            'body': "Sorry, I couldn't find any recipes for your request. Please try asking about specific ingredients, dietary restrictions, or meal types!"
        }
    }
    send_whatsapp_message(error_message)

def handle_button_response_as_text(customer_message: Dict[str, Any], button_id: str):
    """
    Handle interactive button responses by converting to text queries (current implementation)
    """
    print(f"Handling button response as text: {button_id}")
    
    # Map button IDs to recipe queries
    button_queries = {
        'RECIPE_BREAKFAST': 'Show me healthy breakfast recipes',
        'RECIPE_DINNER': 'Show me dinner recipes',
        'RECIPE_DESSERT': 'Show me dessert recipes'
    }
    
    query = button_queries.get(button_id)
    if query:
        try:
            recipe_answer = perform_question_answering(query)
            send_recipe_response(customer_message, recipe_answer)
        except Exception as e:
            print(f"Error getting recipe answer for button {button_id}: {str(e)}")
            send_error_response(customer_message)
    else:
        print(f"Unknown button ID: {button_id}")
        send_error_response(customer_message)

def handle_button_response(customer_message: Dict[str, Any], button_id: str):
    """
    Handle interactive button responses (preserved for future use)
    This function will be used when display name approval is resolved
    """
    print(f"Handling button response: {button_id}")
    
    # Map button IDs to recipe queries
    button_queries = {
        'RECIPE_BREAKFAST': 'Show me healthy breakfast recipes',
        'RECIPE_DINNER': 'Show me dinner recipes',
        'RECIPE_DESSERT': 'Show me dessert recipes'
    }
    
    query = button_queries.get(button_id)
    if query:
        try:
            recipe_answer = perform_question_answering(query)
            send_recipe_response(customer_message, recipe_answer)
        except Exception as e:
            print(f"Error getting recipe answer for button {button_id}: {str(e)}")
            send_error_response(customer_message)
    else:
        print(f"Unknown button ID: {button_id}")
        send_error_response(customer_message)

def send_whatsapp_message(meta_message: Dict[str, Any]):
    """
    Send WhatsApp message using AWS Social Messaging service
    """
    try:
        meta_api_version = 'v20.0'
        
        request_params = {
            'originationPhoneNumberId': PHONE_NUMBER_ID,
            'message': json.dumps(meta_message),
            'metaApiVersion': meta_api_version
        }
        
        print("Sending WhatsApp message...")
        response = social_messaging_client.send_whatsapp_message(**request_params)
        print("WhatsApp message sent successfully")
        return response
        
    except Exception as e:
        print(f"Error sending WhatsApp message: {str(e)}")
        raise

# Recipe AI Functions (from your existing code)

def food_data_prompt():
    """
    Create the prompt template for recipe queries
    """
    template = """ You are a helpful recipe assistant. You provide cooking recipes and food suggestions based on user questions.
                You have access to a comprehensive food database with recipes, ingredients, and instructions.
                
                Database contains:
                    Title: Name of the food dish
                    Ingredients: List of ingredients needed
                    Instructions: Step-by-step cooking instructions
                    Cleaned_Ingredients: Processed ingredient list

                RULES:
                1. Only provide information from the database
                2. Give clear, concise recipe suggestions
                3. Include ingredients and basic instructions when possible
                4. If multiple recipes match, provide 2-3 best options
                5. Keep responses under 4000 characters for WhatsApp compatibility
                
                EXPECTED INPUT & OUTPUT:
                INPUT: I want to bake a cake for a chocolate lover
                Expected output: <<You have to provide the recipes of all cakes having chocolate flavor>>>


                INPUT: Cook something for breakfast who is diabetic
                Expected output: <<You have to provide Recipes with all which does not have sugar>>>


                INPUT: I need healthy option for lunch which is quick to make
                Expected output: <<You have to provide Recipes which has health benefits, or helps cure of common experienced factors of obesity etc. This is wide category, so we can check the thought process w/ verbose=true>>>


                INPUT: I am allergic to nuts, what do you got for me?
                Expected output: <<You have to provide Recipes which does not have any type of nuts>>>


                INPUT: Lactose tolerance is a real thing, you got any for me?
                Expected output: <<You have to provide Any thing matching our db but does not have any mil products involved in it>>>


                INPUT: I am touring Antarctica for a few days, do you have any suggestions?
                Expected output: <<You have to provide In this case, the ingredients in the recipe should be pretty limited, and something that can be found naturally like fish and minimal effort and resources to make. You can change the place do different names to see what it suggests based on what is available in the region.>>>


                INPUT: What are the options I have if I need to make it for breakfast, lunch and dinner but cook once, keep it for all three meals?
                Expected output: <<You have to provide This should be something that does not rot easily and can be had for all 3 times a day.>>>


                INPUT: I want to surprise my girlfriend, what's the fanciest meal i can cook?
                Expected output: <<You have to provide this can be something like delicacies that looks good etc.>>>


                INPUT: I want to surprise my boyfriend, he's from southern california, what can i make which will make him feel home?
                Expected output: <<You have to provide A Southern Californian specialty food, or you can change the name to different region to match/test with the data we have.>>>


                INPUT: What is the quickest meal I can make?
                Expected output: <<You have to provide I would expect something like maggi.. but there are other things like sandwiches etc.>>>
                Context from database: {context}
                User Question: {question}
                
                Provide a helpful recipe response:
                """
    
    return ChatPromptTemplate.from_template(template)

def reading_vector_data():
    """
    Initialize MongoDB Atlas Vector Search retriever
    """
    if not all([MONGO_URI, MONGO_DBNAME, MONGO_COLLECTION, MONGO_vSEARCH]):
        raise ValueError("Missing MongoDB configuration environment variables")
    
    reading_vector_search = MongoDBAtlasVectorSearch.from_connection_string(
        MONGO_URI,
        f"{MONGO_DBNAME}.{MONGO_COLLECTION}",
        OpenAIEmbeddings(disallowed_special=()),
        index_name=MONGO_vSEARCH,
    )
    
    return reading_vector_search.as_retriever()

def format_docs(docs):
    """
    Format retrieved documents for the prompt
    """
    return "\n\n".join(doc.page_content for doc in docs)

def perform_question_answering(question: str) -> str:
    """
    Simple OpenAI-based question answering for recipe queries
    """
    try:
        client = openai.OpenAI(api_key=OPENAI_API_KEY)
        
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a helpful recipe assistant. Provide cooking recipes and food suggestions based on user questions. Keep responses under 4000 characters."},
                {"role": "user", "content": question}
            ],
            temperature=0.1,
            max_tokens=1000
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        print(f"Error in question answering: {str(e)}")
        raise