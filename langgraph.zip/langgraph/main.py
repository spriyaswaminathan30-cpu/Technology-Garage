# main.py
import logging
from langgraph.graph import StateGraph
from langchain_core.runnables import RunnableLambda
from typing import TypedDict
from agents import llm, weather_api, get_latest_news, get_tourist_info

# Setup logging
logging.basicConfig(level=logging.INFO)

# --- Define the structure of data that flows between agents ---
class AgentState(TypedDict):
    query: str
    weather_info: str
    news_info: str
    tourist_info: str

# --- Agent 1: Weather ---
def weather_agent(state):
    city = state["query"]
    logging.info(f"Fetching weather for {city}...")
    weather = weather_api.run(city)
    return {"weather_info": weather}

# --- Agent 2: News ---
def news_agent(state):
    city = state["query"]
    logging.info(f"Fetching news for {city}...")
    news_list = get_latest_news(city)
    return {"news_info": "\n".join(news_list)}

# --- Agent 3: Tourist Info ---
def tourist_agent(state):
    city = state["query"]
    logging.info(f"Fetching tourist attractions for {city}...")
    result = get_tourist_info(city)
    return {"tourist_info": result}

# --- Build LangGraph flow ---
graph = StateGraph(AgentState)

# Add agents as nodes
graph.add_node("Weather Agent", RunnableLambda(weather_agent))
graph.add_node("News Agent", RunnableLambda(news_agent))
graph.add_node("Tourist Agent", RunnableLambda(tourist_agent))

# Define execution order
graph.add_edge("Weather Agent", "News Agent")
graph.add_edge("News Agent", "Tourist Agent")

# Define start and end
graph.set_entry_point("Weather Agent")
graph.set_finish_point("Tourist Agent")

# Compile the graph into a runnable app
app = graph.compile()

# --- Run it ---
if __name__ == "__main__":
    query = input("Enter city name: ").strip() or "Chennai"
    logging.info(f"Running LangGraph for {query}")

    result = app.invoke({"query": query})

    print("\n===== AGENT RESPONSES =====")
    print(f"🌦 Weather Info:\n{result.get('weather_info')}")
    print(f"\n🗞 News Info:\n{result.get('news_info')}")
    print(f"\n🗺 Tourist Info:\n{result.get('tourist_info')}")
