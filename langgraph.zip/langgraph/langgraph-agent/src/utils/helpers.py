def make_api_call(url, params=None):
    import requests
    response = requests.get(url, params=params)
    response.raise_for_status()
    return response.json()

def parse_response(response):
    if isinstance(response, dict) and 'data' in response:
        return response['data']
    return response