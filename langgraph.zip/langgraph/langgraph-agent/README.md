# LangGraph Agent Project

## Overview
The LangGraph Agent project consists of two main agents: the Brand Analysis Agent and the Product Retrieval Agent. These agents are designed to assist in gathering marketing analysis and product information for specified brands.

## Agents

### Brand Analysis Agent
- **File**: `src/brand_analysis_agent.py`
- **Description**: This agent retrieves the top brand marketing analysis.
- **Key Methods**:
  - `fetch_analysis`: Gathers data related to brand marketing.
  - `process_analysis`: Formats the results for easier interpretation.

### Product Retrieval Agent
- **File**: `src/product_retrieval_agent.py`
- **Description**: This agent retrieves products associated with a specified brand.
- **Key Methods**:
  - `fetch_products`: Collects product data for the brand.
  - `filter_products`: Refines the product list based on specific criteria.

## Utilities
- **File**: `src/utils/helpers.py`
- **Description**: Contains utility functions that support both agents.
- **Key Functions**:
  - `make_api_call`: Handles API requests.
  - `parse_response`: Processes the responses from API calls.

## Requirements
- **File**: `requirements.txt`
- **Description**: Lists the dependencies required for the project, including libraries such as `requests`.

## Setup Instructions
1. Clone the repository to your local machine.
2. Navigate to the project directory.
3. Install the required dependencies using:
   ```
   pip install -r requirements.txt
   ```

## Usage Examples
- To use the Brand Analysis Agent, instantiate the `BrandAnalysisAgent` class and call the `fetch_analysis` method.
- To use the Product Retrieval Agent, instantiate the `ProductRetrievalAgent` class and call the `fetch_products` method.

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.