# agents.py
import os
import requests
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_community.utilities.openweathermap import OpenWeatherMapAPIWrapper

# --- Load environment variables ---
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), ".env"))

# ✅ Check if key exists
openai_key = os.getenv("OPENAI_API_KEY")
if not openai_key:
    raise ValueError("❌ OPENAI_API_KEY not found in .env file!")

# --- Initialize OpenAI LLM (used by tourist/news agents) ---
llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0,
    api_key=openai_key
)

# --- Initialize Weather API ---
weather_api = OpenWeatherMapAPIWrapper(
    openweathermap_api_key=os.getenv("OPENWEATHER_API_KEY")
)

# --- Function to get latest news ---
def get_latest_news(city):
    """Fetch top 3 news headlines for a city."""
    api_key = os.getenv("NEWSAPI_KEY")
    url = f"https://newsapi.org/v2/everything?q={city}&pageSize=3&apiKey={api_key}"
    response = requests.get(url)
    data = response.json()
    if "articles" in data:
        return [article["title"] for article in data["articles"][:3]]
    else:
        return ["No news found."]

# --- Function to get tourist information using LLM ---
def get_tourist_info(city):
    """Fetch top 3 tourist attractions for a city using OpenAI."""
    result = llm.invoke(f"List top 3 tourist attractions in {city}.")
    return result.content
