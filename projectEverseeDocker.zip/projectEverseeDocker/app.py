import cv2
import os
from pymongo import MongoClient
import boto3
import ollama

# -------- SETTINGS --------
videos = [
    {"path": "/tmp/v1.mp4", "camera_id": "CAM1"},
    {"path": "/tmp/v2.mp4", "camera_id": "CAM2"}
]
output_dir = "/tmp/frames"
model = "moondream:1.8b"
target_fps = 10  # frames per second

# -------- AWS S3 Settings --------
S3_BUCKET = os.getenv("S3_BUCKET", "your-s3-bucket")
s3_client = boto3.client("s3")

# -------- MongoDB Connection --------
MONGO_URI = os.getenv("MONGO_URI", "your-mongo-uri")
client = MongoClient(MONGO_URI)
db = client["project_eversee"]
collection = db["video_frame_analysis"]

os.makedirs(output_dir, exist_ok=True)

# -------- Suspicious keywords --------
SUSPICIOUS_KEYWORDS = [
    "cross the billing counter without paying",
    "cross the billing counter by holding the object"
]

# --------------------------
# Helper: upload file to S3
# --------------------------
def upload_to_s3(file_path, s3_key):
    s3_client.upload_file(file_path, S3_BUCKET, s3_key)
    return f"https://{S3_BUCKET}.s3.amazonaws.com/{s3_key}"

# --------------------------
# Helper: save video snippet around suspicious frame
# --------------------------
def save_video_snippet(video_path, start_frame, end_frame, output_path):
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
    for f in range(start_frame, end_frame + 1):
        ret, frame = cap.read()
        if not ret:
            break
        out.write(frame)

    cap.release()
    out.release()

# --------------------------
# Function to handle one video
# --------------------------
def process_video(video_path, camera_id):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"❌ Cannot open video {video_path}")
        return

    video_fps = cap.get(cv2.CAP_PROP_FPS)
    frame_skip = max(int(video_fps / target_fps), 1)
    frame_count = 0
    saved_frames = []

    # Extract frames
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if frame_count % frame_skip == 0:
            frame_path = os.path.join(output_dir, f"{camera_id}_frame_{frame_count}.jpg")
            cv2.imwrite(frame_path, frame)
            saved_frames.append(frame_path)
        frame_count += 1

    cap.release()
    print(f"✅ [{camera_id}] Extracted {len(saved_frames)} frames")

    # Analyze frames
    for i, frame_path in enumerate(saved_frames):
        with open(frame_path, "rb") as f:
            image_bytes = f.read()

        prompt = f"""
You are a vigilant supermarket CCTV security assistant analyzing {camera_id}, frame {i}.

Rules:
- Respond ONLY in plain English sentences.
- Do NOT return numbers, coordinates, arrays, or JSON.
- Describe only what you SEE in the image.
- If you see someone crossing the billing counter without paying:
   * Describe the person (gender, age range, clothing colors, accessories, hair, etc.)
   * Describe their action clearly in words (walking, running, holding an object, etc.)
- If nothing suspicious is happening, simply respond with:
   "No suspicious activity detected"
"""

        try:
            response = ollama.chat(
                model=model,
                messages=[
                    {"role": "system", "content": "You are a vigilant supermarket security assistant."},
                    {"role": "user", "content": prompt, "images": [image_bytes]}
                ],
                stream=False
            )
            raw_content = response.get("message", {}).get("content", "No response")
        except Exception as e:
            raw_content = f"Error contacting model: {e}"

        # Save document in MongoDB
        doc = {
            "camera_id": camera_id,
            "frame_number": i,
            "frame_path": frame_path,
            "analysis": raw_content,
            "suspicious_activity": False
        }
        collection.insert_one(doc)

        # If suspicious, capture screenshot + snippet
        if any(keyword in raw_content.lower() for keyword in SUSPICIOUS_KEYWORDS):
            print("=" * 50)
            print(f"[ALERT - {camera_id}] Frame {i} - {frame_path}")
            print(f"Suspicious Activity: {raw_content}")
            print("=" * 50)

            # Upload Screenshot
            screenshot_key = f"{camera_id}/screenshots/frame_{i}.jpg"
            screenshot_url = upload_to_s3(frame_path, screenshot_key)

            # Create Video Snippet
            snippet_path = os.path.join(output_dir, f"{camera_id}_suspicious_clip_{i}.mp4")
            snippet_duration = 5  # seconds
            snippet_start = max(i * frame_skip - int(video_fps * (snippet_duration // 2)), 0)
            snippet_end = min(i * frame_skip + int(video_fps * (snippet_duration // 2)),
                              int(cap.get(cv2.CAP_PROP_FRAME_COUNT)))
            save_video_snippet(video_path, snippet_start, snippet_end, snippet_path)

            # Upload Snippet
            snippet_key = f"{camera_id}/snippets/clip_{i}.mp4"
            snippet_url = upload_to_s3(snippet_path, snippet_key)

            # Update MongoDB
            collection.update_one(
                {"camera_id": camera_id, "frame_number": i},
                {"$set": {
                    "suspicious_activity": True,
                    "suspicious_screenshot_url": screenshot_url,
                    "suspicious_clip_url": snippet_url
                }}
            )

    print(f"✅ [{camera_id}] Analysis complete. Data saved to MongoDB.")

# --------------------------
# Entrypoint
# --------------------------
if __name__ == "__main__":
    for vid in videos:
        process_video(vid["path"], vid["camera_id"])
    print("🎉 All video analyses complete and stored in MongoDB with S3 evidence links.")
