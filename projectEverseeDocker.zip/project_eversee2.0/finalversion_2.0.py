# # ============================================================
# #  AI CCTV FACE SECURITY SYSTEM
# #  - MongoDB storage for persons, access status, events
# #  - Local folder storage for face images (path in MongoDB)
# #  - Real-time face detection with block alerting
# #  - Clean camera display with full-frame coverage
# # ============================================================

# from __future__ import annotations

# import cv2
# import time
# import uuid
# import math
# import threading
# import datetime
# import numpy as np
# import face_recognition

# from pathlib import Path
# from dataclasses import dataclass, field
# from typing import List, Optional, Tuple

# # ── MongoDB ──────────────────────────────────────────────────
# from pymongo import MongoClient
# from pymongo.collection import Collection

# # ============================================================
# # CONFIG  (edit these to match your environment)
# # ============================================================

# # Camera – use 0 for laptop webcam, or an RTSP URL string
# CAMERA_SOURCES: list = [
#     0, "rtsp://admin:EduServices%2301@192.168.29.100:554/cam/realmonitor?channel=1&subtype=0",
#     1, "rtsp://admin:EduServices%2301@192.168.29.100:554/cam/realmonitor?channel=1&subtype=1"                         # webcam
#     ]

# # MongoDB
# MONGO_URI      = "mongodb+srv://tgdev:technology-1@cluster0.0pefygc.mongodb.net/"
# DB_NAME        = "project_eversee"

# # Local folder where face-crop images are saved
# FACES_DIR      = Path("faces")          # relative to cwd

# # Detection
# FACE_MODEL          = "hog"             # "hog" = CPU-fast, "cnn" = GPU-accurate
# FACE_MATCH_THRESHOLD = 0.50             # lower = stricter match
# MIN_FACE_PX         = 40               # ignore faces smaller than this (px)
# PROCESS_EVERY_N     = 3                # process 1 out of every N frames (speed)

# # Tracking
# TRACK_MAX_DIST   = 120   # pixels – how far a face can move between frames
# TRACK_LOST_MAX   = 25    # frames before a track is dropped

# # Alert
# ALERT_COOLDOWN   = 10    # seconds between repeated alerts for the same person

# # ============================================================
# # BOOTSTRAP
# # ============================================================

# FACES_DIR.mkdir(parents=True, exist_ok=True)

# # ── MongoDB collections ──────────────────────────────────────
# _client = MongoClient(MONGO_URI)
# _db     = _client[DB_NAME]

# persons_col : Collection = _db["persons"]   # one doc per unique face
# events_col  : Collection = _db["events"]    # every detection / alert event

# # Indexes for fast look-up
# persons_col.create_index("person_id", unique=True)
# events_col.create_index("person_id")
# events_col.create_index("timestamp")

# print(f"[DB] Connected to MongoDB  db={DB_NAME}")

# # ============================================================
# # DATABASE HELPERS
# # ============================================================

# def get_person(person_id: str) -> Optional[dict]:
#     """Return the person document or None."""
#     return persons_col.find_one({"person_id": person_id}, {"_id": 0})


# def get_all_known() -> List[dict]:
#     """
#     Return every person with a stored face encoding.
#     Each item:  { person_id, name, status, encoding (list[float]) }
#     """
#     return list(persons_col.find(
#         {"encoding": {"$exists": True}},
#         {"_id": 0, "person_id": 1, "name": 1, "status": 1, "encoding": 1}
#     ))


# def create_person(person_id: str, name: str, encoding: list,
#                   face_image_path: str) -> None:
#     """Insert a brand-new person into MongoDB."""
#     doc = {
#         "person_id"       : person_id,
#         "name"            : name,
#         "status"          : "allow",          # default – change via update_status()
#         "encoding"        : encoding,          # list[float] – face_recognition vector
#         "face_image_path" : face_image_path,   # LOCAL path, e.g. "faces/Person-abc.jpg"
#         "created_at"      : datetime.datetime.utcnow(),
#         "last_seen"       : datetime.datetime.utcnow(),
#     }
#     persons_col.insert_one(doc)


# def update_last_seen(person_id: str) -> None:
#     persons_col.update_one(
#         {"person_id": person_id},
#         {"$set": {"last_seen": datetime.datetime.utcnow()}}
#     )


# def update_status(person_id: str, status: str) -> None:
#     """
#     Manually call this (or via a separate admin script) to block/allow.
#     status: "allow" | "blocked"
#     """
#     persons_col.update_one(
#         {"person_id": person_id},
#         {"$set": {"status": status, "updated_at": datetime.datetime.utcnow()}}
#     )


# def log_event(person_id: str, name: str, event: str, detail: str = "") -> None:
#     """Append one event record to the events collection."""
#     events_col.insert_one({
#         "person_id" : person_id,
#         "name"      : name,
#         "event"     : event,       # "detected" | "new_person" | "blocked_alert"
#         "detail"    : detail,
#         "timestamp" : datetime.datetime.utcnow(),
#     })


# # ============================================================
# # FACE IMAGE  –  save crop locally, return path string
# # ============================================================

# def save_face_crop(frame: np.ndarray, location: tuple,
#                    name: str, person_id: str) -> Optional[str]:
#     """
#     Crop the face region from `frame`, save to FACES_DIR.
#     Returns the relative path string (stored in MongoDB) or None on failure.

#     WHY a path string?
#     ------------------
#     Storing the raw image bytes in MongoDB is wasteful for large images.
#     Instead we save the file locally and store only the path.
#     To retrieve the image for a person doc, use:
#         Path(doc["face_image_path"])   →   open / display the file
#     """
#     top, right, bottom, left = location
#     pad  = 25
#     h, w = frame.shape[:2]

#     top    = max(0, top    - pad)
#     left   = max(0, left   - pad)
#     bottom = min(h, bottom + pad)
#     right  = min(w, right  + pad)

#     crop = frame[top:bottom, left:right]

#     if crop.size == 0 or crop.shape[0] < MIN_FACE_PX or crop.shape[1] < MIN_FACE_PX:
#         return None

#     filename = f"{name}_{person_id[:8]}.jpg"
#     filepath = FACES_DIR / filename
#     cv2.imwrite(str(filepath), crop)

#     # Return relative path string  (e.g. "faces/Person-abc12345.jpg")
#     return str(filepath)


# # ============================================================
# # FACE RECOGNIZER
# # ============================================================

# class Recognizer:
#     """Wraps face_recognition library calls."""

#     def detect_faces(self, rgb: np.ndarray) -> List[dict]:
#         """
#         Detect faces and compute encodings in one shot.
#         Returns list of  { location: (top,right,bottom,left), encoding: ndarray }
#         """
#         locations = face_recognition.face_locations(rgb, model=FACE_MODEL)

#         # Filter too-small faces
#         h, w = rgb.shape[:2]
#         valid_locs = []
#         for loc in locations:
#             top, right, bottom, left = loc
#             fw = right - left
#             fh = bottom - top
#             if fw >= MIN_FACE_PX and fh >= MIN_FACE_PX:
#                 if top >= 0 and left >= 0 and right <= w and bottom <= h:
#                     valid_locs.append(loc)

#         if not valid_locs:
#             return []

#         encodings = face_recognition.face_encodings(rgb, valid_locs)
#         return [{"location": l, "encoding": e}
#                 for l, e in zip(valid_locs, encodings)]

#     def best_match(self, encoding: np.ndarray,
#                    known: List[dict]) -> Optional[dict]:
#         """
#         Compare `encoding` against known persons.
#         Returns the best-matching person dict or None.

#         HOW MATCHING WORKS
#         ------------------
#         face_distance() returns a float [0..1] for each known face.
#         0 = identical twin,  1 = completely different.
#         We return the person whose distance is smallest AND below the threshold.
#         """
#         if not known:
#             return None

#         known_encs  = [np.array(p["encoding"]) for p in known]
#         distances   = face_recognition.face_distance(known_encs, encoding)
#         best_idx    = int(np.argmin(distances))
#         best_dist   = float(distances[best_idx])

#         if best_dist <= FACE_MATCH_THRESHOLD:
#             return known[best_idx]
#         return None


# # ============================================================
# # TRACK  (one per visible face)
# # ============================================================

# @dataclass
# class Track:
#     person_id   : str
#     name        : str
#     center      : Tuple[float, float]
#     lost_frames : int = 0
#     last_alert  : float = field(default_factory=lambda: 0.0)


# # ============================================================
# # CAMERA WORKER  (one thread per camera)
# # ============================================================

# class CameraWorker(threading.Thread):

#     def __init__(self, source, app_state):
#         super().__init__(daemon=True)
#         self.source      = source
#         self.app_state   = app_state
#         self._stop       = threading.Event()
#         self.recognizer  = Recognizer()
#         self.tracks      : List[Track] = []
#         self.frame_count = 0

#     # ── open / reopen camera ─────────────────────────────────

#     def _open(self):
#         if isinstance(self.source, int):
#             cap = cv2.VideoCapture(self.source)
#         else:
#             cap = cv2.VideoCapture(self.source, cv2.CAP_FFMPEG)
#             cap.set(cv2.CAP_PROP_BUFFERSIZE, 2)

#         if cap.isOpened():
#             w   = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
#             h   = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
#             fps = cap.get(cv2.CAP_PROP_FPS)
#             print(f"[CAMERA] {self.source}  {w}x{h}  {fps:.1f}fps")
#         return cap

#     # ── track matching by centroid distance ──────────────────

#     @staticmethod
#     def _centroid(location):
#         top, right, bottom, left = location
#         return ((left + right) / 2, (top + bottom) / 2)

#     def _find_track(self, center) -> Optional[int]:
#         best_i, best_d = None, float("inf")
#         for i, t in enumerate(self.tracks):
#             d = math.hypot(center[0] - t.center[0],
#                            center[1] - t.center[1])
#             if d < TRACK_MAX_DIST and d < best_d:
#                 best_i, best_d = i, d
#         return best_i

#     # ── alert for blocked face ────────────────────────────────

#     @staticmethod
#     def _alert(track: Track):
#         now = time.time()
#         if now - track.last_alert >= ALERT_COOLDOWN:
#             track.last_alert = now
#             print(f"\n{'!'*60}")
#             print(f"  ⚠  BLOCKED PERSON DETECTED:  {track.name}")
#             print(f"  ID : {track.person_id}")
#             print(f"  At : {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
#             print(f"{'!'*60}\n")
#             log_event(track.person_id, track.name,
#                       "blocked_alert",
#                       f"Blocked person seen at {datetime.datetime.utcnow().isoformat()}")

#     # ── draw bounding box + label on frame ───────────────────

#     @staticmethod
#     def _draw(frame, location, name, status):
#         top, right, bottom, left = location
#         color  = (0, 255, 0) if status == "allow" else (0, 0, 255)
#         label  = f"{name}  [{status.upper()}]"

#         # Rectangle
#         cv2.rectangle(frame, (left, top), (right, bottom), color, 2)

#         # Label background
#         (tw, th), _ = cv2.getTextSize(
#             label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
#         cv2.rectangle(frame,
#                       (left, top - th - 10),
#                       (left + tw + 4, top),
#                       color, -1)

#         # Label text
#         cv2.putText(frame, label,
#                     (left + 2, top - 5),
#                     cv2.FONT_HERSHEY_SIMPLEX,
#                     0.55, (255, 255, 255), 1, cv2.LINE_AA)

#     # ── main thread loop ──────────────────────────────────────

#     def run(self):
#         cap = self._open()
#         if not cap.isOpened():
#             print(f"[ERROR] Cannot open camera: {self.source}")
#             return

#         while not self._stop.is_set() and not self.app_state.should_stop():

#             ok, frame = cap.read()

#             # ── reconnect on stream failure ───────────────────
#             if not ok or frame is None:
#                 print(f"[WARN] Stream lost – reconnecting {self.source}")
#                 cap.release()
#                 time.sleep(2)
#                 cap = self._open()
#                 continue

#             self.frame_count += 1

#             # ── skip frames for speed ─────────────────────────
#             if self.frame_count % PROCESS_EVERY_N != 0:
#                 # Still push last annotated frame so display stays smooth
#                 self.app_state.set_frame(self.source, frame)
#                 continue

#             # ── detection ─────────────────────────────────────
#             try:
#                 rgb   = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
#                 faces = self.recognizer.detect_faces(rgb)

#                 # Refresh known-persons list each processing cycle
#                 known_persons = get_all_known()

#                 matched_track_indices = set()

#                 for face in faces:
#                     location = face["location"]
#                     encoding = face["encoding"]
#                     center   = self._centroid(location)

#                     # ── find or create track ──────────────────
#                     t_idx = self._find_track(center)

#                     if t_idx is not None:
#                         # Existing track – just update position
#                         track = self.tracks[t_idx]
#                         track.center      = center
#                         track.lost_frames = 0
#                         matched_track_indices.add(t_idx)
#                         person_id = track.person_id
#                         name      = track.name

#                     else:
#                         # New track – try to match against DB
#                         match = self.recognizer.best_match(encoding, known_persons)

#                         if match:
#                             # ── KNOWN person ──────────────────
#                             person_id = match["person_id"]
#                             name      = match["name"]
#                             update_last_seen(person_id)
#                             log_event(person_id, name, "detected")

#                         else:
#                             # ── NEW person – register in MongoDB ──
#                             person_id = str(uuid.uuid4())
#                             name      = f"Person-{person_id[:8]}"

#                             face_path = save_face_crop(
#                                 frame, location, name, person_id)

#                             if face_path is None:
#                                 continue   # crop too small – skip

#                             create_person(
#                                 person_id  = person_id,
#                                 name       = name,
#                                 encoding   = encoding.tolist(),
#                                 face_image_path = face_path,
#                             )
#                             log_event(person_id, name, "new_person",
#                                       f"Image saved: {face_path}")
#                             print(f"[NEW] Registered {name}  img={face_path}")

#                         # Build new Track object
#                         new_track = Track(
#                             person_id = person_id,
#                             name      = name,
#                             center    = center,
#                         )
#                         self.tracks.append(new_track)
#                         matched_track_indices.add(len(self.tracks) - 1)
#                         track = new_track

#                     # ── check status & alert if blocked ───────
#                     person_doc = get_person(person_id)
#                     status     = person_doc.get("status", "allow") if person_doc else "allow"

#                     if status == "blocked":
#                         self._alert(track)

#                     # ── draw box on frame ─────────────────────
#                     self._draw(frame, location, name, status)

#                 # ── age-out lost tracks ───────────────────────
#                 for i, t in enumerate(self.tracks):
#                     if i not in matched_track_indices:
#                         t.lost_frames += 1

#                 self.tracks = [t for t in self.tracks
#                                if t.lost_frames < TRACK_LOST_MAX]

#             except Exception as exc:
#                 print(f"[ERROR] Detection loop: {exc}")

#             # Push annotated frame for display
#             self.app_state.set_frame(self.source, frame)

#         cap.release()

#     def stop(self):
#         self._stop.set()


# # ============================================================
# # SHARED APP STATE
# # ============================================================

# class AppState:

#     def __init__(self):
#         self._frames : dict = {}
#         self._lock   = threading.Lock()
#         self._stop   = threading.Event()

#     def set_frame(self, source, frame: np.ndarray):
#         with self._lock:
#             self._frames[str(source)] = frame.copy()

#     def get_frames(self) -> dict:
#         with self._lock:
#             return {k: v.copy() for k, v in self._frames.items()}

#     def stop(self):
#         self._stop.set()

#     def should_stop(self) -> bool:
#         return self._stop.is_set()


# # ============================================================
# # MAIN
# # ============================================================

# def main():
#     print("\n" + "=" * 58)
#     print("   AI CCTV FACE SECURITY SYSTEM  (MongoDB Edition)")
#     print("=" * 58)
#     print(f"  Cameras  : {CAMERA_SOURCES}")
#     print(f"  DB       : {MONGO_URI}  /  {DB_NAME}")
#     print(f"  Faces dir: {FACES_DIR.resolve()}")
#     print(f"  Model    : {FACE_MODEL}   threshold={FACE_MATCH_THRESHOLD}")
#     print("=" * 58)
#     print("  Press  Q  or  ESC  to quit")
#     print("=" * 58 + "\n")

#     state   = AppState()
#     workers = []

#     for src in CAMERA_SOURCES:
#         w = CameraWorker(src, state)
#         w.start()
#         workers.append(w)

#     try:
#         while not state.should_stop():
#             frames = state.get_frames()

#             for src, frame in frames.items():
#                 win_title = f"CCTV  |  {src}"
#                 cv2.namedWindow(win_title, cv2.WINDOW_NORMAL)   # resizable window
#                 cv2.imshow(win_title, frame)

#             key = cv2.waitKey(1) & 0xFF
#             if key in (ord("q"), ord("Q"), 27):    # Q or ESC
#                 state.stop()

#             time.sleep(0.01)

#     except KeyboardInterrupt:
#         state.stop()

#     finally:
#         for w in workers:
#             w.stop()
#         for w in workers:
#             w.join(timeout=3)
#         cv2.destroyAllWindows()
#         _client.close()
#         print("\n[SYSTEM] Stopped.\n")


# if __name__ == "__main__":
#     main()

# ============================================================
#  AI CCTV FACE SECURITY SYSTEM  —  v2  (False-Positive Fix)
#  ─────────────────────────────────────────────────────────
#  Changes from v1:
#   [FIX-1]  number_of_times_to_upsample=0  → stricter HOG
#   [FIX-2]  Aspect-ratio filter  (0.6 – 1.5)
#   [FIX-3]  Hard minimum face size  60 × 60 px
#   [FIX-4]  Facial-landmark sanity check  (eyes + nose + mouth)
#   [FIX-5]  Tighter match threshold  0.45
#   KEEP     MongoDB storage, local face-image folder, block alert
# ============================================================

from __future__ import annotations

import cv2
import time
import uuid
import math
import threading
import datetime
import numpy as np
import face_recognition

from pathlib import Path
from dataclasses import dataclass, field
from typing   import List, Optional, Tuple

from pymongo             import MongoClient
from pymongo.collection  import Collection

# ============================================================
#  CONFIG  ← edit to match your environment
# ============================================================

# Camera: 0 = laptop/USB webcam   or   "rtsp://user:pass@ip:554/..."
CAMERA_SOURCES: list = [
    "rtsp://admin:EduServices%2301@192.168.29.100:554/cam/realmonitor?channel=1&subtype=0",
    # "rtsp://admin:EduServices%2301@192.168.29.100:554/cam/realmonitor?channel=1&subtype=1"                         # webcam
    ]

# MongoDB
MONGO_URI      = "mongodb+srv://tgdev:technology-1@cluster0.0pefygc.mongodb.net/"
DB_NAME        = "project_eversee"

# Local folder for face-crop images
FACES_DIR = Path("faces")

# ── Detection ────────────────────────────────────────────────
FACE_MODEL           = "hog"    # "hog" = CPU-fast  |  "cnn" = GPU-accurate
FACE_MATCH_THRESHOLD = 0.45     # [FIX-5] tighter than original 0.50

# [FIX-3] hard minimum: anything smaller is rejected outright
MIN_FACE_PX   = 60              # minimum width AND height in pixels

# [FIX-2] aspect ratio limits: real faces are nearly square
ASPECT_MIN    = 0.6             # width/height lower bound
ASPECT_MAX    = 1.5             # width/height upper bound

# How many frames to skip between full detections (keeps CPU low)
PROCESS_EVERY_N = 3

# ── Tracking ─────────────────────────────────────────────────
TRACK_MAX_DIST = 120   # pixels – centroid movement allowed per cycle
TRACK_LOST_MAX = 25    # frames before a track is removed

# ── Alert ────────────────────────────────────────────────────
ALERT_COOLDOWN = 10    # seconds between repeated blocked-face alerts

# ============================================================
#  BOOTSTRAP
# ============================================================

FACES_DIR.mkdir(parents=True, exist_ok=True)

_client     = MongoClient(MONGO_URI)
_db         = _client[DB_NAME]
persons_col : Collection = _db["persons"]
events_col  : Collection = _db["events"]

persons_col.create_index("person_id", unique=True)
events_col.create_index("person_id")
events_col.create_index("timestamp")

print(f"[DB] Connected → {MONGO_URI}  db={DB_NAME}")

# ============================================================
#  DATABASE HELPERS
# ============================================================

def get_person(person_id: str) -> Optional[dict]:
    """Return person document or None."""
    return persons_col.find_one({"person_id": person_id}, {"_id": 0})


def get_all_known() -> List[dict]:
    """
    Return all persons that have a stored encoding.
    Used each cycle to compare new detections against.
    """
    return list(persons_col.find(
        {"encoding": {"$exists": True}},
        {"_id": 0, "person_id": 1, "name": 1, "status": 1, "encoding": 1}
    ))


def create_person(person_id: str, name: str,
                  encoding: list, face_image_path: str) -> None:
    """
    Insert a new person document into MongoDB.

    face_image_path is a LOCAL path string like  "faces/Person-abc.jpg".
    The image lives on disk; MongoDB stores only the path.
    To find which image belongs to a document:
        doc = persons_col.find_one({"person_id": <id>})
        image = cv2.imread(doc["face_image_path"])
    """
    persons_col.insert_one({
        "person_id"       : person_id,
        "name"            : name,
        "status"          : "allow",       # change with admin.py block <id>
        "encoding"        : encoding,      # 128-float face vector
        "face_image_path" : face_image_path,
        "created_at"      : datetime.datetime.utcnow(),
        "last_seen"       : datetime.datetime.utcnow(),
    })


def update_last_seen(person_id: str) -> None:
    persons_col.update_one(
        {"person_id": person_id},
        {"$set": {"last_seen": datetime.datetime.utcnow()}}
    )


def log_event(person_id: str, name: str,
              event: str, detail: str = "") -> None:
    """
    Write one event to the events collection.
    event values: "new_person" | "detected" | "blocked_alert"
    """
    events_col.insert_one({
        "person_id" : person_id,
        "name"      : name,
        "event"     : event,
        "detail"    : detail,
        "timestamp" : datetime.datetime.utcnow(),
    })


# ============================================================
#  FACE IMAGE  –  save crop to disk, return path string
# ============================================================

def save_face_crop(frame: np.ndarray, location: tuple,
                   name: str, person_id: str) -> Optional[str]:
    """
    Crop the face bounding box from `frame` with padding,
    write it as a JPEG in FACES_DIR, return the path string.
    Returns None if the crop is too small to be useful.
    """
    top, right, bottom, left = location
    pad  = 25
    h, w = frame.shape[:2]

    top    = max(0, top    - pad)
    left   = max(0, left   - pad)
    bottom = min(h, bottom + pad)
    right  = min(w, right  + pad)

    crop = frame[top:bottom, left:right]

    if (crop.size == 0
            or crop.shape[0] < MIN_FACE_PX
            or crop.shape[1] < MIN_FACE_PX):
        return None

    filename = f"{name}_{person_id[:8]}.jpg"
    filepath = FACES_DIR / filename
    cv2.imwrite(str(filepath), crop)

    # e.g.  "faces/Person-abc12345.jpg"
    return str(filepath)


# ============================================================
#  RECOGNIZER  –  all face_recognition calls live here
# ============================================================

class Recognizer:

    # ── detect + encode ──────────────────────────────────────

    def detect_faces(self, rgb: np.ndarray) -> List[dict]:
        """
        Run HOG/CNN detection on `rgb`, apply all false-positive
        filters, compute encodings for survivors.

        FILTER PIPELINE
        ───────────────
        1. number_of_times_to_upsample=0   [FIX-1]
           Skips the image-upsampling step that caused decorative
           patterns and textures to register as faces.

        2. Minimum size 60×60 px           [FIX-3]
           Patterns rarely produce detections larger than 60 px.
           Real human faces at normal CCTV distance are 80 px+.

        3. Aspect ratio 0.6 – 1.5          [FIX-2]
           A human face is roughly square (ratio ≈ 0.8–1.1).
           Patterns often produce thin horizontal or tall vertical
           boxes that fall outside this window.

        4. Landmark check                  [FIX-4]
           Requires left_eye, right_eye, nose_tip, top_lip.
           face_recognition.face_landmarks() cannot find these on
           a wall pattern, so false positives are eliminated here.
        """
        # ── Step 1: raw detection with no upsampling ─────────
        locations = face_recognition.face_locations(
            rgb,
            model=FACE_MODEL,
            number_of_times_to_upsample=0   # [FIX-1]
        )

        if not locations:
            return []

        h_img, w_img = rgb.shape[:2]
        size_filtered = []

        for loc in locations:
            top, right, bottom, left = loc
            fw = right - left
            fh = bottom - top

            # ── Step 2: minimum size ─────────────────────────
            if fw < MIN_FACE_PX or fh < MIN_FACE_PX:          # [FIX-3]
                continue

            # ── Step 3: aspect ratio ─────────────────────────
            aspect = fw / fh
            if aspect < ASPECT_MIN or aspect > ASPECT_MAX:    # [FIX-2]
                continue

            # ── bounds guard ─────────────────────────────────
            if top < 0 or left < 0 or right > w_img or bottom > h_img:
                continue

            size_filtered.append(loc)

        if not size_filtered:
            return []

        # ── Step 4: landmark sanity check ────────────────────
        landmarks_list = face_recognition.face_landmarks(rgb, size_filtered)
        required_parts = {"left_eye", "right_eye", "nose_tip", "top_lip"}
        confirmed_locs = []

        for loc, lm in zip(size_filtered, landmarks_list):
            # All four facial regions must be present and non-empty
            if required_parts.issubset(lm.keys()) and all(
                len(lm[k]) > 0 for k in required_parts
            ):
                confirmed_locs.append(loc)             # [FIX-4]

        if not confirmed_locs:
            return []

        # ── Compute encodings only for confirmed faces ────────
        encodings = face_recognition.face_encodings(rgb, confirmed_locs)
        return [
            {"location": loc, "encoding": enc}
            for loc, enc in zip(confirmed_locs, encodings)
        ]

    # ── match encoding against known persons ─────────────────

    def best_match(self, encoding: np.ndarray,
                   known: List[dict]) -> Optional[dict]:
        """
        HOW MATCHING WORKS
        ──────────────────
        face_distance() returns a float [0..1] per known face.
        0 = perfect match,  1 = completely different person.
        We return the person with the smallest distance,
        but only if that distance is ≤ FACE_MATCH_THRESHOLD (0.45).
        A lower threshold means fewer false matches.
        """
        if not known:
            return None

        known_encs = [np.array(p["encoding"]) for p in known]
        distances  = face_recognition.face_distance(known_encs, encoding)
        best_idx   = int(np.argmin(distances))
        best_dist  = float(distances[best_idx])

        if best_dist <= FACE_MATCH_THRESHOLD:
            return known[best_idx]
        return None


# ============================================================
#  TRACK  –  one object per currently-visible face
# ============================================================

@dataclass
class Track:
    person_id   : str
    name        : str
    center      : Tuple[float, float]
    lost_frames : int   = 0
    last_alert  : float = field(default_factory=lambda: 0.0)


# ============================================================
#  CAMERA WORKER  –  one thread per camera source
# ============================================================

class CameraWorker(threading.Thread):

    def __init__(self, source, app_state: "AppState"):
        super().__init__(daemon=True)
        self.source      = source
        self.app_state   = app_state
        self._stop       = threading.Event()
        self.recognizer  = Recognizer()
        self.tracks      : List[Track] = []
        self.frame_count : int         = 0

    # ── open / reopen camera ─────────────────────────────────

    def _open(self) -> cv2.VideoCapture:
        if isinstance(self.source, int):
            cap = cv2.VideoCapture(self.source)
        else:
            cap = cv2.VideoCapture(self.source, cv2.CAP_FFMPEG)
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 2)

        if cap.isOpened():
            w   = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h   = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            fps = cap.get(cv2.CAP_PROP_FPS)
            print(f"[CAMERA] {self.source}  {w}×{h}  {fps:.1f} fps")
        else:
            print(f"[ERROR] Could not open camera: {self.source}")
        return cap

    # ── centroid of a face bounding box ──────────────────────

    @staticmethod
    def _centroid(location: tuple) -> Tuple[float, float]:
        top, right, bottom, left = location
        return ((left + right) / 2, (top + bottom) / 2)

    # ── find existing track nearest to `center` ──────────────

    def _find_track(self, center: Tuple[float, float]) -> Optional[int]:
        best_i, best_d = None, float("inf")
        for i, t in enumerate(self.tracks):
            d = math.hypot(center[0] - t.center[0],
                           center[1] - t.center[1])
            if d < TRACK_MAX_DIST and d < best_d:
                best_i, best_d = i, d
        return best_i

    # ── terminal + DB alert for blocked face ─────────────────

    @staticmethod
    def _alert(track: Track) -> None:
        now = time.time()
        if now - track.last_alert >= ALERT_COOLDOWN:
            track.last_alert = now
            ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(f"\n{'!' * 62}")
            print(f"  ⚠  BLOCKED PERSON DETECTED")
            print(f"  Name : {track.name}")
            print(f"  ID   : {track.person_id}")
            print(f"  Time : {ts}")
            print(f"{'!' * 62}\n")
            log_event(track.person_id, track.name,
                      "blocked_alert",
                      f"Seen at {datetime.datetime.utcnow().isoformat()}")

    # ── draw bounding box + status label on frame ─────────────

    @staticmethod
    def _draw(frame: np.ndarray, location: tuple,
              name: str, status: str) -> None:
        top, right, bottom, left = location

        # Green = allowed,  Red = blocked
        color = (0, 255, 0) if status == "allow" else (0, 0, 255)
        label = f"{name}  [{status.upper()}]"

        # Face rectangle
        cv2.rectangle(frame, (left, top), (right, bottom), color, 2)

        # Filled label background
        (tw, th), _ = cv2.getTextSize(
            label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
        cv2.rectangle(frame,
                      (left, top - th - 10),
                      (left + tw + 6, top),
                      color, -1)

        # Label text (white on colour background)
        cv2.putText(frame, label,
                    (left + 3, top - 5),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55, (255, 255, 255), 1, cv2.LINE_AA)

    # ── main detection + tracking loop ───────────────────────

    def run(self) -> None:
        cap = self._open()
        if not cap.isOpened():
            return

        while not self._stop.is_set() and not self.app_state.should_stop():

            ok, frame = cap.read()

            # ── auto-reconnect on stream drop ─────────────────
            if not ok or frame is None:
                print(f"[WARN] Stream lost – reconnecting {self.source}")
                cap.release()
                time.sleep(2)
                cap = self._open()
                continue

            self.frame_count += 1

            # ── push every raw frame so display stays smooth ──
            # We always set the frame BEFORE the skip check so the
            # window shows live video even on non-processing frames.
            display_frame = frame.copy()

            if self.frame_count % PROCESS_EVERY_N != 0:
                self.app_state.set_frame(self.source, display_frame)
                continue

            # ── face detection & recognition ──────────────────
            try:
                rgb   = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                faces = self.recognizer.detect_faces(rgb)

                # Load known persons fresh each cycle so admin
                # block/allow changes take effect immediately
                known_persons = get_all_known()

                matched_indices: set = set()

                for face in faces:
                    location = face["location"]
                    encoding = face["encoding"]
                    center   = self._centroid(location)

                    # ── find or create a track ────────────────
                    t_idx = self._find_track(center)

                    if t_idx is not None:
                        # ── existing track: update position ───
                        track             = self.tracks[t_idx]
                        track.center      = center
                        track.lost_frames = 0
                        matched_indices.add(t_idx)
                        person_id = track.person_id
                        name      = track.name

                    else:
                        # ── new detection: check DB ───────────
                        match = self.recognizer.best_match(
                            encoding, known_persons)

                        if match:
                            # ── KNOWN person ──────────────────
                            person_id = match["person_id"]
                            name      = match["name"]
                            update_last_seen(person_id)
                            log_event(person_id, name, "detected")

                        else:
                            # ── BRAND-NEW person ──────────────
                            person_id  = str(uuid.uuid4())
                            name       = f"Person-{person_id[:8]}"
                            face_path  = save_face_crop(
                                frame, location, name, person_id)

                            if face_path is None:
                                # crop failed quality check – skip
                                continue

                            create_person(
                                person_id       = person_id,
                                name            = name,
                                encoding        = encoding.tolist(),
                                face_image_path = face_path,
                            )
                            log_event(person_id, name, "new_person",
                                      f"Image saved: {face_path}")
                            print(f"[NEW] {name}   img → {face_path}")

                        new_track = Track(
                            person_id = person_id,
                            name      = name,
                            center    = center,
                        )
                        self.tracks.append(new_track)
                        matched_indices.add(len(self.tracks) - 1)
                        track = new_track

                    # ── read live status from DB ───────────────
                    doc    = get_person(person_id)
                    status = doc.get("status", "allow") if doc else "allow"

                    # ── alert if blocked ───────────────────────
                    if status == "blocked":
                        self._alert(track)

                    # ── draw on the display copy ───────────────
                    self._draw(display_frame, location, name, status)

                # ── age out lost tracks ───────────────────────
                for i, t in enumerate(self.tracks):
                    if i not in matched_indices:
                        t.lost_frames += 1

                self.tracks = [
                    t for t in self.tracks
                    if t.lost_frames < TRACK_LOST_MAX
                ]

            except Exception as exc:
                print(f"[ERROR] {exc}")

            # ── push annotated frame ──────────────────────────
            self.app_state.set_frame(self.source, display_frame)

        cap.release()

    def stop(self) -> None:
        self._stop.set()


# ============================================================
#  SHARED APP STATE  –  thread-safe frame buffer + stop flag
# ============================================================

class AppState:

    def __init__(self):
        self._frames : dict          = {}
        self._lock   : threading.Lock = threading.Lock()
        self._stop   : threading.Event = threading.Event()

    def set_frame(self, source, frame: np.ndarray) -> None:
        with self._lock:
            self._frames[str(source)] = frame.copy()

    def get_frames(self) -> dict:
        with self._lock:
            return {k: v.copy() for k, v in self._frames.items()}

    def stop(self) -> None:
        self._stop.set()

    def should_stop(self) -> bool:
        return self._stop.is_set()


# ============================================================
#  MAIN
# ============================================================

def main() -> None:
    print("\n" + "=" * 62)
    print("   AI CCTV FACE SECURITY SYSTEM  v2  (False-Positive Fix)")
    print("=" * 62)
    print(f"  Cameras         : {CAMERA_SOURCES}")
    print(f"  MongoDB         : {MONGO_URI}  /  {DB_NAME}")
    print(f"  Faces folder    : {FACES_DIR.resolve()}")
    print(f"  Model           : {FACE_MODEL}")
    print(f"  Match threshold : {FACE_MATCH_THRESHOLD}")
    print(f"  Min face size   : {MIN_FACE_PX}×{MIN_FACE_PX} px")
    print(f"  Aspect range    : {ASPECT_MIN} – {ASPECT_MAX}")
    print("=" * 62)
    print("  Filters active  : upsample=0 | size | aspect | landmark")
    print("  Press  Q  or  ESC  to quit")
    print("=" * 62 + "\n")

    state   = AppState()
    workers : List[CameraWorker] = []

    for src in CAMERA_SOURCES:
        w = CameraWorker(src, state)
        w.start()
        workers.append(w)

    try:
        while not state.should_stop():
            frames = state.get_frames()

            for src, frame in frames.items():
                win = f"CCTV  |  cam {src}"
                cv2.namedWindow(win, cv2.WINDOW_NORMAL)   # freely resizable
                cv2.imshow(win, frame)

            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), ord("Q"), 27):
                state.stop()

            time.sleep(0.01)

    except KeyboardInterrupt:
        state.stop()

    finally:
        for w in workers:
            w.stop()
        for w in workers:
            w.join(timeout=3)
        cv2.destroyAllWindows()
        _client.close()
        print("\n[SYSTEM] Stopped cleanly.\n")


if __name__ == "__main__":
    main()