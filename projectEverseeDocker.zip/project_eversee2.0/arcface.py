# ============================================================
# AI CCTV FACE SECURITY SYSTEM
# ArcFace + InsightFace Version
# Stable RTSP + Better Face Detection
# ============================================================

from __future__ import annotations

# ============================================================
# RTSP TCP FIX
# ============================================================

import os

os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "rtsp_transport;tcp"

# ============================================================
# IMPORTS
# ============================================================

import cv2
import time
import uuid
import math
import threading
import datetime
import numpy as np

from pathlib import Path
from dataclasses import dataclass
from typing import List, Tuple

import insightface

# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).parent

DATA_DIR = BASE_DIR / "data"

FACES_DIR = DATA_DIR / "faces"

DATA_DIR.mkdir(exist_ok=True)

FACES_DIR.mkdir(exist_ok=True)

# ============================================================
# CAMERA SETTINGS
# ============================================================

CAMERA_SOURCES = [
    # "rtsp://admin:EduServices%2301@192.168.29.100:554/cam/realmonitor?channel=1&subtype=0",
    "rtsp://admin:EduServices%2301@192.168.29.100:554/cam/realmonitor?channel=1&subtype=2"
]

# ============================================================
# DETECTION SETTINGS
# ============================================================

FACE_MATCH_THRESHOLD = 0.45

MIN_FACE_WIDTH = 40

MIN_FACE_HEIGHT = 40

MIN_DET_SCORE = 0.55

FRAME_SKIP = 2

TRACK_DISTANCE = 120

TRACK_LOST_FRAMES = 30

# ============================================================
# TRACK CLASS
# ============================================================

@dataclass
class Track:

    person_id: str

    center: Tuple[float, float]

    embedding: np.ndarray

    lost_frames: int = 0

# ============================================================
# INSIGHTFACE SETUP
# ============================================================

print("\n[INSIGHT] Loading InsightFace models ...")

app = insightface.app.FaceAnalysis(
    name="buffalo_l",
    providers=["CPUExecutionProvider"]
)

app.prepare(
    ctx_id=0,
    det_size=(1280, 1280)
)

print("[INSIGHT] Models ready")

# ============================================================
# HELPERS
# ============================================================

def cosine_similarity(a, b):

    return np.dot(a, b) / (
        np.linalg.norm(a) * np.linalg.norm(b)
    )

def centroid(box):

    x1, y1, x2, y2 = box

    return (
        (x1 + x2) / 2,
        (y1 + y2) / 2
    )

def distance(a, b):

    return math.hypot(
        a[0] - b[0],
        a[1] - b[1]
    )

# ============================================================
# CAMERA WORKER
# ============================================================

class CameraWorker(threading.Thread):

    def __init__(self, source):

        super().__init__(daemon=True)

        self.source = source

        self.stop_signal = threading.Event()

        self.tracks: List[Track] = []

    # ========================================================
    # OPEN CAMERA
    # ========================================================

    def open_camera(self):

        print(f"\n[CAM] Connecting {self.source}")

        cap = cv2.VideoCapture(
            self.source,
            cv2.CAP_FFMPEG
        )

        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

        if cap.isOpened():

            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))

            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

            fps = cap.get(cv2.CAP_PROP_FPS)

            print(
                f"[CAM] Connected "
                f"{width}x{height} "
                f"{fps:.1f}fps"
            )

        return cap

    # ========================================================
    # FIND TRACK
    # ========================================================

    def find_track(self, center, embedding):

        best_index = None

        best_similarity = 0

        for i, track in enumerate(self.tracks):

            d = distance(center, track.center)

            if d > TRACK_DISTANCE:
                continue

            similarity = cosine_similarity(
                embedding,
                track.embedding
            )

            if similarity > FACE_MATCH_THRESHOLD:

                if similarity > best_similarity:

                    best_similarity = similarity

                    best_index = i

        return best_index

    # ========================================================
    # MAIN LOOP
    # ========================================================

    def run(self):

        cap = self.open_camera()

        if not cap.isOpened():

            print("[ERROR] Cannot open camera")

            return

        frame_counter = 0

        while not self.stop_signal.is_set():

            success, frame = cap.read()

            if not success:

                print("[WARNING] Reconnecting camera...")

                cap.release()

                time.sleep(2)

                cap = self.open_camera()

                continue

            frame_counter += 1

            if frame_counter % FRAME_SKIP != 0:
                continue

            try:

                faces = app.get(frame)

                matched_tracks = set()

                for face in faces:

                    box = face.bbox.astype(int)

                    x1, y1, x2, y2 = box

                    score = float(face.det_score)

                    if score < MIN_DET_SCORE:
                        continue

                    width = x2 - x1

                    height = y2 - y1

                    if width < MIN_FACE_WIDTH:
                        continue

                    if height < MIN_FACE_HEIGHT:
                        continue

                    embedding = face.embedding

                    center = centroid(box)

                    track_index = self.find_track(
                        center,
                        embedding
                    )

                    # ====================================
                    # EXISTING PERSON
                    # ====================================

                    if track_index is not None:

                        track = self.tracks[track_index]

                        track.center = center

                        track.embedding = embedding

                        track.lost_frames = 0

                        matched_tracks.add(track_index)

                        person_id = track.person_id

                    # ====================================
                    # NEW PERSON
                    # ====================================

                    else:

                        person_id = str(uuid.uuid4())[:8]

                        self.tracks.append(
                            Track(
                                person_id=person_id,
                                center=center,
                                embedding=embedding
                            )
                        )

                        matched_tracks.add(
                            len(self.tracks) - 1
                        )

                        print(
                            f"[NEW FACE] {person_id}"
                        )

                        # SAVE FACE IMAGE

                        crop = frame[y1:y2, x1:x2]

                        if crop.size > 0:

                            filename = (
                                f"{person_id}.jpg"
                            )

                            filepath = (
                                FACES_DIR / filename
                            )

                            cv2.imwrite(
                                str(filepath),
                                crop
                            )

                    # ====================================
                    # DRAW FACE
                    # ====================================

                    cv2.rectangle(
                        frame,
                        (x1, y1),
                        (x2, y2),
                        (0, 255, 0),
                        2
                    )

                    label = (
                        f"ID: {person_id} "
                        f"{score:.2f}"
                    )

                    cv2.putText(
                        frame,
                        label,
                        (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.6,
                        (0, 255, 0),
                        2
                    )

                # ========================================
                # CLEAN TRACKS
                # ========================================

                for i, track in enumerate(self.tracks):

                    if i not in matched_tracks:

                        track.lost_frames += 1

                self.tracks = [

                    t for t in self.tracks

                    if t.lost_frames < TRACK_LOST_FRAMES
                ]

                # ========================================
                # SHOW FRAME
                # ========================================

                cv2.imshow(
                    "AI CCTV FACE SECURITY",
                    frame
                )

                key = cv2.waitKey(1) & 0xFF

                if key in (ord("q"), 27):

                    self.stop()

                    break

            except Exception as e:

                print(f"[ERROR] {e}")

        cap.release()

        cv2.destroyAllWindows()

    # ========================================================
    # STOP
    # ========================================================

    def stop(self):

        self.stop_signal.set()

# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":

    print("\n====================================================")

    print(" AI CCTV FACE SECURITY SYSTEM ")

    print(" ArcFace + InsightFace Version ")

    print("====================================================")

    print(f"Camera: {CAMERA_SOURCES}")

    print(f"Face Threshold: {FACE_MATCH_THRESHOLD}")

    print(f"Detection Score: {MIN_DET_SCORE}")

    print()

    workers = []

    for source in CAMERA_SOURCES:

        worker = CameraWorker(source)

        worker.start()

        workers.append(worker)

    try:

        while True:

            time.sleep(1)

    except KeyboardInterrupt:

        print("\nStopping system...\n")

        for worker in workers:

            worker.stop()

        for worker in workers:

            worker.join()

        cv2.destroyAllWindows()

        print("System stopped.")