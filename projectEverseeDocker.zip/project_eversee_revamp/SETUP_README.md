# Supermarket AI Surveillance System — Setup Guide

## System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| GPU | NVIDIA 4 GB VRAM | NVIDIA 8 GB+ VRAM |
| RAM | 8 GB | 16 GB |
| Python | 3.9+ | 3.10+ |
| OS | Windows 10 / Ubuntu 20.04 | Ubuntu 22.04 |
| CUDA | 11.8+ | 12.x |

---

## Step 1 — Install Python Dependencies

```bash
pip install opencv-python pillow numpy pymongo boto3
pip install ultralytics
pip install insightface onnxruntime-gpu
pip install websockets ollama scipy
```

---

## Step 2 — Install Ollama and Download Qwen Model

**Install Ollama:**
- Linux/Mac: `curl -fsSL https://ollama.com/install.sh | sh`
- Windows: Download from https://ollama.com/download

**Download the vision model (pick one):**
```bash
ollama pull qwen2.5vl:7b    # Best quality — needs ~6 GB VRAM
ollama pull qwen2.5vl:3b    # Lighter — needs ~3 GB VRAM
```

**Start Ollama server (run in a separate terminal):**
```bash
ollama serve
```

---

## Step 3 — Configure the Script

Open `supermarket_surveillance.py` and edit these lines at the top:

```python
CAMERA_URL   = "rtsp://your_camera_url"   # or: 0  for webcam
MONGO_URI    = "your_mongodb_connection_string"
OLLAMA_MODEL = "qwen2.5vl:7b"             # or qwen2.5vl:3b
```

**To test with your webcam instead of RTSP:**
```python
CAMERA_URL = 0
```

---

## Step 4 — Run the Script

```bash
# Terminal 1 — start Ollama
ollama serve

# Terminal 2 — start surveillance
python supermarket_surveillance.py
```

---

## What Happens Automatically

### Models download on first run:
- **YOLOv8n** (~6 MB) — downloads from Ultralytics automatically
- **InsightFace buffalo_l** (~300 MB) — downloads from InsightFace CDN automatically

### MongoDB collections created automatically:
| Collection | Purpose |
|---|---|
| `people_profiles` | One document per unique person seen |
| `blocked_persons` | Blocked person list with face embeddings |
| `incidents` | All anomaly and blocked-entry events |

---

## How to Block a Person

After someone is detected, they get a `person_id` like `P20240101120000123456`.

**Option 1 — Python (in a separate script or shell):**
```python
from supermarket_surveillance import manual_block
manual_block("P20240101120000123456", reason="Shoplifting confirmed")
```

**Option 2 — Directly in MongoDB:**
```
db.people_profiles.updateOne(
  { person_id: "P20240101120000123456" },
  { $set: { is_blocked: true } }
)
```
Then restart the script — it will reload the blocklist.

---

## How to List All Detected Persons

```python
from supermarket_surveillance import list_persons
list_persons()
```

Output:
```
✅ OK    | P20240101120000123 | visits: 3 | first: 2024-01-01 12:00
🚫 BLOCKED | P20240101130000456 | visits: 1 | first: 2024-01-01 13:00
```

---

## Evidence Files

All evidence is saved to the `evidence/` folder:
- `face_<person_id>_<timestamp>.jpg` — face crop of new/returning visitor
- `BLOCKED_<person_id>_<timestamp>.jpg` — face crop of blocked person detected
- `incident_risk_<timestamp>.jpg` — full frame when anomaly detected

---

## WebSocket Data Format

Connect to `ws://localhost:8765` to receive live updates:

```json
{
  "frame_number": 142,
  "timestamp": "2024-01-01 12:05:33",
  "people_count": 3,
  "faces_found": 2,
  "description": "Two customers browsing the aisle normally.",
  "status": "normal",
  "anomaly_type": null,
  "alerts": []
}
```

When a blocked person is detected:
```json
{
  "alerts": [{
    "type": "BLOCKED_PERSON_ENTRY",
    "person_id": "P20240101130000456",
    "similarity": 0.921,
    "message": "⚠️ Blocked person P20240101130000456 entered the store!",
    "evidence": "evidence/BLOCKED_P20240101130000456_20240101130500.jpg"
  }]
}
```

---

## GPU VRAM Guide

| GPU VRAM | Recommended Model | Notes |
|---|---|---|
| 4 GB | `qwen2.5vl:3b` | Run Qwen on CPU if needed |
| 6–8 GB | `qwen2.5vl:7b` | All models on GPU |
| 10 GB+ | `qwen2.5vl:7b` | Full speed, all simultaneous |

**If you get CUDA out-of-memory errors:**
1. Change `OLLAMA_MODEL = "qwen2.5vl:3b"`
2. Or set `ANOMALY_EVERY_N_FRAMES = 20` to run Qwen less often

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `Cannot open camera` | Check RTSP URL or use `CAMERA_URL = 0` for webcam |
| `Ollama connection error` | Run `ollama serve` in a separate terminal first |
| `InsightFace CUDA error` | Change `ctx_id=0` to `ctx_id=-1` in `face_app.prepare()` to use CPU |
| `onnxruntime not found` | Run `pip install onnxruntime-gpu` |
| `MongoDB connection failed` | Check MONGO_URI string |
