# import datetime
# import json
# import os
# import threading
# import time
# import uuid
# from pathlib import Path
# from typing import Dict, List, Optional, Tuple

# import cv2
# import face_recognition
# import numpy as np

# # ---------------------------------------------------------------------------
# # Paths
# # ---------------------------------------------------------------------------
# BASE_DIR = Path(__file__).parent
# DATA_DIR = BASE_DIR / "data"
# FACES_DIR = DATA_DIR / "faces"
# PERSONS_FILE = DATA_DIR / "persons.json"
# ACCESS_STATUS_FILE = DATA_DIR / "access_status.json"

# DATA_DIR.mkdir(exist_ok=True)
# FACES_DIR.mkdir(exist_ok=True)

# # ---------------------------------------------------------------------------
# # Config
# # ---------------------------------------------------------------------------
# EMBEDDING_THRESHOLD: float = float(os.getenv("EMBEDDING_THRESHOLD", "0.5"))
# UNKNOWN_SAVE_SECONDS: int = int(os.getenv("UNKNOWN_SAVE_SECONDS", "30"))
# CAMERA_SOURCES: str = os.getenv("CAMERA_SOURCES", "0")


# def cameras() -> List[str]:
#     return [s.strip() for s in CAMERA_SOURCES.split(",") if s.strip()]


# # ---------------------------------------------------------------------------
# # JSON helpers (thread-safe via a single global lock)
# # ---------------------------------------------------------------------------
# _file_lock = threading.Lock()


# def _read_json(path: Path) -> dict:
#     if not path.exists():
#         return {}
#     with open(path, "r", encoding="utf-8") as f:
#         return json.load(f)


# def _write_json(path: Path, data: dict):
#     with open(path, "w", encoding="utf-8") as f:
#         json.dump(data, f, indent=2, default=str)


# # ---------------------------------------------------------------------------
# # persons.json  — face encodings + detection log
# # Schema:
# #   { "<person_id>": {
# #       "id": str,
# #       "name": str,
# #       "face_image": str,        # relative path inside data/faces/
# #       "encoding": [float, ...],
# #       "created_at": ISO-str,
# #       "detections": [{"timestamp": ISO-str}, ...]
# #   }}
# # ---------------------------------------------------------------------------

# def load_persons() -> dict:
#     with _file_lock:
#         return _read_json(PERSONS_FILE)


# def log_detection(person_id: str):
#     """Append a detection timestamp to an existing person's record."""
#     with _file_lock:
#         persons = _read_json(PERSONS_FILE)
#         if person_id in persons:
#             persons[person_id].setdefault("detections", []).append(
#                 {"timestamp": datetime.datetime.now().isoformat()}
#             )
#             _write_json(PERSONS_FILE, persons)


# def register_person_if_new(
#     encoding: np.ndarray,
#     frame,
#     location: tuple,
#     threshold: float,
# ) -> Tuple[Optional[str], Optional[str], bool]:
#     """
#     Atomically check persons.json and register only if no matching face exists.
#     Returns (person_id, name, is_new). is_new=False means a duplicate was found.
#     The face image is saved BEFORE the lock so disk I/O doesn't block readers.
#     """
#     # Pre-generate id/name so we only need one lock acquisition
#     pid = str(uuid.uuid4())
#     name = f"Unknown-{pid[:8]}"
#     face_img_path = save_face_image(frame, location, name, pid)

#     with _file_lock:
#         persons = _read_json(PERSONS_FILE)

#         # Re-check inside the lock against the latest data
#         if persons:
#             known_encs = [np.array(p["encoding"]) for p in persons.values()]
#             dists = face_recognition.face_distance(known_encs, encoding)
#             best_idx = int(np.argmin(dists))
#             if float(dists[best_idx]) <= threshold:
#                 # Duplicate — discard the image we just saved
#                 img_full = DATA_DIR / face_img_path
#                 if img_full.exists():
#                     img_full.unlink()
#                 matched = list(persons.values())[best_idx]
#                 return matched["id"], matched["name"], False

#         now = datetime.datetime.now().isoformat()
#         persons[pid] = {
#             "id": pid,
#             "name": name,
#             "face_image": face_img_path,
#             "encoding": encoding.tolist(),
#             "created_at": now,
#             "detections": [{"timestamp": now}],
#         }
#         _write_json(PERSONS_FILE, persons)

#     return pid, name, True


# # ---------------------------------------------------------------------------
# # access_status.json  — allow / block per person
# # Schema:
# #   { "<person_id>": {
# #       "name": str,
# #       "status": "allow" | "block",
# #       "updated_at": ISO-str
# #   }}
# # ---------------------------------------------------------------------------

# def load_access_status() -> dict:
#     with _file_lock:
#         return _read_json(ACCESS_STATUS_FILE)


# def save_access_status(status: dict):
#     with _file_lock:
#         _write_json(ACCESS_STATUS_FILE, status)


# def set_access_status(person_id: str, name: str, status: str = "allow"):
#     access = load_access_status()
#     access[person_id] = {
#         "name": name,
#         "status": status,
#         "updated_at": datetime.datetime.now().isoformat(),
#     }
#     save_access_status(access)


# def get_status(person_id: str) -> str:
#     """Returns 'allow' or 'block'. Defaults to 'allow' if not found."""
#     access = load_access_status()
#     return access.get(person_id, {}).get("status", "allow")


# # ---------------------------------------------------------------------------
# # Face image capture helper
# # ---------------------------------------------------------------------------

# def save_face_image(frame, location, name: str, person_id: str) -> str:
#     """Crop face from frame, save to faces/ folder. Returns relative path."""
#     top, right, bottom, left = location
#     # Add small padding
#     pad = 20
#     h, w = frame.shape[:2]
#     top = max(0, top - pad)
#     left = max(0, left - pad)
#     bottom = min(h, bottom + pad)
#     right = min(w, right + pad)

#     face_crop = frame[top:bottom, left:right]
#     filename = f"{name}_{person_id[:8]}.jpg"
#     filepath = FACES_DIR / filename
#     cv2.imwrite(str(filepath), face_crop)
#     return str(filepath.relative_to(DATA_DIR))


# # ---------------------------------------------------------------------------
# # Face Recognizer
# # ---------------------------------------------------------------------------

# class Recognizer:
#     def __init__(self, threshold: float = 0.5):
#         self.threshold = threshold

#     def detect_and_encode(self, rgb_frame) -> List[Dict]:
#         locations = face_recognition.face_locations(rgb_frame)
#         encodings = face_recognition.face_encodings(rgb_frame, locations)
#         return [{"location": loc, "encoding": enc} for loc, enc in zip(locations, encodings)]

#     def best_match(self, encoding, known: List[Dict]) -> Tuple[Optional[Dict], Optional[float]]:
#         if not known:
#             return None, None
#         encs = [np.array(p["encoding"]) for p in known]
#         dists = face_recognition.face_distance(encs, encoding)
#         best_idx = int(np.argmin(dists))
#         best_dist = float(dists[best_idx])
#         if best_dist <= self.threshold:
#             return known[best_idx], best_dist
#         return None, best_dist

#     @staticmethod
#     def draw_boxes(frame, locations, labels, statuses):
#         for (top, right, bottom, left), label, status in zip(locations, labels, statuses):
#             color = (0, 255, 0) if status != "block" else (0, 0, 255)
#             cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
#             display = f"{label} [{status}]"
#             cv2.putText(frame, display, (left, max(top - 10, 0)),
#                         cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
#         return frame


# # ---------------------------------------------------------------------------
# # Camera Worker
# # ---------------------------------------------------------------------------

# class CameraWorker(threading.Thread):
#     def __init__(self, source, state):
#         super().__init__(daemon=True)
#         self.source = source
#         self.state = state
#         self.recognizer = Recognizer(EMBEDDING_THRESHOLD)
#         self.stop_event = threading.Event()

#     def run(self):
#         cap = self._open_capture(self.source)
#         if not cap.isOpened():
#             print(f"Failed to open camera source: {self.source}")
#             return

#         while not self.stop_event.is_set() and not self.state.should_stop():
#             ret, frame = cap.read()
#             if not ret:
#                 if not cap.isOpened():
#                     cap.release()
#                     cap = self._open_capture(self.source)
#                 time.sleep(0.5)
#                 continue

#             rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
#             faces = self.recognizer.detect_and_encode(rgb)
#             labels = []
#             locations = []
#             statuses = []

#             # Load current known persons once per frame
#             persons = load_persons()
#             known_list = [
#                 {"id": pid, "name": p["name"], "encoding": p["encoding"]}
#                 for pid, p in persons.items()
#             ]

#             for face in faces:
#                 loc = face["location"]
#                 enc = face["encoding"]

#                 match, _ = self.recognizer.best_match(enc, known_list)

#                 if match is not None:
#                     pid = match["id"]
#                     name = match["name"]
#                     status = get_status(pid)
#                     log_detection(pid)
#                     labels.append(name)
#                     statuses.append(status)
#                     if status == "block":
#                         print(f"ALERT: Blocked person detected — {name} (id={pid})")
#                 else:
#                     pid, name, is_new = register_person_if_new(
#                         enc, frame, loc, EMBEDDING_THRESHOLD
#                     )
#                     if is_new:
#                         set_access_status(pid, name, status="allow")
#                         print(f"NEW_PERSON: {name} registered (id={pid[:8]})")
#                     else:
#                         # Duplicate caught inside the lock — log detection instead
#                         log_detection(pid)
#                     labels.append(name)
#                     statuses.append(get_status(pid))

#                 locations.append(loc)

#             frame = self.recognizer.draw_boxes(frame, locations, labels, statuses)
#             self.state.set_frame(self.source, frame)
#             time.sleep(0.05)

#         cap.release()

#     def stop(self):
#         self.stop_event.set()

#     @staticmethod
#     def _open_capture(source):
#         if isinstance(source, int):
#             cap = cv2.VideoCapture(source, cv2.CAP_DSHOW)
#             if cap.isOpened():
#                 return cap
#         return cv2.VideoCapture(source)


# # ---------------------------------------------------------------------------
# # App State
# # ---------------------------------------------------------------------------

# class AppState:
#     def __init__(self):
#         self._frames: Dict[str, np.ndarray] = {}
#         self._lock = threading.Lock()
#         self._stop_event = threading.Event()

#     def set_frame(self, source, frame):
#         with self._lock:
#             self._frames[str(source)] = frame.copy()

#     def get_frames(self):
#         with self._lock:
#             return {k: v.copy() for k, v in self._frames.items()}

#     def request_stop(self):
#         self._stop_event.set()

#     def should_stop(self):
#         return self._stop_event.is_set()


# # ---------------------------------------------------------------------------
# # Entry point
# # ---------------------------------------------------------------------------

# def parse_source(source: str):
#     return int(source) if source.isdigit() else source


# def start_workers(state: AppState):
#     workers = []
#     for src in cameras():
#         worker = CameraWorker(parse_source(src), state)
#         worker.start()
#         workers.append(worker)
#     return workers


# def stop_workers(workers):
#     for w in workers:
#         w.stop()
#     for w in workers:
#         w.join(timeout=2.0)


# if __name__ == "__main__":
#     print(f"Data directory : {DATA_DIR}")
#     print(f"Faces directory: {FACES_DIR}")
#     print(f"Persons file   : {PERSONS_FILE}")
#     print(f"Access status  : {ACCESS_STATUS_FILE}")
#     print("Backend started. Press Q or Esc to stop.\n")

#     state = AppState()
#     workers = start_workers(state)

#     try:
#         while not state.should_stop():
#             frames = state.get_frames()
#             for src, frame in frames.items():
#                 cv2.imshow(f"Face Security - Camera {src}", frame)

#             key = cv2.waitKey(1) & 0xFF
#             if key in (ord("q"), 27):
#                 state.request_stop()

#             time.sleep(0.01)
#     except KeyboardInterrupt:
#         print("Stopping...")
#         state.request_stop()
#     finally:
#         stop_workers(workers)
#         cv2.destroyAllWindows()
#         print("Backend stopped.")





































































