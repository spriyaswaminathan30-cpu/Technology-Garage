

import cv2
import numpy as np
from PIL import Image
from io import BytesIO
import base64
from datetime import datetime
import time
import asyncio
import threading
import json
import os
import logging

import ollama
import websockets
from pymongo import MongoClient
from scipy.spatial.distance import cosine

# YOLOv8
from ultralytics import YOLO

# InsightFace
from insightface.app import FaceAnalysis

# ──────────────────────────────────────────────
#  CONFIGURATION  — Edit these values
# ──────────────────────────────────────────────

CAMERA_URL = "rtsp://admin:EduServices%2301@192.168.29.100:554/cam/realmonitor?channel=1&subtype=0"
# For testing with a webcam, use: CAMERA_URL = 0

MONGO_URI   = "mongodb+srv://tgdev:technology-1@cluster0.0pefygc.mongodb.net/"
DB_NAME     = "project_eversee"

OLLAMA_MODEL = "qwen2.5vl:7b"   # change to qwen2.5vl:3b if low VRAM

WEBSOCKET_HOST = "0.0.0.0"
WEBSOCKET_PORT = 8765

# Face matching threshold (0.0–1.0). Lower = stricter match.
FACE_MATCH_THRESHOLD = 0.45

# How often to run Qwen anomaly detection (every N frames)
ANOMALY_EVERY_N_FRAMES = 8

# Evidence folder for local image/video saves
EVIDENCE_DIR = "evidence"
os.makedirs(EVIDENCE_DIR, exist_ok=True)

# ──────────────────────────────────────────────
#  LOGGING
# ──────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
log = logging.getLogger("surveillance")

# ──────────────────────────────────────────────
#  MONGODB SETUP
# ──────────────────────────────────────────────

mongo_client = MongoClient(MONGO_URI)
db           = mongo_client[DB_NAME]

# Collections
col_people   = db["people_profiles"]    # one doc per unique person seen
col_blocked  = db["blocked_persons"]    # blocked persons list
col_incidents = db["incidents"]         # anomaly / alert events

# Indexes for fast lookup
col_people.create_index("person_id", unique=True)
col_blocked.create_index("person_id", unique=True)

# ──────────────────────────────────────────────
#  AI MODEL INIT
# ──────────────────────────────────────────────

log.info("Loading YOLOv8n (person detector)...")
yolo_model = YOLO("yolov8n.pt")   # auto-downloads ~6MB on first run
log.info("YOLOv8n ready ✅")

log.info("Loading InsightFace buffalo_l (face recognition)...")
face_app = FaceAnalysis(name="buffalo_l")
face_app.prepare(ctx_id=0, det_size=(640, 640))  # ctx_id=0 = first NVIDIA GPU
log.info("InsightFace ready ✅")

# ──────────────────────────────────────────────
#  GLOBALS
# ──────────────────────────────────────────────

connected_clients = set()
latest_data = {
    "description": "System starting...",
    "status": "normal",
    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "people_count": 0,
    "alerts": []
}
frame_count       = 0
blocked_cache     = []   # in-memory cache of blocked face embeddings


# ──────────────────────────────────────────────
#  HELPER: load blocked embeddings into memory
# ──────────────────────────────────────────────

def refresh_blocked_cache():
    """Load all blocked person embeddings from MongoDB into RAM."""
    global blocked_cache
    blocked_cache = list(col_blocked.find({}, {"person_id": 1, "embedding": 1, "name": 1, "_id": 0}))
    log.info(f"Blocked cache refreshed — {len(blocked_cache)} blocked persons loaded")


# ──────────────────────────────────────────────
#  HELPER: face embedding utilities
# ──────────────────────────────────────────────

def embedding_to_list(emb: np.ndarray) -> list:
    return emb.tolist()

def list_to_embedding(lst: list) -> np.ndarray:
    return np.array(lst, dtype=np.float32)

def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    return 1 - cosine(a, b)

def match_face(query_embedding: np.ndarray, candidates: list, threshold: float) -> tuple:
    """
    Check query_embedding against a list of candidate dicts with 'embedding' key.
    Returns (matched_person_id, similarity) or (None, 0).
    """
    best_sim   = 0.0
    best_match = None
    for candidate in candidates:
        stored_emb = list_to_embedding(candidate["embedding"])
        sim = cosine_similarity(query_embedding, stored_emb)
        if sim > best_sim:
            best_sim   = sim
            best_match = candidate
    if best_sim >= threshold and best_match:
        return best_match["person_id"], best_sim
    return None, 0.0


# ──────────────────────────────────────────────
#  HELPER: save face crop image
# ──────────────────────────────────────────────

def save_face_crop(frame: np.ndarray, bbox: list, person_id: str, tag: str = "") -> str:
    """Crop face from frame and save as JPEG. Returns local file path."""
    x1, y1, x2, y2 = [int(v) for v in bbox]
    # Add padding
    h, w = frame.shape[:2]
    pad = 20
    x1 = max(0, x1 - pad)
    y1 = max(0, y1 - pad)
    x2 = min(w, x2 + pad)
    y2 = min(h, y2 + pad)
    crop = frame[y1:y2, x1:x2]
    ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{tag}_{person_id}_{ts}.jpg"
    path = os.path.join(EVIDENCE_DIR, filename)
    cv2.imwrite(path, crop)
    return path


# ──────────────────────────────────────────────
#  HELPER: save full frame as evidence
# ──────────────────────────────────────────────

def save_frame_evidence(frame: np.ndarray, label: str) -> str:
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"incident_{label}_{ts}.jpg"
    path     = os.path.join(EVIDENCE_DIR, filename)
    cv2.imwrite(path, frame)
    return path


# ──────────────────────────────────────────────
#  HELPER: encode frame for Ollama (Qwen)
# ──────────────────────────────────────────────

def encode_frame_b64(frame: np.ndarray) -> str:
    pil_img  = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    buf      = BytesIO()
    pil_img.save(buf, format="JPEG", quality=80)
    return base64.b64encode(buf.getvalue()).decode("utf-8")


# ──────────────────────────────────────────────
#  QWEN ANOMALY DETECTION
# ──────────────────────────────────────────────

def detect_anomaly(frame: np.ndarray, frame_number: int, people_count: int) -> dict:
    """
    Ask Qwen2.5-VL to analyse the frame for anomalies.
    Returns dict: {description, status, anomaly_type}
    """
    b64 = encode_frame_b64(frame)
    prompt = f"""
You are an AI monitoring a supermarket CCTV camera. Analyze this frame carefully.

Context: {people_count} person(s) visible in the frame.
Frame number: {frame_number}

Look for the following and describe in 2 sentences:
1. SHOPLIFTING — hiding items in bags, pockets, clothing, or under cart
2. AGGRESSIVE BEHAVIOR — fighting, pushing, threatening, arguments
3. SLIP / FALL — person on ground, slipping, tripping
4. LOITERING — person standing still in one spot for a long time
5. THEFT FROM DISPLAY — removing items from shelves abnormally
6. NORMAL SHOPPING — if nothing suspicious is happening, say so

At the end of your response, on a new line, write exactly one of:
STATUS: NORMAL
STATUS: MEDIUM
STATUS: RISK

If STATUS is MEDIUM or RISK, also write:
ANOMALY: <one word describing the type, e.g. SHOPLIFTING, FIGHTING, FALL, LOITERING>
"""
    try:
        response = ollama.generate(model=OLLAMA_MODEL, prompt=prompt, images=[b64])
        text     = response.get("response", "").strip()

        # Parse status
        status = "normal"
        if "STATUS: RISK" in text:
            status = "risk"
        elif "STATUS: MEDIUM" in text:
            status = "medium"

        # Parse anomaly type
        anomaly_type = None
        for line in text.splitlines():
            if line.startswith("ANOMALY:"):
                anomaly_type = line.replace("ANOMALY:", "").strip()

        # Clean description (remove status/anomaly lines)
        desc_lines = [l for l in text.splitlines()
                      if not l.startswith("STATUS:") and not l.startswith("ANOMALY:")]
        description = " ".join(desc_lines).strip()

        return {"description": description, "status": status, "anomaly_type": anomaly_type}

    except Exception as e:
        log.error(f"Qwen error: {e}")
        return {"description": "Analysis error", "status": "normal", "anomaly_type": None}


# ──────────────────────────────────────────────
#  PERSON MANAGEMENT
# ──────────────────────────────────────────────

def get_or_create_person(embedding: np.ndarray, face_crop_path: str, age, gender) -> tuple:
    """
    Compare embedding against known persons in MongoDB.
    If match found → return existing person_id.
    If new → create profile doc, return new person_id.
    Returns (person_id, is_new)
    """
    all_persons = list(col_people.find({}, {"person_id": 1, "embedding": 1, "_id": 0}))
    matched_id, sim = match_face(embedding, all_persons, FACE_MATCH_THRESHOLD)

    if matched_id:
        # Update last seen
        col_people.update_one(
            {"person_id": matched_id},
            {"$set": {"last_seen": datetime.now().isoformat()},
             "$inc": {"visit_count": 1}}
        )
        return matched_id, False
    else:
        # New person — create profile
        person_id = f"P{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        doc = {
            "person_id":    person_id,
            "embedding":    embedding_to_list(embedding),
            "face_crop":    face_crop_path,
            "age_estimate": int(age) if age else None,
            "gender":       "Male" if gender == 1 else "Female",
            "first_seen":   datetime.now().isoformat(),
            "last_seen":    datetime.now().isoformat(),
            "visit_count":  1,
            "is_blocked":   False,
            "incidents":    []
        }
        col_people.insert_one(doc)
        log.info(f"👤 New person profile created: {person_id}")
        return person_id, True


def block_person(person_id: str, reason: str = "Manual block"):
    """Add person to blocklist."""
    person = col_people.find_one({"person_id": person_id})
    if not person:
        log.warning(f"block_person: {person_id} not found in people_profiles")
        return

    # Add to blocked collection
    block_doc = {
        "person_id":  person_id,
        "embedding":  person["embedding"],
        "name":       person.get("name", "Unknown"),
        "reason":     reason,
        "blocked_at": datetime.now().isoformat(),
        "face_crop":  person.get("face_crop", "")
    }
    col_blocked.update_one({"person_id": person_id}, {"$set": block_doc}, upsert=True)

    # Mark in people_profiles
    col_people.update_one(
        {"person_id": person_id},
        {"$set": {"is_blocked": True, "block_reason": reason}}
    )
    refresh_blocked_cache()
    log.warning(f"🚫 Person BLOCKED: {person_id} — Reason: {reason}")


# ──────────────────────────────────────────────
#  INCIDENT LOGGING
# ──────────────────────────────────────────────

def log_incident(person_id: str, incident_type: str, description: str,
                 evidence_path: str, frame_number: int, is_blocked_entry: bool = False):
    """Store an incident record in MongoDB."""
    incident = {
        "person_id":        person_id,
        "type":             incident_type,
        "description":      description,
        "evidence_image":   evidence_path,
        "frame_number":     frame_number,
        "timestamp":        datetime.now().isoformat(),
        "is_blocked_entry": is_blocked_entry
    }
    col_incidents.insert_one(incident)
    # Also link to person profile
    col_people.update_one(
        {"person_id": person_id},
        {"$push": {"incidents": incident}}
    )


# ──────────────────────────────────────────────
#  WEBSOCKET BROADCAST
# ──────────────────────────────────────────────

async def broadcast(data: dict):
    if not connected_clients:
        return
    msg = json.dumps(data)
    disconnected = set()
    for ws in connected_clients:
        try:
            await ws.send(msg)
        except Exception:
            disconnected.add(ws)
    connected_clients -= disconnected


# ──────────────────────────────────────────────
#  SAFE CAMERA READ
# ──────────────────────────────────────────────

def safe_read(cap, url):
    ret, frame = cap.read()
    if not ret:
        log.warning("Camera read failed — reconnecting...")
        cap.release()
        time.sleep(1)
        cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
        ret, frame = cap.read()
        if not ret:
            return cap, None
    return cap, frame


# ──────────────────────────────────────────────
#  MAIN SURVEILLANCE LOOP
# ──────────────────────────────────────────────

def surveillance_loop():
    global latest_data, frame_count

    # Load blocked persons into memory on startup
    refresh_blocked_cache()

    log.info(f"📹 Opening camera: {CAMERA_URL}")
    cap = cv2.VideoCapture(CAMERA_URL, cv2.CAP_FFMPEG) if isinstance(CAMERA_URL, str) \
          else cv2.VideoCapture(CAMERA_URL)

    if not cap.isOpened():
        log.error("❌ Cannot open camera. Check CAMERA_URL.")
        return

    log.info("✅ Camera opened. Surveillance running.")

    while True:
        cap, frame = safe_read(cap, CAMERA_URL)
        if frame is None:
            time.sleep(0.5)
            continue

        frame_count += 1
        frame_alerts = []
        timestamp    = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # ── STEP 1: Detect persons with YOLOv8n ──────────────────
        yolo_results  = yolo_model(frame, classes=[0], verbose=False, device=0)
        person_boxes  = []
        for result in yolo_results:
            for box in result.boxes:
                if box.conf[0] > 0.4:
                    person_boxes.append(box.xyxy[0].cpu().numpy())

        people_count = len(person_boxes)

        # ── STEP 2: Face recognition for each detected person ─────
        # Run InsightFace on full frame (it finds faces internally)
        try:
            faces = face_app.get(frame)
        except Exception as e:
            log.error(f"InsightFace error: {e}")
            faces = []

        for face in faces:
            embedding  = face.normed_embedding
            bbox       = face.bbox   # [x1, y1, x2, y2]
            age        = getattr(face, "age", None)
            gender     = getattr(face, "gender", None)

            # ── STEP 2a: Check if person is BLOCKED ──────────────
            blocked_id, sim = match_face(embedding, blocked_cache, FACE_MATCH_THRESHOLD)

            if blocked_id:
                # BLOCKED PERSON DETECTED
                log.warning(f"🚨 BLOCKED PERSON DETECTED — {blocked_id} (similarity: {sim:.2f})")
                evidence_path = save_face_crop(frame, bbox, blocked_id, tag="BLOCKED")
                full_evidence = save_frame_evidence(frame, "blocked_entry")

                alert = {
                    "type":      "BLOCKED_PERSON_ENTRY",
                    "person_id": blocked_id,
                    "similarity": round(sim, 3),
                    "timestamp": timestamp,
                    "evidence":  evidence_path,
                    "message":   f"⚠️ Blocked person {blocked_id} entered the store!"
                }
                frame_alerts.append(alert)

                # Log incident
                log_incident(
                    person_id       = blocked_id,
                    incident_type   = "BLOCKED_ENTRY",
                    description     = f"Blocked person re-entered. Similarity: {sim:.3f}",
                    evidence_path   = full_evidence,
                    frame_number    = frame_count,
                    is_blocked_entry = True
                )

            else:
                # ── STEP 2b: Get or create person profile ─────────
                face_crop_path = save_face_crop(frame, bbox, f"frame{frame_count}", tag="face")
                person_id, is_new = get_or_create_person(embedding, face_crop_path, age, gender)

                if is_new:
                    log.info(f"👤 New visitor detected: {person_id}")
                else:
                    log.info(f"👀 Returning visitor: {person_id}")

        # ── STEP 3: Anomaly detection (every N frames) ────────────
        anomaly_result = {"description": "", "status": "normal", "anomaly_type": None}

        if frame_count % ANOMALY_EVERY_N_FRAMES == 0 or people_count > 0:
            anomaly_result = detect_anomaly(frame, frame_count, people_count)
            log.info(f"[Frame {frame_count}] Status: {anomaly_result['status'].upper()} | {anomaly_result['description'][:80]}")

            # If anomaly detected, save evidence and log
            if anomaly_result["status"] in ("medium", "risk"):
                evidence_path = save_frame_evidence(frame, anomaly_result["status"])

                # Try to link to most recently seen person if available
                linked_person = None
                if faces:
                    # Link to first face seen in this frame
                    linked_emb  = faces[0].normed_embedding
                    all_persons = list(col_people.find({}, {"person_id": 1, "embedding": 1, "_id": 0}))
                    linked_person, _ = match_face(linked_emb, all_persons, FACE_MATCH_THRESHOLD)

                if anomaly_result["status"] == "risk":
                    alert = {
                        "type":         "ANOMALY",
                        "anomaly_type": anomaly_result["anomaly_type"],
                        "description":  anomaly_result["description"],
                        "person_id":    linked_person,
                        "timestamp":    timestamp,
                        "evidence":     evidence_path,
                        "message":      f"🚨 RISK DETECTED: {anomaly_result['anomaly_type']}"
                    }
                    frame_alerts.append(alert)

                    if linked_person:
                        log_incident(
                            person_id     = linked_person,
                            incident_type = anomaly_result["anomaly_type"] or "RISK",
                            description   = anomaly_result["description"],
                            evidence_path = evidence_path,
                            frame_number  = frame_count
                        )

        # ── STEP 4: Update live data for WebSocket clients ────────
        latest_data = {
            "frame_number": frame_count,
            "timestamp":    timestamp,
            "people_count": people_count,
            "faces_found":  len(faces),
            "description":  anomaly_result["description"] or "Monitoring...",
            "status":       anomaly_result["status"],
            "anomaly_type": anomaly_result["anomaly_type"],
            "alerts":       frame_alerts
        }

        # Small delay to avoid GPU overload
        time.sleep(0.05)


# ──────────────────────────────────────────────
#  WEBSOCKET SERVER
# ──────────────────────────────────────────────

async def ws_handler(websocket, path):
    connected_clients.add(websocket)
    log.info(f"🔌 WebSocket client connected ({len(connected_clients)} total)")
    last_sent = None
    try:
        while True:
            if latest_data != last_sent:
                await websocket.send(json.dumps(latest_data))
                last_sent = dict(latest_data)
            await asyncio.sleep(0.3)
    except websockets.exceptions.ConnectionClosed:
        log.info("🔌 WebSocket client disconnected")
    finally:
        connected_clients.discard(websocket)


async def start_ws_server():
    async with websockets.serve(ws_handler, WEBSOCKET_HOST, WEBSOCKET_PORT):
        log.info(f"✅ WebSocket server: ws://{WEBSOCKET_HOST}:{WEBSOCKET_PORT}")
        await asyncio.Future()


# ──────────────────────────────────────────────
#  UTILITY: Block a person by ID (run manually)
# ──────────────────────────────────────────────

def manual_block(person_id: str, reason: str = "Suspicious behavior"):
    """
    Call this function manually to block a person.
    Example: manual_block("P20240101120000123456", "Shoplifting confirmed")
    """
    block_person(person_id, reason)
    log.warning(f"🚫 Manually blocked: {person_id}")


# ──────────────────────────────────────────────
#  UTILITY: List all persons in DB
# ──────────────────────────────────────────────

def list_persons():
    persons = list(col_people.find({}, {"person_id": 1, "first_seen": 1,
                                        "visit_count": 1, "is_blocked": 1, "_id": 0}))
    for p in persons:
        status = "🚫 BLOCKED" if p.get("is_blocked") else "✅ OK"
        print(f"{status} | {p['person_id']} | visits: {p.get('visit_count', 1)} | first: {p.get('first_seen', '')[:16]}")


# ──────────────────────────────────────────────
#  ENTRY POINT
# ──────────────────────────────────────────────

if __name__ == "__main__":
    log.info("=" * 60)
    log.info("  SUPERMARKET SURVEILLANCE — Starting Up")
    log.info("=" * 60)
    log.info(f"  Ollama Model : {OLLAMA_MODEL}")
    log.info(f"  Camera       : {CAMERA_URL}")
    log.info(f"  MongoDB      : {MONGO_URI[:40]}...")
    log.info(f"  Evidence Dir : {EVIDENCE_DIR}/")
    log.info(f"  WebSocket    : ws://{WEBSOCKET_HOST}:{WEBSOCKET_PORT}")
    log.info("=" * 60)

    # Start surveillance in background thread
    t = threading.Thread(target=surveillance_loop, daemon=True)
    t.start()

    # Run WebSocket server on main thread
    try:
        asyncio.run(start_ws_server())
    except KeyboardInterrupt:
        log.info("🛑 Surveillance stopped by user.")
