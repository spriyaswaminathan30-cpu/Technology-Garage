import base64
import cv2
import datetime
import face_recognition
import json
import math
import numpy as np
import os
import requests
import threading
import time
import uuid

from pathlib import Path

# =========================================================
# CONFIG
# =========================================================

OLLAMA_URL = "http://localhost:11434/api/generate"

OLLAMA_MODEL = "llava"

EMBEDDING_THRESHOLD = 0.5

TRACK_MAX_DRIFT = 80

TRACK_LOST_FRAMES = 15

AI_ANALYSIS_INTERVAL = 5

CAMERA_SOURCES = ["0"]

# =========================================================
# DATA PATHS
# =========================================================

BASE_DIR = Path(__file__).parent

DATA_DIR = BASE_DIR / "data"

FACES_DIR = DATA_DIR / "faces"

PERSONS_FILE = DATA_DIR / "persons.json"

AI_EVENTS_FILE = DATA_DIR / "ai_events.json"

ACCESS_FILE = DATA_DIR / "access_status.json"

DATA_DIR.mkdir(exist_ok=True)

FACES_DIR.mkdir(exist_ok=True)

# =========================================================
# PROMPT
# =========================================================

PROMPT = """
You are an AI monitoring a supermarket CCTV camera.

Analyze this frame carefully.

Context: {people_count} person(s) visible in the frame.
Frame number: {frame_number}

Look for the following and describe in 2 sentences:

1. SHOPLIFTING — hiding items in bags, pockets, clothing, or under cart
2. AGGRESSIVE BEHAVIOR — fighting, pushing, threatening, arguments
3. SLIP / FALL — person on ground, slipping, tripping
4. LOITERING — person standing still in one spot for a long time
5. THEFT FROM DISPLAY — removing items from shelves abnormally
6. NORMAL SHOPPING — if nothing suspicious is happening, say so

At the end of your response, on a new line, write exactly one of:

STATUS: NORMAL
STATUS: MEDIUM
STATUS: RISK

If STATUS is MEDIUM or RISK, also write:

ANOMALY: <one word describing the type>
"""

# =========================================================
# LOCK
# =========================================================

lock = threading.Lock()

# =========================================================
# JSON HELPERS
# =========================================================

def read_json(path):

    if not path.exists():
        return {}

    with open(path, "r") as f:
        return json.load(f)

def write_json(path, data):

    with open(path, "w") as f:
        json.dump(data, f, indent=2)

# =========================================================
# PERSON MANAGEMENT
# =========================================================

def load_persons():

    with lock:
        return read_json(PERSONS_FILE)

def save_face(frame, location, name):

    top, right, bottom, left = location

    pad = 20

    h, w = frame.shape[:2]

    top = max(0, top - pad)
    left = max(0, left - pad)

    bottom = min(h, bottom + pad)
    right = min(w, right + pad)

    face = frame[top:bottom, left:right]

    filename = f"{name}.jpg"

    filepath = FACES_DIR / filename

    cv2.imwrite(str(filepath), face)

    return str(filepath)

def register_person(encoding, frame, location):

    persons = load_persons()

    for pid, pdata in persons.items():

        known = np.array(pdata["encoding"])

        dist = face_recognition.face_distance(
            [known],
            encoding
        )[0]

        if dist <= EMBEDDING_THRESHOLD:

            return pid, pdata["name"], False

    pid = str(uuid.uuid4())

    name = f"Person-{pid[:8]}"

    image_path = save_face(
        frame,
        location,
        name
    )

    persons[pid] = {
        "id": pid,
        "name": name,
        "encoding": encoding.tolist(),
        "face_image": image_path,
        "created_at": str(datetime.datetime.now())
    }

    with lock:
        write_json(PERSONS_FILE, persons)

    return pid, name, True

# =========================================================
# ACCESS STATUS
# =========================================================

def get_status(pid):

    data = read_json(ACCESS_FILE)

    return data.get(pid, {}).get("status", "allow")

def set_status(pid, name, status):

    data = read_json(ACCESS_FILE)

    data[pid] = {
        "name": name,
        "status": status,
        "updated_at": str(datetime.datetime.now())
    }

    write_json(ACCESS_FILE, data)

# =========================================================
# AI BACKEND
# =========================================================

class AIBackend:

    def frame_to_base64(self, frame):

        _, buffer = cv2.imencode(".jpg", frame)

        return base64.b64encode(buffer).decode()

    # =====================================================

    def analyze(self, frame, people_count, frame_number):

        prompt = PROMPT.format(
            people_count=people_count,
            frame_number=frame_number
        )

        image_b64 = self.frame_to_base64(frame)

        payload = {
            "model": OLLAMA_MODEL,
            "prompt": prompt,
            "images": [image_b64],
            "stream": False
        }

        try:

            response = requests.post(
                OLLAMA_URL,
                json=payload,
                timeout=120
            )

            data = response.json()

            return data.get("response", "")

        except Exception as e:

            return f"STATUS: NORMAL\nERROR: {e}"

# =========================================================
# TRACK CLASS
# =========================================================

class Track:

    def __init__(self, pid, name, centroid):

        self.pid = pid

        self.name = name

        self.centroid = centroid

        self.lost = 0

# =========================================================
# CAMERA WORKER
# =========================================================

class CameraWorker(threading.Thread):

    def __init__(self, source):

        super().__init__(daemon=True)

        self.source = int(source)

        self.cap = cv2.VideoCapture(
            self.source,
            cv2.CAP_DSHOW
        )

        self.ai = AIBackend()

        self.tracks = []

        self.last_ai = 0

        self.frame_number = 0

    # =====================================================

    def centroid(self, loc):

        top, right, bottom, left = loc

        return (
            (left + right) / 2,
            (top + bottom) / 2
        )

    # =====================================================

    def distance(self, a, b):

        return math.hypot(
            a[0] - b[0],
            a[1] - b[1]
        )

    # =====================================================

    def find_track(self, centroid):

        best_track = None

        best_distance = 999999

        for track in self.tracks:

            d = self.distance(
                track.centroid,
                centroid
            )

            if d < TRACK_MAX_DRIFT and d < best_distance:

                best_track = track

                best_distance = d

        return best_track

    # =====================================================

    def process_ai_response(self, response):

        print("\n========== AI ANALYSIS ==========")

        print(response)

        print("=================================\n")

        status = "NORMAL"

        anomaly = None

        for line in response.splitlines():

            line = line.strip()

            if line.startswith("STATUS:"):

                status = line.replace(
                    "STATUS:",
                    ""
                ).strip()

            if line.startswith("ANOMALY:"):

                anomaly = line.replace(
                    "ANOMALY:",
                    ""
                ).strip()

        data = read_json(AI_EVENTS_FILE)

        data.setdefault("events", []).append({
            "time": str(datetime.datetime.now()),
            "status": status,
            "anomaly": anomaly,
            "summary": response
        })

        write_json(AI_EVENTS_FILE, data)

        # AUTO BLOCK

        if status == "RISK":

            print("[ALERT] HIGH RISK DETECTED")

            for track in self.tracks:

                set_status(
                    track.pid,
                    track.name,
                    "block"
                )

    # =====================================================

    def run(self):

        if not self.cap.isOpened():

            print(f"[ERROR] Cannot open camera {self.source}")

            return

        while True:

            ret, frame = self.cap.read()

            if not ret:
                continue

            self.frame_number += 1

            # =============================================
            # Resize for speed
            # =============================================

            small_frame = cv2.resize(
                frame,
                (640, 360)
            )

            rgb = cv2.cvtColor(
                small_frame,
                cv2.COLOR_BGR2RGB
            )

            # =============================================
            # Face Detection
            # =============================================

            locations = face_recognition.face_locations(
                rgb,
                model="hog"
            )

            encodings = face_recognition.face_encodings(
                rgb,
                locations
            )

            labels = []

            matched_tracks = []

            # =============================================
            # Process Faces
            # =============================================

            for location, encoding in zip(locations, encodings):

                centroid = self.centroid(location)

                track = self.find_track(centroid)

                # =========================================
                # Existing Track
                # =========================================

                if track:

                    track.centroid = centroid

                    track.lost = 0

                    pid = track.pid

                    name = track.name

                # =========================================
                # New Person
                # =========================================

                else:

                    pid, name, is_new = register_person(
                        encoding,
                        small_frame,
                        location
                    )

                    track = Track(
                        pid,
                        name,
                        centroid
                    )

                    self.tracks.append(track)

                    if is_new:

                        print(f"[NEW PERSON] {name}")

                        set_status(
                            pid,
                            name,
                            "allow"
                        )

                matched_tracks.append(track)

                labels.append(name)

                status = get_status(pid)

                # =========================================
                # Draw Box
                # =========================================

                top, right, bottom, left = location

                color = (0, 255, 0)

                if status == "block":
                    color = (0, 0, 255)

                cv2.rectangle(
                    small_frame,
                    (left, top),
                    (right, bottom),
                    color,
                    2
                )

                cv2.putText(
                    small_frame,
                    f"{name} [{status}]",
                    (left, top - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    color,
                    2
                )

            # =============================================
            # Remove Lost Tracks
            # =============================================

            for track in self.tracks:

                if track not in matched_tracks:

                    track.lost += 1

            self.tracks = [
                t for t in self.tracks
                if t.lost < TRACK_LOST_FRAMES
            ]

            # =============================================
            # AI ANALYSIS
            # =============================================

            if time.time() - self.last_ai > AI_ANALYSIS_INTERVAL:

                ai_response = self.ai.analyze(
                    small_frame,
                    len(labels),
                    self.frame_number
                )

                self.process_ai_response(
                    ai_response
                )

                self.last_ai = time.time()

            # =============================================
            # Show Frame
            # =============================================

            cv2.imshow(
                f"AI CCTV Camera {self.source}",
                small_frame
            )

            key = cv2.waitKey(1)

            if key == ord("q"):
                break

        self.cap.release()

        cv2.destroyAllWindows()

# =========================================================
# MAIN
# =========================================================

def main():

    workers = []

    for source in CAMERA_SOURCES:

        worker = CameraWorker(source)

        worker.start()

        workers.append(worker)

    while True:
        time.sleep(1)

# =========================================================
# START
# =========================================================

if __name__ == "__main__":

    print("\nStarting AI CCTV System...\n")

    main()