"""
============================================================
  SUPERMARKET SURVEILLANCE SYSTEM — Pure Python Edition
  No AI Models Required. Fully Local. Free.
============================================================

WHAT THIS USES (all free, no AI model downloads):
  - OpenCV          — frame capture, motion, background subtraction
  - face_recognition (dlib) — face detection & 128-D embeddings
  - scipy           — cosine similarity for face matching
  - pymongo         — MongoDB storage
  - websockets      — real-time WebSocket server
  - numpy           — array math

INSTALL:
  pip install opencv-python numpy scipy pymongo websockets
  pip install face_recognition   (requires cmake + dlib, see note below)

NOTE on face_recognition install:
  Windows:  pip install cmake dlib face_recognition
  Ubuntu:   sudo apt install cmake libdlib-dev
            pip install face_recognition
  Mac:      brew install cmake dlib && pip install face_recognition

ANOMALY DETECTION (rule-based, no AI):
  - Motion level    (background subtraction pixel diff)
  - Dwell time      (person standing still > threshold)
  - Zone intrusion  (restricted areas defined by coordinates)
  - Speed anomaly   (moving too fast — running)
  - Crowd density   (too many people in one zone)

CAMERA:
  CAMERA_URL = 0              → webcam
  CAMERA_URL = "rtsp://..."   → IP/RTSP camera

============================================================
"""

import cv2
import numpy as np
import face_recognition
import json
import os
import time
import threading
import asyncio
import logging
import signal
from datetime import datetime
from scipy.spatial.distance import cosine
from pymongo import MongoClient
import websockets

# ──────────────────────────────────────────────
#  CONFIGURATION
# ──────────────────────────────────────────────

CAMERA_URL    = 0       # 0 = webcam, or "rtsp://user:pass@ip:port/..."
MONGO_URI     = "mongodb+srv://tgdev:technology-1@cluster0.0pefygc.mongodb.net/"
DB_NAME       = "supermarket_surveillance"

WEBSOCKET_HOST = "0.0.0.0"
WEBSOCKET_PORT = 8765

# Face matching — lower = stricter (0.0 to 1.0)
FACE_THRESHOLD = 0.45

# Anomaly thresholds (rule-based)
MOTION_THRESHOLD    = 3000   # pixel area — below = still, above = moving
DWELL_THRESHOLD_SEC = 30     # seconds stationary = suspicious loitering
SPEED_THRESHOLD     = 80     # pixels/frame — above = running
CROWD_LIMIT         = 6      # max persons in frame before crowd alert

# Restricted zones — list of (x1,y1,x2,y2) in pixels
# Set to [] to disable zone detection
# Example: staff-only area in top-right corner
RESTRICTED_ZONES = [
    # (500, 0, 800, 300),    # uncomment and set your pixel coordinates
]

EVIDENCE_DIR = "evidence"
os.makedirs(os.path.join(EVIDENCE_DIR, "photos"), exist_ok=True)
os.makedirs(os.path.join(EVIDENCE_DIR, "videos"), exist_ok=True)

# ──────────────────────────────────────────────
#  LOGGING
# ──────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(f"surveillance_{datetime.now().strftime('%Y%m%d')}.log")
    ]
)
log = logging.getLogger("surveillance")

# ──────────────────────────────────────────────
#  MONGODB SETUP
# ──────────────────────────────────────────────

mongo_client   = MongoClient(MONGO_URI)
db             = mongo_client[DB_NAME]
col_people     = db["people_profiles"]
col_blocked    = db["blocked_persons"]
col_incidents  = db["incidents"]

col_people.create_index("person_id", unique=True)
col_blocked.create_index("person_id", unique=True)

# ──────────────────────────────────────────────
#  GLOBALS
# ──────────────────────────────────────────────

connected_clients = set()
latest_data = {
    "frame_number": 0,
    "timestamp":    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "people_count": 0,
    "motion_level": 0,
    "status":       "normal",
    "alerts":       [],
    "description":  "System starting..."
}

blocked_cache = []        # in-memory blocked embeddings
person_tracker = {}       # track person positions across frames: {person_id: {frames: [], first_seen, last_pos}}
running = True

# ──────────────────────────────────────────────
#  SIGNAL HANDLER
# ──────────────────────────────────────────────

def shutdown(sig, frame):
    global running
    log.info("Shutdown signal received.")
    running = False

signal.signal(signal.SIGINT, shutdown)
signal.signal(signal.SIGTERM, shutdown)

# ──────────────────────────────────────────────
#  FACE RECOGNITION HELPERS
# ──────────────────────────────────────────────

def get_face_embeddings(frame_rgb):
    """
    Detect faces in frame and return list of dicts:
    {location: (top,right,bottom,left), encoding: 128-D numpy array}
    Uses dlib HOG detector — no AI model, runs on CPU.
    """
    locations  = face_recognition.face_locations(frame_rgb, model="hog")
    encodings  = face_recognition.face_encodings(frame_rgb, locations)
    results = []
    for loc, enc in zip(locations, encodings):
        results.append({"location": loc, "encoding": enc})
    return results

def cosine_sim(a, b):
    return 1 - cosine(np.array(a, dtype=np.float64), np.array(b, dtype=np.float64))

def match_embedding(query_enc, candidates, threshold):
    """Compare query against list of candidate dicts with 'encoding' key."""
    best_sim, best_id = 0.0, None
    for c in candidates:
        sim = cosine_sim(query_enc, c["encoding"])
        if sim > best_sim:
            best_sim = sim
            best_id  = c.get("person_id")
    if best_id and best_sim >= threshold:
        return best_id, best_sim
    return None, 0.0

# ──────────────────────────────────────────────
#  BLOCKED CACHE
# ──────────────────────────────────────────────

def refresh_blocked_cache():
    global blocked_cache
    blocked_cache = list(col_blocked.find(
        {}, {"person_id": 1, "encoding": 1, "name": 1, "_id": 0}
    ))
    log.info(f"Blocked cache: {len(blocked_cache)} person(s)")

# ──────────────────────────────────────────────
#  PERSON PROFILE MANAGEMENT
# ──────────────────────────────────────────────

def get_or_create_person(encoding: np.ndarray) -> tuple:
    """
    Match encoding against all profiles. Return (person_id, is_new).
    Creates a new profile doc if no match found.
    """
    all_persons = list(col_people.find({}, {"person_id": 1, "encoding": 1, "_id": 0}))
    matched_id, sim = match_embedding(encoding, all_persons, FACE_THRESHOLD)

    if matched_id:
        col_people.update_one(
            {"person_id": matched_id},
            {"$set": {"last_seen": datetime.now().isoformat()},
             "$inc": {"visit_count": 1}}
        )
        return matched_id, False
    else:
        pid = f"P{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        doc = {
            "person_id":   pid,
            "encoding":    encoding.tolist(),
            "first_seen":  datetime.now().isoformat(),
            "last_seen":   datetime.now().isoformat(),
            "visit_count": 1,
            "is_blocked":  False,
            "incidents":   []
        }
        col_people.insert_one(doc)
        log.info(f"New person profile: {pid}")
        return pid, True

def block_person(person_id: str, reason: str = "Suspicious behavior"):
    """Block a person — adds them to blocked_persons collection."""
    person = col_people.find_one({"person_id": person_id})
    if not person:
        log.warning(f"block_person: {person_id} not found")
        return
    doc = {
        "person_id":  person_id,
        "encoding":   person["encoding"],
        "name":       person.get("name", "Unknown"),
        "reason":     reason,
        "blocked_at": datetime.now().isoformat()
    }
    col_blocked.update_one({"person_id": person_id}, {"$set": doc}, upsert=True)
    col_people.update_one({"person_id": person_id},
                          {"$set": {"is_blocked": True, "block_reason": reason}})
    refresh_blocked_cache()
    log.warning(f"BLOCKED: {person_id} — {reason}")

# ──────────────────────────────────────────────
#  EVIDENCE SAVING
# ──────────────────────────────────────────────

def ts():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def save_photo(frame, label: str, person_id: str = None) -> str:
    name = f"{label}_{person_id+'_' if person_id else ''}{ts()}.jpg"
    path = os.path.join(EVIDENCE_DIR, "photos", name)
    cv2.imwrite(path, frame)
    log.info(f"Evidence photo: {path}")
    return path

def save_face_crop(frame, location, person_id: str, label: str = "face") -> str:
    top, right, bottom, left = location
    pad  = 20
    h, w = frame.shape[:2]
    crop = frame[max(0, top-pad):min(h, bottom+pad),
                 max(0, left-pad):min(w, right+pad)]
    path = os.path.join(EVIDENCE_DIR, "photos", f"{label}_{person_id}_{ts()}.jpg")
    cv2.imwrite(path, crop)
    return path

def save_video_clip(camera_url, label: str, seconds: int = 30):
    """Record a video clip in a background thread."""
    def _record():
        path = os.path.join(EVIDENCE_DIR, "videos", f"{label}_{ts()}.mp4")
        cap  = cv2.VideoCapture(camera_url)
        fps  = int(cap.get(cv2.CAP_PROP_FPS)) or 20
        w    = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h    = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        out  = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
        total, count = fps * seconds, 0
        while count < total:
            ret, frm = cap.read()
            if ret:
                out.write(frm)
                count += 1
        out.release(); cap.release()
        log.info(f"Video clip saved: {path}")
    threading.Thread(target=_record, daemon=True).start()

# ──────────────────────────────────────────────
#  INCIDENT LOGGING
# ──────────────────────────────────────────────

def log_incident(person_id, incident_type, description, evidence_path, frame_number,
                 is_blocked_entry=False):
    severity = "HIGH" if is_blocked_entry or incident_type in ["RUNNING","ZONE_INTRUSION"] else "MEDIUM"
    incident = {
        "person_id":        person_id,
        "type":             incident_type,
        "description":      description,
        "evidence_image":   evidence_path,
        "frame_number":     frame_number,
        "timestamp":        datetime.now().isoformat(),
        "is_blocked_entry": is_blocked_entry,
        "severity":         severity
    }
    col_incidents.insert_one(incident)
    col_people.update_one(
        {"person_id": person_id},
        {"$push": {"incidents": {"type": incident_type,
                                 "timestamp": incident["timestamp"],
                                 "evidence":  evidence_path}}}
    )
    log.warning(f"Incident [{severity}] {incident_type} — {person_id}")

# ──────────────────────────────────────────────
#  BACKGROUND SUBTRACTOR (Motion Detection)
# ──────────────────────────────────────────────

bg_subtractor = cv2.createBackgroundSubtractorMOG2(
    history=500, varThreshold=50, detectShadows=False
)

def get_motion_level(frame) -> int:
    """Returns pixel area of detected motion in this frame."""
    fg_mask   = bg_subtractor.apply(frame)
    kernel    = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    fg_clean  = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(fg_clean, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    total_area = sum(cv2.contourArea(c) for c in contours if cv2.contourArea(c) > 200)
    return int(total_area)

def get_motion_boxes(frame):
    """Returns list of bounding boxes (x,y,w,h) for moving regions."""
    fg_mask   = bg_subtractor.apply(frame)
    kernel    = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    fg_clean  = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(fg_clean, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    boxes = []
    for c in contours:
        area = cv2.contourArea(c)
        if area > 800:   # filter small noise
            boxes.append(cv2.boundingRect(c))
    return boxes

# ──────────────────────────────────────────────
#  RULE-BASED ANOMALY DETECTION
# ──────────────────────────────────────────────

def check_zone_intrusion(motion_boxes):
    """Check if any motion box overlaps a restricted zone."""
    if not RESTRICTED_ZONES:
        return False, None
    for (mx, my, mw, mh) in motion_boxes:
        for (zx1, zy1, zx2, zy2) in RESTRICTED_ZONES:
            # Simple AABB overlap
            if mx < zx2 and mx+mw > zx1 and my < zy2 and my+mh > zy1:
                return True, (zx1, zy1, zx2, zy2)
    return False, None

def check_crowd(people_count: int):
    """Too many people in frame."""
    return people_count >= CROWD_LIMIT

def check_running(person_id: str, current_pos: tuple) -> bool:
    """
    Track person position history. If displacement per frame > threshold → running.
    current_pos = (cx, cy) center point
    """
    if person_id not in person_tracker:
        person_tracker[person_id] = {"positions": [], "first_seen": time.time()}
    tracker = person_tracker[person_id]
    tracker["positions"].append({"pos": current_pos, "time": time.time()})
    # Keep last 10 positions
    if len(tracker["positions"]) > 10:
        tracker["positions"].pop(0)
    if len(tracker["positions"]) >= 2:
        p1 = tracker["positions"][-2]["pos"]
        p2 = tracker["positions"][-1]["pos"]
        dist = np.sqrt((p2[0]-p1[0])**2 + (p2[1]-p1[1])**2)
        if dist > SPEED_THRESHOLD:
            return True
    return False

def check_loitering(person_id: str, current_pos: tuple) -> bool:
    """
    If person has barely moved in DWELL_THRESHOLD_SEC seconds → loitering.
    """
    if person_id not in person_tracker:
        person_tracker[person_id] = {"positions": [], "first_seen": time.time()}
    tracker = person_tracker[person_id]

    if not tracker["positions"]:
        tracker["positions"].append({"pos": current_pos, "time": time.time()})
        return False

    # Check distance from oldest tracked position
    oldest    = tracker["positions"][0]
    elapsed   = time.time() - oldest["time"]
    dist      = np.sqrt((current_pos[0]-oldest["pos"][0])**2 +
                        (current_pos[1]-oldest["pos"][1])**2)

    if elapsed > DWELL_THRESHOLD_SEC and dist < 50:
        return True
    return False

def get_anomaly_status(motion_level, motion_boxes, motion_count):
    """
    Pure rule-based status: normal / medium / risk
    Returns (status, anomaly_type, description)
    """
    # High motion = risk
    if motion_level > MOTION_THRESHOLD * 4:
        return "risk", "HIGH_MOTION", f"Very high motion detected — area: {motion_level}px"
    # Zone intrusion
    intruded, zone = check_zone_intrusion(motion_boxes)
    if intruded:
        return "risk", "ZONE_INTRUSION", f"Motion in restricted zone {zone}"
    # Crowd
    if check_crowd(motion_count):
        return "medium", "CROWD", f"Crowd detected: {motion_count} moving regions"
    # Medium motion
    if motion_level > MOTION_THRESHOLD:
        return "medium", "MOTION", f"Elevated motion — area: {motion_level}px"
    return "normal", None, "Normal activity"

# ──────────────────────────────────────────────
#  CAMERA HELPERS
# ──────────────────────────────────────────────

def open_camera(url):
    log.info(f"Opening camera: {url}")
    cap = cv2.VideoCapture(url) if isinstance(url, int) \
          else cv2.VideoCapture(url, cv2.CAP_FFMPEG)
    if cap.isOpened():
        fps = cap.get(cv2.CAP_PROP_FPS)
        w   = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h   = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        log.info(f"Camera: {w}x{h} @ {fps:.1f}fps")
    else:
        log.error("Failed to open camera!")
    return cap

def safe_read(cap, url):
    ret, frame = cap.read()
    if not ret:
        log.warning("Frame read failed — reconnecting...")
        cap.release()
        time.sleep(1)
        cap = open_camera(url)
        ret, frame = cap.read()
        if not ret:
            return cap, None
    return cap, frame

# ──────────────────────────────────────────────
#  DRAW OVERLAYS
# ──────────────────────────────────────────────

def draw_overlay(frame, status, motion_level, people_count, alerts):
    color_map = {"normal": (0,200,0), "medium": (0,165,255), "risk": (0,0,220)}
    color = color_map.get(status, (200,200,200))

    # Status bar at top
    cv2.rectangle(frame, (0,0), (frame.shape[1], 50), (30,30,30), -1)
    cv2.putText(frame, f"Status: {status.upper()}  |  Motion: {motion_level}  |  People: {people_count}",
                (10,32), cv2.FONT_HERSHEY_SIMPLEX, 0.75, color, 2)

    # Draw restricted zones
    for (zx1, zy1, zx2, zy2) in RESTRICTED_ZONES:
        cv2.rectangle(frame, (zx1,zy1), (zx2,zy2), (0,0,255), 2)
        cv2.putText(frame, "RESTRICTED", (zx1+4, zy1+20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,255), 2)

    # Active alerts
    for i, alert in enumerate(alerts[:3]):
        cv2.putText(frame, f"ALERT: {alert.get('message','')[:60]}",
                    (10, 80 + i*25), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0,0,255), 2)

    return frame

# ──────────────────────────────────────────────
#  WEBSOCKET
# ──────────────────────────────────────────────

async def ws_handler(websocket, path):
    connected_clients.add(websocket)
    log.info(f"WS client connected ({len(connected_clients)} total)")
    last_sent = None
    try:
        while True:
            if latest_data != last_sent:
                await websocket.send(json.dumps(latest_data))
                last_sent = dict(latest_data)
            await asyncio.sleep(0.3)
    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        connected_clients.discard(websocket)

async def start_ws_server():
    async with websockets.serve(ws_handler, WEBSOCKET_HOST, WEBSOCKET_PORT):
        log.info(f"WebSocket: ws://{WEBSOCKET_HOST}:{WEBSOCKET_PORT}")
        await asyncio.Future()

# ──────────────────────────────────────────────
#  MAIN SURVEILLANCE LOOP
# ──────────────────────────────────────────────

def surveillance_loop():
    global latest_data, running

    refresh_blocked_cache()
    cap         = open_camera(CAMERA_URL)
    frame_count = 0
    # Process face recognition every N frames (face_recognition is slower than YOLO)
    FACE_EVERY  = 5

    log.info("Surveillance loop started.")

    while running:
        cap, frame = safe_read(cap, CAMERA_URL)
        if frame is None:
            time.sleep(0.5)
            continue

        frame_count += 1
        ts_str      = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        frame_alerts = []

        # ── STEP 1: Motion detection (every frame, fast) ───────
        motion_level  = get_motion_level(frame)
        motion_boxes  = get_motion_boxes(frame)
        motion_count  = len(motion_boxes)

        # Draw motion boxes
        for (x, y, w, h) in motion_boxes:
            cv2.rectangle(frame, (x,y), (x+w, y+h), (0,255,255), 1)

        # Rule-based anomaly check
        status, anomaly_type, description = get_anomaly_status(
            motion_level, motion_boxes, motion_count
        )

        # ── STEP 2: Face recognition (every FACE_EVERY frames) ─
        face_count = 0
        if frame_count % FACE_EVERY == 0 and motion_level > 500:
            # Downscale for speed, then scale locations back up
            scale       = 0.5
            small_frame = cv2.resize(frame, (0,0), fx=scale, fy=scale)
            rgb_small   = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
            faces       = get_face_embeddings(rgb_small)
            face_count  = len(faces)

            for face in faces:
                top, right, bottom, left = [int(v/scale) for v in face["location"]]
                enc = face["encoding"]

                # ── Check blocked ──────────────────────────────
                blocked_id, sim = match_embedding(enc, blocked_cache, FACE_THRESHOLD)
                if blocked_id:
                    log.warning(f"BLOCKED PERSON: {blocked_id} (sim={sim:.2f})")
                    cv2.rectangle(frame, (left,top), (right,bottom), (0,0,255), 3)
                    cv2.putText(frame, f"BLOCKED {blocked_id[:8]}", (left, top-8),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,255), 2)

                    ev_path = save_face_crop(frame, (top,right,bottom,left),
                                             blocked_id, label="BLOCKED")
                    save_photo(frame, "blocked_entry", blocked_id)

                    alert = {
                        "type":      "BLOCKED_ENTRY",
                        "person_id": blocked_id,
                        "similarity": round(sim, 3),
                        "message":   f"Blocked person {blocked_id[:12]} re-entered store!",
                        "timestamp": ts_str
                    }
                    frame_alerts.append(alert)
                    status = "risk"

                    log_incident(blocked_id, "BLOCKED_ENTRY",
                                 f"Blocked person re-entered. Similarity: {sim:.3f}",
                                 ev_path, frame_count, is_blocked_entry=True)

                else:
                    # ── Get or create profile ──────────────────
                    person_id, is_new = get_or_create_person(enc)
                    label = "NEW" if is_new else "KNOWN"
                    color = (255,180,0) if is_new else (0,200,0)

                    cv2.rectangle(frame, (left,top), (right,bottom), color, 2)
                    cv2.putText(frame, f"{label} {person_id[:8]}", (left, top-8),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

                    # Center point for movement tracking
                    cx, cy = (left+right)//2, (top+bottom)//2

                    # ── Check running ──────────────────────────
                    if check_running(person_id, (cx,cy)):
                        log.warning(f"RUNNING detected: {person_id}")
                        ev = save_photo(frame, "RUNNING", person_id)
                        frame_alerts.append({
                            "type": "RUNNING", "person_id": person_id,
                            "message": f"Person {person_id[:10]} running in store",
                            "timestamp": ts_str
                        })
                        if status != "risk":
                            status = "medium"
                        log_incident(person_id, "RUNNING",
                                     "Person moving at high speed", ev, frame_count)

                    # ── Check loitering ────────────────────────
                    if check_loitering(person_id, (cx,cy)):
                        log.info(f"LOITERING detected: {person_id}")
                        ev = save_photo(frame, "LOITERING", person_id)
                        frame_alerts.append({
                            "type": "LOITERING", "person_id": person_id,
                            "message": f"Person {person_id[:10]} loitering",
                            "timestamp": ts_str
                        })
                        if status == "normal":
                            status = "medium"
                        log_incident(person_id, "LOITERING",
                                     f"Stationary for >{DWELL_THRESHOLD_SEC}s", ev, frame_count)

        # ── STEP 3: Zone intrusion evidence ────────────────────
        if anomaly_type == "ZONE_INTRUSION":
            ev = save_photo(frame, "ZONE_INTRUSION")
            frame_alerts.append({
                "type": "ZONE_INTRUSION",
                "message": "Motion in restricted zone!",
                "timestamp": ts_str
            })

        # ── STEP 4: Risk evidence capture ──────────────────────
        if status == "risk" and anomaly_type:
            save_photo(frame, f"risk_{anomaly_type}")

        # ── STEP 5: Update WebSocket data ──────────────────────
        latest_data = {
            "frame_number": frame_count,
            "timestamp":    ts_str,
            "people_count": face_count,
            "motion_level": motion_level,
            "status":       status,
            "anomaly_type": anomaly_type,
            "description":  description,
            "alerts":       frame_alerts
        }

        if frame_count % 100 == 0:
            log.info(f"Frame {frame_count} | Status: {status.upper()} | Motion: {motion_level}")

        # ── Draw and display ────────────────────────────────────
        display = draw_overlay(frame.copy(), status, motion_level, face_count, frame_alerts)
        cv2.imshow("Supermarket Surveillance — Pure Python", display)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        time.sleep(0.03)   # ~30 FPS cap

    cap.release()
    cv2.destroyAllWindows()
    log.info("Surveillance stopped.")

# ──────────────────────────────────────────────
#  UTILITY FUNCTIONS
# ──────────────────────────────────────────────

def manual_block(person_id: str, reason: str = "Manual block"):
    """Call this to block a person by ID."""
    block_person(person_id, reason)

def list_persons():
    """Print all detected persons."""
    print("\n=== Person Profiles ===")
    for p in col_people.find({}, {"person_id":1,"visit_count":1,"is_blocked":1,"_id":0}):
        icon = "🚫" if p.get("is_blocked") else "✅"
        print(f"{icon} {p['person_id']} | visits: {p.get('visit_count',1)}")

def list_incidents(limit=20):
    """Print recent incidents."""
    print("\n=== Recent Incidents ===")
    for i in col_incidents.find({},{"_id":0}).sort("timestamp",-1).limit(limit):
        print(f"[{i.get('severity','?'):6}] {i['type']:16} | {i['person_id']} | {i['timestamp'][:16]}")

# ──────────────────────────────────────────────
#  ENTRY POINT
# ──────────────────────────────────────────────

if __name__ == "__main__":
    log.info("=" * 58)
    log.info("  SUPERMARKET SURVEILLANCE — Pure Python Edition")
    log.info("=" * 58)
    log.info(f"  Camera       : {CAMERA_URL}")
    log.info(f"  MongoDB      : {MONGO_URI[:35]}...")
    log.info(f"  Evidence Dir : {EVIDENCE_DIR}/")
    log.info(f"  WebSocket    : ws://{WEBSOCKET_HOST}:{WEBSOCKET_PORT}")
    log.info(f"  Face Thresh  : {FACE_THRESHOLD}")
    log.info(f"  Motion Thresh: {MOTION_THRESHOLD}px")
    log.info(f"  Dwell Limit  : {DWELL_THRESHOLD_SEC}s")
    log.info("=" * 58)

    # Surveillance runs in background thread
    t = threading.Thread(target=surveillance_loop, daemon=True)
    t.start()

    # WebSocket server on main thread
    try:
        asyncio.run(start_ws_server())
    except KeyboardInterrupt:
        log.info("Stopped by user.")
