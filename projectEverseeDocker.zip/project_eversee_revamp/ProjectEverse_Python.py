import datetime
import json
import math
import os
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import face_recognition
import numpy as np

# ─────────────────────────────────────────────────────────────
# Paths
# ─────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
FACES_DIR = DATA_DIR / "faces"
PERSONS_FILE = DATA_DIR / "persons.json"
ACCESS_STATUS_FILE = DATA_DIR / "access_status.json"
EVENTS_FILE = DATA_DIR / "events.json"

DATA_DIR.mkdir(exist_ok=True)
FACES_DIR.mkdir(exist_ok=True)

# ─────────────────────────────────────────────────────────────
# Config  (all overridable via env vars)
# ─────────────────────────────────────────────────────────────
EMBEDDING_THRESHOLD: float = float(os.getenv("EMBEDDING_THRESHOLD", "0.50"))
CAMERA_SOURCES: str = os.getenv("CAMERA_SOURCES", "0")

# Tracking
TRACK_MAX_DRIFT: int = int(os.getenv("TRACK_MAX_DRIFT", "80"))        # pixels
TRACK_LOST_FRAMES: int = int(os.getenv("TRACK_LOST_FRAMES", "15"))    # frames before eviction

# Behaviour rules
LOITER_SECONDS: int = int(os.getenv("LOITER_SECONDS", "60"))          # seconds on-screen → flag
RAPID_MOVE_PX: int = int(os.getenv("RAPID_MOVE_PX", "120"))           # px jump in one frame
REENTRY_COOLDOWN: int = int(os.getenv("REENTRY_COOLDOWN", "30"))      # seconds
STRIKE_LIMIT: int = int(os.getenv("STRIKE_LIMIT", "3"))               # strikes → block


def cameras() -> List[str]:
    return [s.strip() for s in CAMERA_SOURCES.split(",") if s.strip()]


# ─────────────────────────────────────────────────────────────
# Thread-safe JSON helpers
# ─────────────────────────────────────────────────────────────
_file_lock = threading.Lock()


def _read_json(path: Path) -> dict:
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _write_json(path: Path, data: dict):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)


# ─────────────────────────────────────────────────────────────
# persons.json
# ─────────────────────────────────────────────────────────────

def load_persons() -> dict:
    with _file_lock:
        return _read_json(PERSONS_FILE)


def log_detection(person_id: str):
    with _file_lock:
        persons = _read_json(PERSONS_FILE)
        if person_id in persons:
            persons[person_id].setdefault("detections", []).append(
                {"timestamp": datetime.datetime.now().isoformat()}
            )
            _write_json(PERSONS_FILE, persons)


def register_person_if_new(
    encoding: np.ndarray,
    frame,
    location: tuple,
    threshold: float,
) -> Tuple[Optional[str], Optional[str], bool]:
    """
    Returns (person_id, name, is_new).
    Saves face image then acquires lock to avoid duplicate registration.
    """
    pid = str(uuid.uuid4())
    name = f"Person-{pid[:8]}"
    face_img_path = save_face_image(frame, location, name, pid)

    with _file_lock:
        persons = _read_json(PERSONS_FILE)
        if persons:
            known_encs = [np.array(p["encoding"]) for p in persons.values()]
            dists = face_recognition.face_distance(known_encs, encoding)
            best_idx = int(np.argmin(dists))
            if float(dists[best_idx]) <= threshold:
                img_full = DATA_DIR / face_img_path
                if img_full.exists():
                    img_full.unlink()
                matched = list(persons.values())[best_idx]
                return matched["id"], matched["name"], False

        now = datetime.datetime.now().isoformat()
        persons[pid] = {
            "id": pid,
            "name": name,
            "face_image": face_img_path,
            "encoding": encoding.tolist(),
            "created_at": now,
            "detections": [{"timestamp": now}],
        }
        _write_json(PERSONS_FILE, persons)

    return pid, name, True


# ─────────────────────────────────────────────────────────────
# access_status.json
# ─────────────────────────────────────────────────────────────

def load_access_status() -> dict:
    with _file_lock:
        return _read_json(ACCESS_STATUS_FILE)


def save_access_status(status: dict):
    with _file_lock:
        _write_json(ACCESS_STATUS_FILE, status)


def set_access_status(person_id: str, name: str, status: str = "allow"):
    access = load_access_status()
    access[person_id] = {
        "name": name,
        "status": status,
        "updated_at": datetime.datetime.now().isoformat(),
    }
    save_access_status(access)


def get_status(person_id: str) -> str:
    access = load_access_status()
    return access.get(person_id, {}).get("status", "allow")


# ─────────────────────────────────────────────────────────────
# events.json  (behaviour log)
# ─────────────────────────────────────────────────────────────

def append_event(person_id: str, name: str, event_type: str, detail: str = ""):
    with _file_lock:
        events = _read_json(EVENTS_FILE)
        events.setdefault(person_id, []).append({
            "timestamp": datetime.datetime.now().isoformat(),
            "event": event_type,
            "name": name,
            "detail": detail,
        })
        _write_json(EVENTS_FILE, events)


# ─────────────────────────────────────────────────────────────
# Face image helper
# ─────────────────────────────────────────────────────────────

def save_face_image(frame, location, name: str, person_id: str) -> str:
    top, right, bottom, left = location
    pad = 20
    h, w = frame.shape[:2]
    top, left = max(0, top - pad), max(0, left - pad)
    bottom, right = min(h, bottom + pad), min(w, right + pad)
    face_crop = frame[top:bottom, left:right]
    filename = f"{name}_{person_id[:8]}.jpg"
    filepath = FACES_DIR / filename
    cv2.imwrite(str(filepath), face_crop)
    return str(filepath.relative_to(DATA_DIR))


# ─────────────────────────────────────────────────────────────
# Active Track  (per-camera, in-memory only)
# ─────────────────────────────────────────────────────────────

def _centroid(location: tuple) -> Tuple[float, float]:
    top, right, bottom, left = location
    return ((left + right) / 2, (top + bottom) / 2)


def _dist(a: Tuple[float, float], b: Tuple[float, float]) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


@dataclass
class ActiveTrack:
    person_id: str
    name: str
    centroid: Tuple[float, float]
    lost_frames: int = 0          # how many consecutive frames without a match
    prev_centroid: Optional[Tuple[float, float]] = None


# ─────────────────────────────────────────────────────────────
# Session / Behaviour Monitor
# ─────────────────────────────────────────────────────────────

@dataclass
class SessionInfo:
    person_id: str
    name: str
    entry_time: datetime.datetime = field(default_factory=datetime.datetime.now)
    last_seen: datetime.datetime = field(default_factory=datetime.datetime.now)
    exit_time: Optional[datetime.datetime] = None
    frame_count: int = 0
    strikes: int = 0
    flags: List[str] = field(default_factory=list)       # e.g. ["LOITER","RAPID_MOVE"]
    centroid_history: deque = field(default_factory=lambda: deque(maxlen=30))


class BehaviourMonitor:
    """
    Purely Python rule engine – no AI model.
    Called every frame per active person.
    Accumulates strikes; at STRIKE_LIMIT it auto-blocks.
    """

    def __init__(self):
        # person_id → SessionInfo
        self._sessions: Dict[str, SessionInfo] = {}
        self._lock = threading.Lock()

    # ── public API ────────────────────────────────────────────

    def on_person_seen(self, person_id: str, name: str,
                       centroid: Tuple[float, float], prev_centroid: Optional[Tuple[float, float]]):
        with self._lock:
            sess = self._sessions.get(person_id)
            if sess is None:
                sess = SessionInfo(person_id=person_id, name=name)
                self._sessions[person_id] = sess
                append_event(person_id, name, "ENTRY")
            sess.last_seen = datetime.datetime.now()
            sess.frame_count += 1
            sess.centroid_history.append(centroid)
            self._evaluate(sess, centroid, prev_centroid)

    def on_person_lost(self, person_id: str):
        with self._lock:
            sess = self._sessions.get(person_id)
            if sess is not None:
                sess.exit_time = datetime.datetime.now()
                dwell = (sess.exit_time - sess.entry_time).total_seconds()
                append_event(person_id, sess.name, "EXIT",
                             f"dwell={dwell:.0f}s frames={sess.frame_count}")

    def get_session(self, person_id: str) -> Optional[SessionInfo]:
        with self._lock:
            return self._sessions.get(person_id)

    def recent_exits(self) -> Dict[str, datetime.datetime]:
        """person_id → exit_time for sessions that have ended."""
        with self._lock:
            return {pid: s.exit_time for pid, s in self._sessions.items()
                    if s.exit_time is not None}

    # ── rule evaluation ───────────────────────────────────────

    def _evaluate(self, sess: SessionInfo,
                  centroid: Tuple[float, float],
                  prev_centroid: Optional[Tuple[float, float]]):
        now = datetime.datetime.now()
        new_flags: List[str] = []

        # Rule 1 – LOITERING
        dwell = (now - sess.entry_time).total_seconds()
        if dwell >= LOITER_SECONDS and "LOITER" not in sess.flags:
            new_flags.append("LOITER")
            append_event(sess.person_id, sess.name, "ANOMALY",
                         f"Loitering detected dwell={dwell:.0f}s")

        # Rule 2 – RAPID MOVEMENT (erratic / running)
        if prev_centroid is not None:
            jump = _dist(centroid, prev_centroid)
            if jump >= RAPID_MOVE_PX and "RAPID_MOVE" not in sess.flags:
                new_flags.append("RAPID_MOVE")
                append_event(sess.person_id, sess.name, "ANOMALY",
                             f"Rapid movement detected jump={jump:.0f}px")

        # Rule 3 – REENTRY too soon after exit
        if sess.exit_time is not None:
            gap = (now - sess.exit_time).total_seconds()
            if gap < REENTRY_COOLDOWN and "REENTRY" not in sess.flags:
                new_flags.append("REENTRY")
                append_event(sess.person_id, sess.name, "ANOMALY",
                             f"Reentry after only {gap:.0f}s")
            # Reset exit so rule doesn't keep firing
            if gap >= REENTRY_COOLDOWN:
                sess.exit_time = None

        for flag in new_flags:
            sess.flags.append(flag)
            sess.strikes += 1
            print(f"[BEHAVIOUR] {sess.name} flag={flag} strikes={sess.strikes}/{STRIKE_LIMIT}")

        if sess.strikes >= STRIKE_LIMIT and get_status(sess.person_id) != "block":
            print(f"[AUTO-BLOCK] {sess.name} reached {STRIKE_LIMIT} strikes → blocking")
            set_access_status(sess.person_id, sess.name, "block")
            append_event(sess.person_id, sess.name, "AUTO_BLOCK",
                         f"strikes={sess.strikes}")


# ─────────────────────────────────────────────────────────────
# Face Recognizer
# ─────────────────────────────────────────────────────────────

class Recognizer:
    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold

    def detect_and_encode(self, rgb_frame) -> List[Dict]:
        locations = face_recognition.face_locations(rgb_frame, model="hog")
        encodings = face_recognition.face_encodings(rgb_frame, locations)
        return [{"location": loc, "encoding": enc}
                for loc, enc in zip(locations, encodings)]

    def best_match(self, encoding, known: List[Dict]) -> Tuple[Optional[Dict], Optional[float]]:
        if not known:
            return None, None
        encs = [np.array(p["encoding"]) for p in known]
        dists = face_recognition.face_distance(encs, encoding)
        best_idx = int(np.argmin(dists))
        best_dist = float(dists[best_idx])
        if best_dist <= self.threshold:
            return known[best_idx], best_dist
        return None, best_dist

    @staticmethod
    def draw_boxes(frame, locations, labels, statuses, flags_map: Dict[str, List[str]]):
        for (top, right, bottom, left), label, status in zip(locations, labels, statuses):
            color = (0, 255, 0) if status == "allow" else (0, 0, 255)
            cv2.rectangle(frame, (left, top), (right, bottom), color, 2)

            # Gather flags for display
            pid_flags = flags_map.get(label, [])
            flag_str = (" ⚠ " + ",".join(pid_flags)) if pid_flags else ""
            display = f"{label} [{status}]{flag_str}"
            cv2.putText(frame, display, (left, max(top - 10, 0)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 1)
        return frame


# ─────────────────────────────────────────────────────────────
# Camera Worker  (with per-camera active-track table)
# ─────────────────────────────────────────────────────────────

class CameraWorker(threading.Thread):
    def __init__(self, source, state: "AppState", monitor: BehaviourMonitor):
        super().__init__(daemon=True)
        self.source = source
        self.state = state
        self.monitor = monitor
        self.recognizer = Recognizer(EMBEDDING_THRESHOLD)
        self.stop_event = threading.Event()

        # Track table: list[ActiveTrack]
        self._tracks: List[ActiveTrack] = []

    # ── main loop ─────────────────────────────────────────────

    def run(self):
        cap = self._open_capture(self.source)
        if not cap.isOpened():
            print(f"[ERROR] Cannot open camera source: {self.source}")
            return

        while not self.stop_event.is_set() and not self.state.should_stop():
            ret, frame = cap.read()
            if not ret:
                cap.release()
                cap = self._open_capture(self.source)
                time.sleep(0.5)
                continue

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            faces = self.recognizer.detect_and_encode(rgb)

            # Load person DB once per frame
            persons = load_persons()
            known_list = [
                {"id": pid, "name": p["name"], "encoding": p["encoding"]}
                for pid, p in persons.items()
            ]

            # ── step 1: match each detected face to a track ───
            matched_track_ids: set[int] = set()   # indices into self._tracks
            labels, locations, statuses = [], [], []
            flags_map: Dict[str, List[str]] = {}  # name → flags (for overlay)

            for face in faces:
                loc = face["location"]
                enc = face["encoding"]
                cen = _centroid(loc)

                # 1a. Try to match to an existing ACTIVE track by centroid proximity
                track_idx = self._find_track(cen)

                if track_idx is not None:
                    # ── KNOWN TRACK: reuse identity, just update centroid ──
                    track = self._tracks[track_idx]
                    matched_track_ids.add(track_idx)
                    prev_cen = track.centroid
                    track.prev_centroid = prev_cen
                    track.centroid = cen
                    track.lost_frames = 0

                    pid, name = track.person_id, track.name
                    status = get_status(pid)
                    log_detection(pid)
                    self.monitor.on_person_seen(pid, name, cen, prev_cen)

                else:
                    # 1b. No track hit – run full recognition
                    match, _ = self.recognizer.best_match(enc, known_list)
                    if match is not None:
                        pid, name = match["id"], match["name"]
                        is_new = False
                    else:
                        pid, name, is_new = register_person_if_new(
                            enc, frame, loc, EMBEDDING_THRESHOLD
                        )
                        if is_new:
                            set_access_status(pid, name, "allow")
                            print(f"[NEW] {name} registered (id={pid[:8]})")
                        else:
                            log_detection(pid)

                    status = get_status(pid)

                    # Check reentry behaviour before creating track
                    recent = self.monitor.recent_exits()
                    if pid in recent and recent[pid] is not None:
                        gap = (datetime.datetime.now() - recent[pid]).total_seconds()
                        if gap < REENTRY_COOLDOWN:
                            print(f"[REENTRY] {name} re-entered after {gap:.0f}s")

                    # Create new track
                    new_track = ActiveTrack(person_id=pid, name=name, centroid=cen)
                    self._tracks.append(new_track)
                    matched_track_ids.add(len(self._tracks) - 1)
                    self.monitor.on_person_seen(pid, name, cen, None)

                # Collect overlay data
                sess = self.monitor.get_session(pid)
                flags = sess.flags if sess else []
                flags_map[name] = flags

                labels.append(name)
                locations.append(loc)
                statuses.append(status)

                if status == "block":
                    print(f"[ALERT] Blocked person on camera {self.source}: {name} (id={pid})")

            # ── step 2: age unmatched tracks ──────────────────
            for idx, track in enumerate(self._tracks):
                if idx not in matched_track_ids:
                    track.lost_frames += 1
                    if track.lost_frames >= TRACK_LOST_FRAMES:
                        self.monitor.on_person_lost(track.person_id)
                        print(f"[EXIT] {track.name} left camera {self.source}")

            # Evict old tracks
            self._tracks = [t for t in self._tracks if t.lost_frames < TRACK_LOST_FRAMES]

            # ── step 3: draw & publish frame ──────────────────
            frame = self.recognizer.draw_boxes(frame, locations, labels, statuses, flags_map)
            self.state.set_frame(self.source, frame)
            time.sleep(0.04)  # ~25 fps cap

        cap.release()

    # ── helpers ───────────────────────────────────────────────

    def _find_track(self, centroid: Tuple[float, float]) -> Optional[int]:
        """Return the index of the closest track within TRACK_MAX_DRIFT, or None."""
        best_idx, best_d = None, float("inf")
        for i, track in enumerate(self._tracks):
            d = _dist(centroid, track.centroid)
            if d < TRACK_MAX_DRIFT and d < best_d:
                best_d = d
                best_idx = i
        return best_idx

    def stop(self):
        self.stop_event.set()

    @staticmethod
    def _open_capture(source):
        if isinstance(source, int):
            cap = cv2.VideoCapture(source, cv2.CAP_DSHOW)
            if cap.isOpened():
                return cap
        return cv2.VideoCapture(source)


# ─────────────────────────────────────────────────────────────
# App State
# ─────────────────────────────────────────────────────────────

class AppState:
    def __init__(self):
        self._frames: Dict[str, np.ndarray] = {}
        self._lock = threading.Lock()
        self._stop = threading.Event()

    def set_frame(self, source, frame):
        with self._lock:
            self._frames[str(source)] = frame.copy()

    def get_frames(self):
        with self._lock:
            return {k: v.copy() for k, v in self._frames.items()}

    def request_stop(self):
        self._stop.set()

    def should_stop(self):
        return self._stop.is_set()


# ─────────────────────────────────────────────────────────────
# Entry point helpers
# ─────────────────────────────────────────────────────────────

def parse_source(source: str):
    return int(source) if source.isdigit() else source


def start_workers(state: AppState, monitor: BehaviourMonitor):
    workers = []
    for src in cameras():
        w = CameraWorker(parse_source(src), state, monitor)
        w.start()
        workers.append(w)
    return workers


def stop_workers(workers):
    for w in workers:
        w.stop()
    for w in workers:
        w.join(timeout=2.0)


# ─────────────────────────────────────────────────────────────
# __main__
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"Data dir  : {DATA_DIR}")
    print(f"Faces dir : {FACES_DIR}")
    print(f"Loiter threshold  : {LOITER_SECONDS}s")
    print(f"Rapid-move thresh : {RAPID_MOVE_PX}px")
    print(f"Reentry cooldown  : {REENTRY_COOLDOWN}s")
    print(f"Strike limit      : {STRIKE_LIMIT}")
    print("Press Q or Esc to quit.\n")

    state = AppState()
    monitor = BehaviourMonitor()
    workers = start_workers(state, monitor)

    try:
        while not state.should_stop():
            frames = state.get_frames()
            for src, frame in frames.items():
                cv2.imshow(f"Face Security – Camera {src}", frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), 27):
                state.request_stop()
            time.sleep(0.01)
    except KeyboardInterrupt:
        state.request_stop()
    finally:
        stop_workers(workers)
        cv2.destroyAllWindows()
        print("Stopped.")