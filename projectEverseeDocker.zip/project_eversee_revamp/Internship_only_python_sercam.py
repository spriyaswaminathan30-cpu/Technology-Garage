# ============================================================
# AI CCTV FACE SECURITY SYSTEM
# Improved CCTV Detection Version
# ============================================================

from __future__ import annotations

import cv2
import json
import time
import uuid
import math
import threading
import datetime
import numpy as np
import face_recognition

from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).parent

DATA_DIR = BASE_DIR / "data"

FACES_DIR = DATA_DIR / "faces"

PERSONS_FILE = DATA_DIR / "persons.json"

ACCESS_FILE = DATA_DIR / "access.json"

EVENTS_FILE = DATA_DIR / "events.json"

DATA_DIR.mkdir(exist_ok=True)

FACES_DIR.mkdir(exist_ok=True)

# ============================================================
# CAMERA SETTINGS
# ============================================================

CAMERA_SOURCES = [
    "rtsp://admin:EduServices%2301@192.168.29.100:554/cam/realmonitor?channel=1&subtype=0"
]

# ============================================================
# DETECTION SETTINGS
# ============================================================

FACE_MODEL = "hog"

FACE_MATCH_THRESHOLD = 0.50

FRAME_RESIZE = 1.0

MIN_FACE_WIDTH = 30

MIN_FACE_HEIGHT = 30

TRACK_DISTANCE = 100

TRACK_LOST_FRAMES = 20

BLUR_THRESHOLD = 40

# ============================================================
# BEHAVIOUR SETTINGS
# ============================================================

LOITER_SECONDS = 60

RAPID_MOVE_DISTANCE = 120

STRIKE_LIMIT = 3

# ============================================================
# JSON LOCK
# ============================================================

json_lock = threading.Lock()

# ============================================================
# JSON HELPERS
# ============================================================


def read_json(path):

    if not path.exists():
        return {}

    try:

        if path.stat().st_size == 0:
            return {}

        with open(path, "r", encoding="utf-8") as f:

            content = f.read().strip()

            if not content:
                return {}

            return json.loads(content)

    except Exception:

        print(f"[WARNING] Corrupted JSON: {path.name}")

        return {}


def write_json(path, data):

    try:

        temp = path.with_suffix(".tmp")

        with open(temp, "w", encoding="utf-8") as f:

            json.dump(
                data,
                f,
                indent=2,
                default=str
            )

        temp.replace(path)

    except Exception as e:

        print(f"[ERROR] JSON write failed: {e}")


# ============================================================
# FRAME VALIDATION
# ============================================================


def is_frame_valid(frame):

    if frame is None:
        return False

    if frame.size == 0:
        return False

    h, w = frame.shape[:2]

    if h < 100 or w < 100:
        return False

    return True


def is_blurry(frame):

    gray = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2GRAY
    )

    variance = cv2.Laplacian(
        gray,
        cv2.CV_64F
    ).var()

    return variance < BLUR_THRESHOLD


# ============================================================
# PERSON DATABASE
# ============================================================


def load_persons():

    with json_lock:

        return read_json(PERSONS_FILE)


def save_persons(data):

    with json_lock:

        write_json(PERSONS_FILE, data)


def save_face(frame, location, name, person_id):

    top, right, bottom, left = location

    padding = 20

    h, w = frame.shape[:2]

    top = max(0, top - padding)

    left = max(0, left - padding)

    bottom = min(h, bottom + padding)

    right = min(w, right + padding)

    crop = frame[top:bottom, left:right]

    if crop.size == 0:
        return None

    ch, cw = crop.shape[:2]

    if cw < MIN_FACE_WIDTH:
        return None

    if ch < MIN_FACE_HEIGHT:
        return None

    filename = f"{name}_{person_id[:8]}.jpg"

    filepath = FACES_DIR / filename

    cv2.imwrite(str(filepath), crop)

    return str(filepath.relative_to(DATA_DIR))


# ============================================================
# ACCESS CONTROL
# ============================================================


def load_access():

    with json_lock:

        return read_json(ACCESS_FILE)


def save_access(data):

    with json_lock:

        write_json(ACCESS_FILE, data)


def set_access(person_id, name, status="allow"):

    access = load_access()

    access[person_id] = {
        "name": name,
        "status": status,
        "updated_at": datetime.datetime.now().isoformat()
    }

    save_access(access)


def get_access(person_id):

    access = load_access()

    return access.get(
        person_id,
        {}
    ).get(
        "status",
        "allow"
    )


# ============================================================
# EVENT LOGGING
# ============================================================


def log_event(person_id, name, event, detail=""):

    with json_lock:

        events = read_json(EVENTS_FILE)

        events.setdefault(
            person_id,
            []
        ).append({
            "timestamp": datetime.datetime.now().isoformat(),
            "event": event,
            "name": name,
            "detail": detail
        })

        write_json(EVENTS_FILE, events)


# ============================================================
# TRACKING HELPERS
# ============================================================


def centroid(location):

    top, right, bottom, left = location

    return (
        (left + right) / 2,
        (top + bottom) / 2
    )


def distance(a, b):

    return math.hypot(
        a[0] - b[0],
        a[1] - b[1]
    )


# ============================================================
# TRACK CLASS
# ============================================================


@dataclass
class Track:

    person_id: str

    name: str

    center: Tuple[float, float]

    lost_frames: int = 0


# ============================================================
# RECOGNIZER
# ============================================================


class Recognizer:

    def __init__(self):

        self.threshold = FACE_MATCH_THRESHOLD

    def detect(self, rgb_frame):

        locations = face_recognition.face_locations(
            rgb_frame,
            model=FACE_MODEL
        )

        filtered = []

        h, w = rgb_frame.shape[:2]

        for loc in locations:

            top, right, bottom, left = loc

            fw = right - left

            fh = bottom - top

            if fw < MIN_FACE_WIDTH:
                continue

            if fh < MIN_FACE_HEIGHT:
                continue

            if top < 0 or left < 0:
                continue

            if right > w or bottom > h:
                continue

            filtered.append(loc)

        encodings = face_recognition.face_encodings(
            rgb_frame,
            filtered
        )

        return [
            {
                "location": loc,
                "encoding": enc
            }
            for loc, enc in zip(filtered, encodings)
        ]

    def best_match(self, encoding, known_people):

        if not known_people:
            return None

        known_encodings = [
            np.array(p["encoding"])
            for p in known_people
        ]

        distances = face_recognition.face_distance(
            known_encodings,
            encoding
        )

        index = int(np.argmin(distances))

        best_distance = float(distances[index])

        if best_distance <= self.threshold:

            return known_people[index]

        return None


# ============================================================
# APP STATE
# ============================================================


class AppState:

    def __init__(self):

        self.frames = {}

        self.lock = threading.Lock()

        self.stop_event = threading.Event()

    def set_frame(self, source, frame):

        with self.lock:

            self.frames[str(source)] = frame.copy()

    def get_frames(self):

        with self.lock:

            return {
                k: v.copy()
                for k, v in self.frames.items()
            }

    def stop(self):

        self.stop_event.set()

    def should_stop(self):

        return self.stop_event.is_set()


# ============================================================
# CAMERA WORKER
# ============================================================


class CameraWorker(threading.Thread):

    def __init__(self, source, state):

        super().__init__(daemon=True)

        self.source = source

        self.state = state

        self.stop_signal = threading.Event()

        self.recognizer = Recognizer()

        self.tracks: List[Track] = []

    # ========================================================
    # OPEN CAMERA
    # ========================================================

    @staticmethod
    def open_camera(source):

        cap = cv2.VideoCapture(
            source,
            cv2.CAP_FFMPEG
        )

        cap.set(
            cv2.CAP_PROP_BUFFERSIZE,
            1
        )

        width = int(
            cap.get(cv2.CAP_PROP_FRAME_WIDTH)
        )

        height = int(
            cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
        )

        fps = int(
            cap.get(cv2.CAP_PROP_FPS)
        )

        print(
            f"[CAMERA INFO] "
            f"Width={width} "
            f"Height={height} "
            f"FPS={fps}"
        )

        return cap

    # ========================================================
    # TRACK MATCH
    # ========================================================

    def find_track(self, center):

        best_index = None

        best_distance = float("inf")

        for i, track in enumerate(self.tracks):

            d = distance(center, track.center)

            if d < TRACK_DISTANCE:

                if d < best_distance:

                    best_distance = d

                    best_index = i

        return best_index

    # ========================================================
    # MAIN LOOP
    # ========================================================

    def run(self):

        print(f"[CAMERA] Starting {self.source}")

        cap = self.open_camera(self.source)

        if not cap.isOpened():

            print(f"[ERROR] Cannot open {self.source}")

            return

        frame_counter = 0

        while (
            not self.stop_signal.is_set()
            and not self.state.should_stop()
        ):

            success, frame = cap.read()

            if not success:

                print(
                    f"[WARNING] Reconnecting "
                    f"{self.source}"
                )

                cap.release()

                time.sleep(2)

                cap = self.open_camera(self.source)

                continue

            if not is_frame_valid(frame):
                continue

            # =================================================
            # OPTIONAL BLUR CHECK
            # =================================================

            # if is_blurry(frame):
            #     continue

            frame_counter += 1

            if frame_counter % 2 != 0:
                continue

            try:

                small_frame = cv2.resize(
                    frame,
                    (0, 0),
                    fx=FRAME_RESIZE,
                    fy=FRAME_RESIZE
                )

                rgb = cv2.cvtColor(
                    small_frame,
                    cv2.COLOR_BGR2RGB
                )

                faces = self.recognizer.detect(rgb)

                persons = load_persons()

                known_people = [
                    {
                        "id": pid,
                        "name": data["name"],
                        "encoding": data["encoding"]
                    }
                    for pid, data in persons.items()
                ]

                matched_tracks = set()

                for face in faces:

                    location = face["location"]

                    encoding = face["encoding"]

                    center = centroid(location)

                    track_index = self.find_track(center)

                    if track_index is not None:

                        track = self.tracks[track_index]

                        matched_tracks.add(track_index)

                        track.center = center

                        track.lost_frames = 0

                        person_id = track.person_id

                        name = track.name

                    else:

                        match = self.recognizer.best_match(
                            encoding,
                            known_people
                        )

                        if match:

                            person_id = match["id"]

                            name = match["name"]

                        else:

                            person_id = str(uuid.uuid4())

                            name = (
                                f"Person-"
                                f"{person_id[:8]}"
                            )

                            face_path = save_face(
                                frame,
                                location,
                                name,
                                person_id
                            )

                            if face_path is None:
                                continue

                            persons[person_id] = {
                                "id": person_id,
                                "name": name,
                                "encoding": encoding.tolist(),
                                "face_image": face_path,
                                "created_at": datetime.datetime.now().isoformat()
                            }

                            save_persons(persons)

                            set_access(
                                person_id,
                                name,
                                "allow"
                            )

                            print(
                                f"[NEW PERSON] "
                                f"{name}"
                            )

                        self.tracks.append(
                            Track(
                                person_id=person_id,
                                name=name,
                                center=center
                            )
                        )

                        matched_tracks.add(
                            len(self.tracks) - 1
                        )

                    access = get_access(person_id)

                    top, right, bottom, left = location

                    top = int(top / FRAME_RESIZE)

                    right = int(right / FRAME_RESIZE)

                    bottom = int(bottom / FRAME_RESIZE)

                    left = int(left / FRAME_RESIZE)

                    color = (
                        (0, 255, 0)
                        if access == "allow"
                        else (0, 0, 255)
                    )

                    cv2.rectangle(
                        frame,
                        (left, top),
                        (right, bottom),
                        color,
                        2
                    )

                    label = (
                        f"{name} | "
                        f"{access}"
                    )

                    cv2.putText(
                        frame,
                        label,
                        (left, top - 10),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,
                        color,
                        1
                    )

                # =============================================
                # CLEAN TRACKS
                # =============================================

                for i, track in enumerate(self.tracks):

                    if i not in matched_tracks:

                        track.lost_frames += 1

                self.tracks = [
                    t for t in self.tracks
                    if t.lost_frames < TRACK_LOST_FRAMES
                ]

                self.state.set_frame(
                    self.source,
                    frame
                )

            except Exception as e:

                print(f"[ERROR] {e}")

            time.sleep(0.03)

        cap.release()

    def stop(self):

        self.stop_signal.set()


# ============================================================
# WORKER HELPERS
# ============================================================


def start_workers(state):

    workers = []

    for src in CAMERA_SOURCES:

        worker = CameraWorker(
            src,
            state
        )

        worker.start()

        workers.append(worker)

    return workers


def stop_workers(workers):

    for worker in workers:
        worker.stop()

    for worker in workers:
        worker.join(timeout=2)


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":

    print("\n========================================")

    print(" AI CCTV FACE SECURITY SYSTEM ")

    print("========================================\n")

    print(f"Cameras: {CAMERA_SOURCES}")

    print(f"Face Model: {FACE_MODEL}")

    print(f"Strike Limit: {STRIKE_LIMIT}")

    print()

    state = AppState()

    workers = start_workers(state)

    try:

        while not state.should_stop():

            frames = state.get_frames()

            for source, frame in frames.items():

                cv2.imshow(
                    f"CCTV Camera {source}",
                    frame
                )

            key = cv2.waitKey(1) & 0xFF

            if key in (ord("q"), 27):

                state.stop()

            time.sleep(0.01)

    except KeyboardInterrupt:

        state.stop()

    finally:

        stop_workers(workers)

        cv2.destroyAllWindows()

        print("\nSystem stopped.\n")