import asyncio
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import Response, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .config import settings
from .db import init_db, get_db
from .workers.camera_worker import CameraWorker

app = FastAPI(title="Face Security System")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class StatusUpdate(BaseModel):
    status: str

@app.on_event("startup")
def on_startup():
    # init DB
    init_db()
    # event loop reference for thread->async scheduling
    app.state.loop = asyncio.get_event_loop()
    app.state.clients = set()
    app.state.last_frame = None
    # start camera workers from CAMERA_SOURCES
    app.state.camera_workers = []
    sources = settings.cameras()
    for s in sources:
        try:
            src = int(s) if s.isdigit() else s
        except Exception:
            src = s
        w = CameraWorker(src, app)
        w.start()
        app.state.camera_workers.append(w)

@app.on_event("shutdown")
def on_shutdown():
    for w in getattr(app.state, 'camera_workers', []):
        w.stop()

# WebSocket broadcast helper
async def broadcast(event: dict):
    to_remove = []
    for ws in list(app.state.clients):
        try:
            await ws.send_json(event)
        except Exception:
            to_remove.append(ws)
    for ws in to_remove:
        try:
            app.state.clients.remove(ws)
        except KeyError:
            pass

# expose broadcast to worker threads
app.state.broadcast = broadcast

@app.websocket("/ws/events")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    app.state.clients.add(websocket)
    try:
        while True:
            # keep connection alive; clients may send pings
            await websocket.receive_text()
    except WebSocketDisconnect:
        try:
            app.state.clients.remove(websocket)
        except KeyError:
            pass

@app.get("/api/persons")
def list_persons():
    db = get_db()
    persons = []
    for p in db.persons.find().sort("created_at", -1).limit(200):
        persons.append({"id": str(p.get("_id")), "name": p.get("name"), "status": p.get("status"), "created_at": p.get("created_at")})
    return persons

@app.post("/api/persons/{person_id}/status")
def update_status(person_id: str, su: StatusUpdate):
    db = get_db()
    res = db.persons.update_one({"_id": person_id}, {"$set": {"status": su.status}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Person not found")
    return {"ok": True}

@app.get("/api/stream/frame.jpg")
def frame_jpeg():
    data = getattr(app.state, 'last_frame', None)
    if not data:
        return Response(status_code=204)
    return Response(content=data, media_type="image/jpeg")

@app.get("/api/logs")
def get_logs():
    db = get_db()
    docs = []
    for l in db.detection_logs.find().sort("timestamp", -1).limit(200):
        docs.append({"person_id": l.get("person_id"), "name": l.get("name"), "distance": l.get("distance"), "timestamp": l.get("timestamp")})
    return docs

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
