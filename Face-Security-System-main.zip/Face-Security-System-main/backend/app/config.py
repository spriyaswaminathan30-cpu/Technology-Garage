from pydantic import Field
from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    MONGODB_URI: str = Field("mongodb://localhost:27017", env="MONGODB_URI")
    DB_NAME: str = Field("face_security", env="DB_NAME")
    ALERT_WEBHOOK: str = Field("", env="ALERT_WEBHOOK")
    EMBEDDING_THRESHOLD: float = Field(0.5, env="EMBEDDING_THRESHOLD")
    UNKNOWN_SAVE_SECONDS: int = Field(30, env="UNKNOWN_SAVE_SECONDS")
    CAMERA_SOURCES: str = Field("0", env="CAMERA_SOURCES")

    class Config:
        env_file = ".env"

    def cameras(self) -> List[str]:
        return [s.strip() for s in self.CAMERA_SOURCES.split(',') if s.strip()]

settings = Settings()
