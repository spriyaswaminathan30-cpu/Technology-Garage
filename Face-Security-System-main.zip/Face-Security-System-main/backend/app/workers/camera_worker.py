import threading
import time
import uuid
import datetime
import asyncio
import cv2
import numpy as np
import face_recognition

from ..recognition import Recognizer
from ..db import get_collections
from ..config import settings
from ..alerts import AlertService

class CameraWorker(threading.Thread):
    def __init__(self, source, app):
        super().__init__(daemon=True)
        self.source = source
        self.app = app
        self.recognizer = Recognizer(settings.EMBEDDING_THRESHOLD)
        self.stop_event = threading.Event()
        self.unknown_cache = []  # list of (encoding_list, ts)
        self.alert_service = AlertService(settings.ALERT_WEBHOOK)

    def run(self):
        persons_col, logs_col = get_collections()
        cap = cv2.VideoCapture(self.source)
        while not self.stop_event.is_set():
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.5)
                continue
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            faces = self.recognizer.detect_and_encode(rgb)
            labels = []
            locations = []
            for face in faces:
                loc = face["location"]
                enc = face["encoding"]
                # load known encodings
                known = list(persons_col.find({}, {"encoding":1, "name":1, "status":1}))
                known_encs = [np.array(p["encoding"]) for p in known] if known else []
                match_idx, dist = self.recognizer.best_match(enc, known_encs)
                if match_idx is not None:
                    person = known[match_idx]
                    labels.append(person.get("name", "Unknown"))
                    # log detection
                    logs_col.insert_one({
                        "person_id": str(person.get("_id")),
                        "name": person.get("name"),
                        "distance": dist,
                        "timestamp": datetime.datetime.utcnow()
                    })
                    if person.get("status") == "blocked":
                        event = {"type":"alert","reason":"blocked_detected","person":{"id":str(person.get("_id")),"name":person.get("name")},"timestamp":datetime.datetime.utcnow().isoformat()}
                        self._broadcast_event(event)
                        self.alert_service.send(event)
                else:
                    # unknown person handling (avoid duplicates)
                    skip = False
                    now_ts = time.time()
                    for ue, ts in list(self.unknown_cache):
                        d = face_recognition.face_distance([np.array(ue)], enc)[0]
                        if d <= settings.EMBEDDING_THRESHOLD:
                            skip = True
                            break
                        if now_ts - ts > settings.UNKNOWN_SAVE_SECONDS:
                            try:
                                self.unknown_cache.remove((ue, ts))
                            except ValueError:
                                pass
                    if not skip:
                        new_id = str(uuid.uuid4())
                        name = f"Unknown-{new_id[:8]}"
                        persons_col.insert_one({"_id": new_id, "name": name, "encoding": enc.tolist(), "status":"allowed", "created_at": datetime.datetime.utcnow()})
                        logs_col.insert_one({"person_id": new_id, "name": name, "distance": None, "timestamp": datetime.datetime.utcnow()})
                        labels.append(name)
                        self.unknown_cache.append((enc.tolist(), now_ts))
                        event = {"type":"new_person","person":{"id":new_id,"name":name},"timestamp":datetime.datetime.utcnow().isoformat()}
                        self._broadcast_event(event)
                locations.append(loc)
            # draw boxes on frame
            frame = self.recognizer.draw_boxes(frame, locations, labels)
            # encode jpeg
            _, jpeg = cv2.imencode('.jpg', frame)
            self.app.state.last_frame = jpeg.tobytes()
            time.sleep(0.05)

    def stop(self):
        self.stop_event.set()

    def _broadcast_event(self, event: dict):
        # schedule broadcast on the FastAPI event loop
        loop = getattr(self.app.state, 'loop', None)
        if loop and hasattr(self.app.state, 'broadcast'):
            coro = self.app.state.broadcast(event)
            asyncio.run_coroutine_threadsafe(coro, loop)
