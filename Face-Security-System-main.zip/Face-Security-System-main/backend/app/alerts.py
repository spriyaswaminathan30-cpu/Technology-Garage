import httpx

class AlertService:
    def __init__(self, webhook_url: str = ""):
        self.webhook_url = webhook_url

    def send(self, payload: dict):
        if not self.webhook_url:
            return
        try:
            httpx.post(self.webhook_url, json=payload, timeout=5.0)
        except Exception as e:
            print("Failed to send alert:", e)
