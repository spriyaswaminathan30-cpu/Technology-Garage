import face_recognition
import numpy as np
import cv2
from typing import List, Tuple, Dict

class Recognizer:
    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold

    def detect_and_encode(self, rgb_frame) -> List[Dict]:
        # rgb_frame: HxWx3 numpy array (RGB)
        locations = face_recognition.face_locations(rgb_frame)
        encodings = face_recognition.face_encodings(rgb_frame, locations)
        results = []
        for loc, enc in zip(locations, encodings):
            results.append({"location": loc, "encoding": enc})
        return results

    def best_match(self, encoding, known_encodings: List[np.ndarray]) -> Tuple[int, float]:
        if not known_encodings:
            return None, None
        dists = face_recognition.face_distance(known_encodings, encoding)
        best_idx = int(np.argmin(dists))
        best_dist = float(dists[best_idx])
        if best_dist <= self.threshold:
            return best_idx, best_dist
        return None, best_dist

    @staticmethod
    def draw_boxes(frame, locations, labels):
        # locations are (top, right, bottom, left) in face_recognition
        for (top, right, bottom, left), label in zip(locations, labels):
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, str(label), (left, max(top-10,0)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 1)
        return frame
