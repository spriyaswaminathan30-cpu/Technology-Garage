from pymongo import MongoClient
from .config import settings

client = None
db = None

def init_db():
    global client, db
    client = MongoClient(settings.MONGODB_URI)
    db = client[settings.DB_NAME]
    # indexes
    db.persons.create_index("created_at")
    db.persons.create_index("status")
    db.detection_logs.create_index("timestamp")
    return db

def get_db():
    if db is None:
        return init_db()
    return db

def get_collections():
    d = get_db()
    return d.persons, d.detection_logs
