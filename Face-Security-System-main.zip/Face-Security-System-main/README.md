# Face Recognition Security System

Production-oriented, modular Face Recognition security system.

Features
- Multi-source camera input (webcam, ESP32-CAM, Pi camera, RTSP)
- Real-time face detection & embedding (face_recognition + OpenCV)
- MongoDB-backed person store (allow / block)
- Admin dashboard (React) with live logs and controls
- Alerting via webhook/email when blocked or low-confidence faces detected

Quick start (development)

1) Start MongoDB (local or Docker):

```bash
docker run -d --name face-mongo -p 27017:27017 -v mongo-data:/data/db mongo:6.0
```

2) Create Python environment and install dependencies:

```bash
python -m venv .venv
.venv/Scripts/activate    # Windows
pip install -r requirements.txt
```

3) Start backend (development):

```bash
cd backend
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

4) Start frontend (development):

```bash
cd frontend
npm install
npm run dev
```

Or use Docker Compose (build+run backend + mongo):

```bash
docker compose up --build
```

Notes
- face_recognition/dlib requires system build tools (install instructions in the sections below).
- Use `.env` to configure `MONGODB_URI`, `ALERT_WEBHOOK`, `EMBEDDING_THRESHOLD`, and `CAMERA_SOURCES`.

Files of interest:
- `backend/app` — FastAPI backend, recognition worker, DB integration
- `frontend/src` — React admin dashboard
- `docker-compose.yml` — quick dev compose

Next steps
- Tune `EMBEDDING_THRESHOLD` for your environment
- Configure `CAMERA_SOURCES` in `.env` (e.g. `0`, `rtsp://…`, `http://<esp32cam>/stream`)
- Set `ALERT_WEBHOOK` for admin notifications
