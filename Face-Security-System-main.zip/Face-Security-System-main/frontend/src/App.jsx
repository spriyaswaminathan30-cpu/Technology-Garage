import React from 'react'
import LiveFeed from './components/LiveFeed'
import Dashboard from './components/Dashboard'

export default function App(){
  return (
    <div style={{display:'flex', gap:20, padding:20}}>
      <div style={{flex:1}}>
        <h2>Live Feed</h2>
        <LiveFeed />
      </div>
      <div style={{width:420}}>
        <h2>Admin Dashboard</h2>
        <Dashboard />
      </div>
    </div>
  )
}
