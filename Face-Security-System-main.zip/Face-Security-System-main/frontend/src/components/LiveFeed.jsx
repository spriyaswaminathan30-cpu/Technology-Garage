import React, { useEffect, useState } from 'react'

export default function LiveFeed(){
  const [ts, setTs] = useState(Date.now())
  useEffect(()=>{
    const id = setInterval(()=> setTs(Date.now()), 800)
    return ()=> clearInterval(id)
  }, [])
  return (
    <div>
      <img src={`/api/stream/frame.jpg?ts=${ts}`} alt="live" style={{width:'100%', border:'1px solid #ccc'}}/>
    </div>
  )
}
