import React, { useEffect, useState } from 'react'
import axios from 'axios'

export default function Dashboard(){
  const [persons, setPersons] = useState([])

  useEffect(()=>{
    fetchPersons()
    const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws/events`)
    ws.onmessage = (e)=>{
      const ev = JSON.parse(e.data)
      if(ev.type === 'new_person' || ev.type === 'alert'){
        fetchPersons()
      }
    }
    return ()=> ws.close()
  }, [])

  async function fetchPersons(){
    try{
      const res = await axios.get('/api/persons')
      setPersons(res.data)
    }catch(err){
      console.error(err)
    }
  }

  async function setStatus(id, status){
    try{
      await axios.post(`/api/persons/${id}/status`, { status })
      fetchPersons()
    }catch(err){
      console.error(err)
    }
  }

  return (
    <div>
      <h3>Known Persons</h3>
      <ul>
        {persons.map(p=> (
          <li key={p.id} style={{marginBottom:8}}>
            <strong>{p.name}</strong> — {p.status}
            <div style={{marginTop:4}}>
              <button onClick={()=> setStatus(p.id, p.status === 'blocked' ? 'allowed' : 'blocked')}>
                {p.status === 'blocked' ? 'Unblock' : 'Block'}
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
