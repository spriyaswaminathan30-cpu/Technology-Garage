#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║  FACE SECURITY TEST — llava:7b                              ║
║  Scenario: Building entrance / access control CCTV          ║
║  Device  : AGX Orin 32/64GB or Workstation 8GB GPU         ║
║  Speed   : ⚡⚡☆☆  |  Accuracy: ★★★★☆               ║
╚══════════════════════════════════════════════════════════════╝

TESTS COVERED:
  1.  Model availability
  2.  Scene description
  3.  Authorized person → STATUS: NORMAL
  4.  Denied person → STATUS: RISK
  5.  Tailgating
  6.  Loitering
  7.  Aggression
  8.  Hallucination test (blank frame — known LLaVA weakness)
  9.  Format compliance
  10. Speed benchmark

KNOWN LLAVA:7B ISSUES IN THIS SCENARIO:
  - Occasionally hallucinates people not in frame (test 8 catches this)
  - Slower than qwen2.5vl:3b (~20-30s/frame on AGX Orin)
  - Less precise about badge colors/details vs Qwen
  - Verbose descriptions — good for incident reports

RUN:
  ollama pull llava:7b
  python3 test_face_sec_llava.py
"""

import ollama
import base64
import time
import sys
import argparse
from datetime import datetime
from PIL import Image, ImageDraw
from io import BytesIO

MODEL = "llava:7b"
G, R, Y, B, BOLD, DIM, RESET = (
    "\033[92m","\033[91m","\033[93m","\033[94m",
    "\033[1m","\033[2m","\033[0m"
)

PROMPT = """<image>
You are an AI security system at a building entrance with face recognition access control.

Analyze this CCTV frame. Authorized people have GREEN badges. Denied/blocked people have RED badges.

Describe what you see in 2 sentences. Then write one of:
STATUS: NORMAL
STATUS: MEDIUM
STATUS: RISK

If STATUS is MEDIUM or RISK, write:
ANOMALY: TAILGATING
or ANOMALY: LOITERING
or ANOMALY: AGGRESSION
or ANOMALY: SUSPICIOUS
or ANOMALY: TRESPASSING
"""

def make_frame(scenario: str) -> Image.Image:
    w, h = 640, 480
    bg = {
        "authorized":(38,55,38),"denied":(70,26,26),"tailgating":(55,50,28),
        "loitering":(46,46,70),"aggression":(80,20,20),"multi":(38,50,43),"blank":(18,18,18)
    }.get(scenario,(38,55,38))
    img = Image.new("RGB",(w,h),bg)
    d   = ImageDraw.Draw(img)
    d.rectangle([0,0,w,44],fill=(0,0,0))
    d.text((8,7),  f"ENTRANCE CAM-01   {datetime.now().strftime('%H:%M:%S')}   LOBBY",fill="white")
    d.text((8,26), f"LLAVA TEST: {scenario.upper()}",fill=(255,180,80))
    if scenario == "blank":
        d.text((190,220),"EMPTY FRAME",fill=(80,80,80))
        return img
    d.rectangle([0,h-70,w,h],fill=(52,42,34))
    d.line([(0,h-70),(w,h-70)],fill=(158,138,116),width=2)
    d.rectangle([268,56,382,h-70],fill=(22,22,30),outline=(172,152,122),width=3)
    d.text((283,63),"ENTRANCE",fill=(198,176,92))

    def person(cx,cy,badge="green",arm_raised=False):
        skin=(210,176,140)
        shirt=(76,90,162) if badge=="green" else (162,52,52)
        d.ellipse([cx-22,cy-62,cx+22,cy-12],fill=skin,outline="white")
        d.rectangle([cx-16,cy-12,cx+16,cy+80],fill=shirt,outline="white")
        if arm_raised:
            d.line([(cx+16,cy+6),(cx+50,cy-28)],fill=skin,width=5)
            d.line([(cx-16,cy+6),(cx-42,cy+50)],fill=skin,width=4)
        else:
            d.line([(cx-16,cy+6),(cx-42,cy+50)],fill=skin,width=4)
            d.line([(cx+16,cy+6),(cx+42,cy+50)],fill=skin,width=4)
        d.rectangle([cx-18,cy+80,cx-4,cy+148],fill=(30,30,30))
        d.rectangle([cx+4,cy+80,cx+18,cy+148],fill=(30,30,30))
        bc=(0,200,78) if badge=="green" else (212,36,36)
        d.rectangle([cx-10,cy+4,cx+10,cy+26],fill=bc,outline="white")
        d.text((cx-8,cy+8),"ID",fill="white")

    {"authorized": lambda: [person(322,180,"green"),
                              d.text((278,375),"✅ AUTHORIZED",fill=(0,220,80))],
     "denied":     lambda: [person(322,180,"red"),
                              d.rectangle([240,378,420,406],fill=(200,28,28)),
                              d.text((255,384),"🚫 DENIED — BLOCKED",fill="white")],
     "tailgating": lambda: [person(290,176,"green"),person(358,196,"red"),
                              d.text((220,375),"⚠️ TAILGATING",fill=(255,165,0))],
     "loitering":  lambda: [person(152,194,"red"),
                              d.text((88,375),"⏱️ LOITERING 9 MINUTES",fill=(255,165,0))],
     "aggression": lambda: [person(246,176,"green"),person(388,176,"red",arm_raised=True),
                              d.rectangle([212,378,442,406],fill=(200,28,28)),
                              d.text((218,384),"⚠️ AGGRESSIVE BEHAVIOR",fill="white")],
     "multi":      lambda: [person(150,184,"green"),person(320,186,"green"),person(490,184,"green"),
                              d.text((190,375),"3 AUTHORIZED",fill=(0,210,80))],
    }.get(scenario, lambda: None)()
    d.text((5,463),"Synthetic test frame — use real CCTV images for production",fill=(115,115,115))
    return img

def encode(img):
    buf=BytesIO(); img.save(buf,format="JPEG",quality=85)
    return base64.b64encode(buf.getvalue()).decode()

def query(prompt,img=None):
    start=time.time()
    kwargs=dict(model=MODEL,prompt=prompt)
    if img: kwargs["images"]=[encode(img)]
    resp=ollama.generate(**kwargs)
    return resp.get("response","").strip(), time.time()-start

def parse(text):
    status,anomaly="normal",None
    t=text.upper()
    if "STATUS: RISK" in t: status="risk"
    elif "STATUS: MEDIUM" in t: status="medium"
    for line in text.splitlines():
        if line.upper().strip().startswith("ANOMALY:"):
            anomaly=line.split(":",1)[1].strip()
    return {"status":status,"anomaly":anomaly}

def show(label,passed,resp,elapsed,expected="",notes=""):
    icon="✅" if passed else "❌"
    color=G if passed else R
    print(f"{color}{icon} {label}{RESET}")
    if expected: print(f"   📌 Expected : {expected}")
    print(f"   ⏱  Time    : {elapsed:.2f}s")
    print(f"   📝 Response : {resp[:280]}{'...' if len(resp)>280 else ''}")
    if notes: print(f"   💡 Notes   : {notes}")
    print()

def run(img_path=None):
    print(f"\n{B}{'═'*62}")
    print(f"  🤖 FACE SECURITY TEST — {MODEL}")
    print(f"  Scenario: Building Entrance / Access Control")
    print(f"  Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  ⚠️  Requires 8GB+ VRAM — NOT for Orin Nano")
    print(f"{'═'*62}{RESET}\n")

    print(f"{B}[TEST 0] Model availability{RESET}")
    try:
        models=ollama.list()
        names=[m.get("name","") for m in models.get("models",[])]
        if not any("llava" in n for n in names):
            print(f"  {R}❌ Run: ollama pull {MODEL}{RESET}\n"); sys.exit(1)
        print(f"  {G}✅ {MODEL} ready{RESET}\n")
    except Exception as e:
        print(f"  {R}❌ {e}{RESET}\n"); sys.exit(1)

    results={}

    print(f"{B}[TEST 1] Basic response{RESET}")
    r,t=query("Reply: LLAVA_READY")
    ok=len(r)>2
    show("Basic Text",ok,r,t,"LLAVA_READY"); results["basic"]=ok

    print(f"{B}[TEST 2] Scene description{RESET}")
    r,t=query("Describe this image in detail.",make_frame("authorized"))
    ok=len(r)>30
    show("Scene Description",ok,r,t,"Detailed lobby/entrance description",
         "LLaVA-7B produces verbose, report-quality descriptions — useful for incident logs")
    results["description"]=ok

    print(f"{B}[TEST 3] Authorized → STATUS: NORMAL{RESET}")
    img=Image.open(img_path) if img_path else make_frame("authorized")
    r,t=query(PROMPT,img)
    p=parse(r); ok=p["status"]=="normal"
    show("Authorized (NORMAL)",ok,r,t,"STATUS: NORMAL",f"Got: {p['status'].upper()}")
    results["authorized"]=ok

    print(f"{B}[TEST 4] Denied → STATUS: RISK{RESET}")
    img=Image.open(img_path) if img_path else make_frame("denied")
    r,t=query(PROMPT,img)
    p=parse(r); ok=p["status"] in ("medium","risk")
    show("Denied Person (RISK)",ok,r,t,"STATUS: RISK",
         f"Got: {p['status'].upper()} | LLaVA may use different wording")
    results["denied"]=ok

    print(f"{B}[TEST 5] Tailgating{RESET}")
    r,t=query(PROMPT,make_frame("tailgating"))
    p=parse(r); ok=p["status"] in ("medium","risk") or "tailgat" in r.lower() or "follow" in r.lower()
    show("Tailgating",ok,r,t,"STATUS: RISK + ANOMALY: TAILGATING",f"Got: {p['status'].upper()}")
    results["tailgating"]=ok

    print(f"{B}[TEST 6] Loitering{RESET}")
    r,t=query(PROMPT,make_frame("loitering"))
    p=parse(r); ok=p["status"] in ("medium","risk") or "loiter" in r.lower()
    show("Loitering",ok,r,t,"STATUS: MEDIUM + ANOMALY: LOITERING",f"Got: {p['status'].upper()}")
    results["loitering"]=ok

    print(f"{B}[TEST 7] Aggression{RESET}")
    r,t=query(PROMPT,make_frame("aggression"))
    p=parse(r); ok=p["status"] in ("medium","risk") or "aggress" in r.lower()
    show("Aggression",ok,r,t,"STATUS: RISK + ANOMALY: AGGRESSION",f"Got: {p['status'].upper()}")
    results["aggression"]=ok

    print(f"{B}[TEST 8] HALLUCINATION CHECK — blank frame ← LLaVA weakness{RESET}")
    blank=Image.new("RGB",(640,480),(18,18,18))
    d=ImageDraw.Draw(blank)
    d.text((180,220),"EMPTY FRAME — NO PEOPLE",fill=(70,70,70))
    r,t=query("How many people are in this image? What are they doing?",blank)
    is_honest=any(w in r.lower() for w in ["no one","nobody","empty","no people","zero","0","dark","blank","cannot"])
    show("Hallucination Check (blank frame)",
         is_honest,r,t,"Should say: no people / empty frame",
         f"{'✅ Honest' if is_honest else '❌ HALLUCINATING — LLaVA described people that arent there!'}"
         "\n   ⚠️  If FAILED: manually verify high-risk alerts from LLaVA")
    results["hallucination"]=is_honest

    print(f"{B}[TEST 9] Format compliance{RESET}")
    r,t=query(PROMPT,make_frame("authorized"))
    ok="STATUS:" in r.upper()
    show("Format",ok,r,t,"Response with STATUS: line",
         "LLaVA-7B sometimes misses format — may need re-prompting")
    results["format"]=ok

    print(f"{B}[TEST 10] Speed benchmark (3 frames — LLaVA is slower){RESET}")
    img=make_frame("authorized")
    times=[]
    for i in range(3):
        _,t=query("One sentence: describe the entrance scene.",img)
        times.append(t)
        print(f"   Frame {i+1}: {t:.1f}s")
    avg=sum(times)/len(times)
    n=max(15,int(30*avg))
    ok=avg<50.0
    print()
    show(f"Speed ({avg:.1f}s avg)",ok,str([f"{t:.1f}s" for t in times]),avg,
         "< 50s/frame on AGX Orin",f"ANOMALY_EVERY_N_FRAMES = {n}")
    results["speed"]=ok

    print(f"\n{B}{'═'*62}")
    print(f"  📊 RESULTS — {MODEL}")
    print(f"{'═'*62}{RESET}")
    passed=sum(1 for v in results.values() if v is True)
    total=len(results)
    for k,v in results.items():
        color=G if v else R
        print(f"  {color}{'✅' if v else '❌'} {k.replace('_',' ').title()}{RESET}")
    print(f"\n  Score: {passed}/{total}")

    print(f"\n{BOLD}  💡 CONFIG FOR ai_cctv_face_security.py:{RESET}")
    print(f'{BOLD}     OLLAMA_MODEL           = "{MODEL}"{RESET}')
    print(f'{BOLD}     ANOMALY_EVERY_N_FRAMES  = {n}{RESET}')

    print(f"\n{B}  ⚠️  LLAVA:7B FACE SECURITY NOTES:{RESET}")
    halluc_ok = results.get("hallucination", False)
    if not halluc_ok:
        print(f"  {R}  🔴 HALLUCINATION TEST FAILED — manually verify all RISK alerts{RESET}")
    print(f"     - Not suitable for Orin Nano (8GB VRAM required)")
    print(f"     - Good for incident report generation (verbose)")
    print(f"     - Slower than qwen2.5vl:3b on same hardware")
    print(f"     - Use qwen2.5vl:3b as primary, llava:7b for incident reports\n")

if __name__ == "__main__":
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument("--image",type=str)
    args=parser.parse_args()
    run(args.image)
