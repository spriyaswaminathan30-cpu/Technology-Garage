#!/usr/bin/env python3
# ============================================================
# AI CCTV FACE SECURITY SYSTEM — VLM ENHANCED
# Same architecture as original + Ollama AI anomaly detection
# ============================================================
#
# WHAT'S ADDED vs original:
#   - Ollama VLM anomaly detection (shoplifting, fight, fall)
#   - Configurable model (moondream / qwen2.5vl:3b / llava:7b)
#   - Strike system: person gets blocked after N anomalies
#   - All events + anomalies logged to JSON
#   - Loitering detection from track dwell time
#   - WebSocket broadcast (same as surveillance_main.py)
#
# HOW TO RUN:
#   pip install face_recognition opencv-python ollama pillow numpy websockets
#   ollama pull qwen2.5vl:3b
#   python3 ai_cctv_face_security.py
# ============================================================

from __future__ import annotations

import cv2
import json
import time
import uuid
import math
import base64
import asyncio
import threading
import datetime
import numpy as np
import face_recognition
import ollama

from io import BytesIO
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from PIL import Image

# ============================================================
# PATHS
# ============================================================

BASE_DIR     = Path(__file__).parent
DATA_DIR     = BASE_DIR / "data"
FACES_DIR    = DATA_DIR / "faces"
EVIDENCE_DIR = DATA_DIR / "evidence"

PERSONS_FILE = DATA_DIR / "persons.json"
ACCESS_FILE  = DATA_DIR / "access.json"
EVENTS_FILE  = DATA_DIR / "events.json"
ALERTS_FILE  = DATA_DIR / "alerts.json"

for d in [DATA_DIR, FACES_DIR, EVIDENCE_DIR]:
    d.mkdir(exist_ok=True)

# ============================================================
# CAMERA SETTINGS
# ============================================================

CAMERA_SOURCES = [
    "rtsp://admin:EduServices%2301@192.168.29.100:554/cam/realmonitor?channel=1&subtype=1"
    # For webcam testing: use 0
    # 0
]

# ============================================================
# AI MODEL SETTINGS  — Change this one line to switch models
# ============================================================

#  Jetson Orin Nano 4GB  → "moondream:latest"
#  Jetson Orin Nano 8GB  → "qwen2.5vl:3b"   ← RECOMMENDED
#  AGX Orin / Workstation → "llava:7b"

OLLAMA_MODEL = "qwen2.5vl:3b"

# Run anomaly check every N processed frames (increase if slow)
ANOMALY_EVERY_N_FRAMES = 30

# ============================================================
# DETECTION SETTINGS  (same as original)
# ============================================================

FACE_MODEL           = "hog"
FACE_MATCH_THRESHOLD = 0.50
FRAME_RESIZE         = 1.0
MIN_FACE_WIDTH       = 30
MIN_FACE_HEIGHT      = 30
TRACK_DISTANCE       = 100
TRACK_LOST_FRAMES    = 20
BLUR_THRESHOLD       = 40

# ============================================================
# BEHAVIOUR SETTINGS  (same as original)
# ============================================================

LOITER_SECONDS      = 60     # seconds before loitering alert
RAPID_MOVE_DISTANCE = 120
STRIKE_LIMIT        = 3      # anomaly strikes before auto-block

# ============================================================
# JSON LOCK
# ============================================================

json_lock = threading.Lock()

# ============================================================
# JSON HELPERS  (unchanged from original)
# ============================================================

def read_json(path):
    if not path.exists():
        return {}
    try:
        if path.stat().st_size == 0:
            return {}
        with open(path, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if not content:
                return {}
            return json.loads(content)
    except Exception:
        print(f"[WARNING] Corrupted JSON: {path.name}")
        return {}

def write_json(path, data):
    try:
        temp = path.with_suffix(".tmp")
        with open(temp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)
        temp.replace(path)
    except Exception as e:
        print(f"[ERROR] JSON write failed: {e}")

# ============================================================
# FRAME VALIDATION  (unchanged)
# ============================================================

def is_frame_valid(frame):
    if frame is None: return False
    if frame.size == 0: return False
    h, w = frame.shape[:2]
    return h >= 100 and w >= 100

def is_blurry(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    return cv2.Laplacian(gray, cv2.CV_64F).var() < BLUR_THRESHOLD

# ============================================================
# PERSON DATABASE  (unchanged)
# ============================================================

def load_persons():
    with json_lock:
        return read_json(PERSONS_FILE)

def save_persons(data):
    with json_lock:
        write_json(PERSONS_FILE, data)

def save_face(frame, location, name, person_id):
    top, right, bottom, left = location
    padding = 20
    h, w = frame.shape[:2]
    top    = max(0, top - padding)
    left   = max(0, left - padding)
    bottom = min(h, bottom + padding)
    right  = min(w, right + padding)
    crop = frame[top:bottom, left:right]
    if crop.size == 0: return None
    ch, cw = crop.shape[:2]
    if cw < MIN_FACE_WIDTH or ch < MIN_FACE_HEIGHT: return None
    filename = f"{name}_{person_id[:8]}.jpg"
    filepath = FACES_DIR / filename
    cv2.imwrite(str(filepath), crop)
    return str(filepath.relative_to(DATA_DIR))

def save_evidence(frame, label):
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"evidence_{label}_{ts}.jpg"
    path = EVIDENCE_DIR / filename
    cv2.imwrite(str(path), frame)
    return str(path)

# ============================================================
# ACCESS CONTROL  (unchanged)
# ============================================================

def load_access():
    with json_lock:
        return read_json(ACCESS_FILE)

def save_access(data):
    with json_lock:
        write_json(ACCESS_FILE, data)

def set_access(person_id, name, status="allow"):
    access = load_access()
    access[person_id] = {
        "name": name,
        "status": status,
        "updated_at": datetime.datetime.now().isoformat()
    }
    save_access(access)

def get_access(person_id):
    access = load_access()
    return access.get(person_id, {}).get("status", "allow")

def block_person(person_id, reason="AI Detected Threat"):
    """Auto-block person after strike limit reached."""
    persons = load_persons()
    name    = persons.get(person_id, {}).get("name", "Unknown")
    set_access(person_id, name, "deny")
    log_event(person_id, name, "AUTO_BLOCKED", reason)
    print(f"[🚫 BLOCKED] {name} ({person_id[:8]}) — {reason}")

# ============================================================
# STRIKE SYSTEM  (new — tracks AI anomaly counts per person)
# ============================================================

strikes: Dict[str, int] = {}
strikes_lock = threading.Lock()

def add_strike(person_id: str, reason: str) -> int:
    with strikes_lock:
        strikes[person_id] = strikes.get(person_id, 0) + 1
        count = strikes[person_id]
    print(f"[⚠️  STRIKE {count}/{STRIKE_LIMIT}] {person_id[:8]} — {reason}")
    if count >= STRIKE_LIMIT:
        block_person(person_id, f"Strike limit reached: {reason}")
    return count

# ============================================================
# EVENT LOGGING  (extended with alert file)
# ============================================================

def log_event(person_id, name, event, detail=""):
    with json_lock:
        events = read_json(EVENTS_FILE)
        events.setdefault(person_id, []).append({
            "timestamp": datetime.datetime.now().isoformat(),
            "event":     event,
            "name":      name,
            "detail":    detail
        })
        write_json(EVENTS_FILE, events)

def log_alert(person_id, name, alert_type, description, evidence_path=""):
    """Separate high-priority alert log."""
    with json_lock:
        alerts = read_json(ALERTS_FILE)
        if not isinstance(alerts, list):
            alerts = []
        alerts.append({
            "timestamp":    datetime.datetime.now().isoformat(),
            "person_id":    person_id,
            "name":         name,
            "alert_type":   alert_type,
            "description":  description,
            "evidence":     evidence_path,
            "model_used":   OLLAMA_MODEL
        })
        # Keep last 500 alerts
        alerts = alerts[-500:]
        write_json(ALERTS_FILE, alerts)

# ============================================================
# LOITERING TRACKER  (new — tracks dwell time per person)
# ============================================================

dwell_start: Dict[str, float] = {}
loiter_alerted: set            = set()
dwell_lock = threading.Lock()

def update_dwell(person_id: str) -> float:
    with dwell_lock:
        if person_id not in dwell_start:
            dwell_start[person_id] = time.time()
        return time.time() - dwell_start[person_id]

def clear_dwell(person_id: str):
    with dwell_lock:
        dwell_start.pop(person_id, None)
        loiter_alerted.discard(person_id)

# ============================================================
# TRACKING HELPERS  (unchanged)
# ============================================================

def centroid(location):
    top, right, bottom, left = location
    return ((left + right) / 2, (top + bottom) / 2)

def distance(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])

# ============================================================
# TRACK CLASS  (extended with dwell and frame counter)
# ============================================================

@dataclass
class Track:
    person_id:    str
    name:         str
    center:       Tuple[float, float]
    lost_frames:  int   = 0
    dwell_start:  float = field(default_factory=time.time)
    frame_count:  int   = 0

    def dwell_seconds(self) -> float:
        return time.time() - self.dwell_start

# ============================================================
# RECOGNIZER  (unchanged)
# ============================================================

class Recognizer:
    def __init__(self):
        self.threshold = FACE_MATCH_THRESHOLD

    def detect(self, rgb_frame):
        locations = face_recognition.face_locations(rgb_frame, model=FACE_MODEL)
        filtered  = []
        h, w = rgb_frame.shape[:2]
        for loc in locations:
            top, right, bottom, left = loc
            if (right - left) < MIN_FACE_WIDTH:   continue
            if (bottom - top) < MIN_FACE_HEIGHT:   continue
            if top < 0 or left < 0:               continue
            if right > w or bottom > h:            continue
            filtered.append(loc)
        encodings = face_recognition.face_encodings(rgb_frame, filtered)
        return [{"location": loc, "encoding": enc} for loc, enc in zip(filtered, encodings)]

    def best_match(self, encoding, known_people):
        if not known_people:
            return None
        known_encodings = [np.array(p["encoding"]) for p in known_people]
        distances       = face_recognition.face_distance(known_encodings, encoding)
        index           = int(np.argmin(distances))
        if float(distances[index]) <= self.threshold:
            return known_people[index]
        return None

# ============================================================
# AI ANOMALY DETECTOR  (new — wraps Ollama VLM)
# ============================================================

class AnomalyDetector:
    """
    Sends CCTV frames to the configured Ollama VLM model.
    Returns structured anomaly results.
    """

    # Prompt tuned for face-recognition CCTV context
    PROMPT = """You are an AI security camera monitoring a building entrance or restricted area.

Analyze this CCTV frame carefully. People are identified and tracked.

Look for:
1. TAILGATING — someone following closely behind an authorized person
2. LOITERING — person standing near entrance without clear purpose
3. AGGRESSION — threatening posture, raised fists, physical contact
4. SUSPICIOUS BEHAVIOR — unusual movement, hiding face, unusual items
5. TRESPASSING — person in restricted area
6. NORMAL — authorized activity, nothing suspicious

Describe what you observe in exactly 2 sentences.

Then on a new line write EXACTLY one of:
STATUS: NORMAL
STATUS: MEDIUM
STATUS: RISK

If STATUS is MEDIUM or RISK, on the next line write:
ANOMALY: <one word: TAILGATING, LOITERING, AGGRESSION, SUSPICIOUS, TRESPASSING>
"""

    def __init__(self, model: str = OLLAMA_MODEL):
        self.model = model
        self._available = None

    def is_available(self) -> bool:
        if self._available is None:
            try:
                models = ollama.list()
                names  = [m.get("name","") for m in models.get("models",[])]
                base   = self.model.split(":")[0]
                self._available = any(base in n for n in names)
            except Exception:
                self._available = False
        return self._available

    def _encode_frame(self, frame: np.ndarray) -> str:
        pil  = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        # Resize to 640×480 max for speed
        pil.thumbnail((640, 480))
        buf  = BytesIO()
        pil.save(buf, format="JPEG", quality=80)
        return base64.b64encode(buf.getvalue()).decode()

    def analyze(self, frame: np.ndarray, person_count: int = 0) -> dict:
        """
        Returns:
          {
            "status":       "normal" | "medium" | "risk",
            "anomaly_type": str | None,
            "description":  str,
            "raw":          str
          }
        """
        if not self.is_available():
            return {"status":"normal","anomaly_type":None,"description":"AI offline","raw":""}

        try:
            b64  = self._encode_frame(frame)
            resp = ollama.generate(
                model  = self.model,
                prompt = self.PROMPT + f"\n\nPeople visible in frame: {person_count}",
                images = [b64]
            )
            text = resp.get("response","").strip()

            status  = "normal"
            anomaly = None
            if "STATUS: RISK"   in text.upper(): status = "risk"
            elif "STATUS: MEDIUM" in text.upper(): status = "medium"
            for line in text.splitlines():
                if line.upper().strip().startswith("ANOMALY:"):
                    anomaly = line.split(":",1)[1].strip()

            desc_lines = [
                l for l in text.splitlines()
                if not l.upper().strip().startswith(("STATUS:","ANOMALY:"))
            ]
            description = " ".join(desc_lines).strip()

            return {
                "status":       status,
                "anomaly_type": anomaly,
                "description":  description,
                "raw":          text
            }
        except Exception as e:
            print(f"[AI ERROR] {e}")
            return {"status":"normal","anomaly_type":None,"description":f"AI error: {e}","raw":""}

# ============================================================
# APP STATE  (unchanged)
# ============================================================

class AppState:
    def __init__(self):
        self.frames     = {}
        self.lock       = threading.Lock()
        self.stop_event = threading.Event()

    def set_frame(self, source, frame):
        with self.lock:
            self.frames[str(source)] = frame.copy()

    def get_frames(self):
        with self.lock:
            return {k: v.copy() for k, v in self.frames.items()}

    def stop(self):
        self.stop_event.set()

    def should_stop(self):
        return self.stop_event.is_set()

# ============================================================
# CAMERA WORKER  (extended with AI anomaly + strike + loiter)
# ============================================================

class CameraWorker(threading.Thread):

    def __init__(self, source, state: AppState):
        super().__init__(daemon=True)
        self.source    = source
        self.state     = state
        self.stop_signal  = threading.Event()
        self.recognizer   = Recognizer()
        self.ai_detector  = AnomalyDetector(OLLAMA_MODEL)
        self.tracks: List[Track] = []
        self._frame_count = 0

        # Warn if AI not available
        if self.ai_detector.is_available():
            print(f"[AI ✅] Model '{OLLAMA_MODEL}' ready")
        else:
            print(f"[AI ⚠️ ] Model '{OLLAMA_MODEL}' not found — face recognition only")
            print(f"         Run: ollama pull {OLLAMA_MODEL}")

    # --------------------------------------------------------
    # OPEN CAMERA  (unchanged)
    # --------------------------------------------------------

    @staticmethod
    def open_camera(source):
        cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        w   = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h   = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = int(cap.get(cv2.CAP_PROP_FPS))
        print(f"[CAMERA INFO] Width={w} Height={h} FPS={fps}")
        return cap

    # --------------------------------------------------------
    # TRACK MATCH  (unchanged)
    # --------------------------------------------------------

    def find_track(self, center):
        best_index    = None
        best_distance = float("inf")
        for i, track in enumerate(self.tracks):
            d = distance(center, track.center)
            if d < TRACK_DISTANCE and d < best_distance:
                best_distance = d
                best_index    = i
        return best_index

    # --------------------------------------------------------
    # DRAW OVERLAY  (extended: shows AI status, dwell time)
    # --------------------------------------------------------

    def draw_overlay(self, frame, location, name, access, dwell_secs,
                     ai_status="normal", anomaly_type=None):
        top, right, bottom, left = location
        top    = int(top    / FRAME_RESIZE)
        right  = int(right  / FRAME_RESIZE)
        bottom = int(bottom / FRAME_RESIZE)
        left   = int(left   / FRAME_RESIZE)

        # Color: green=allow, red=deny, orange=AI alert
        if access == "deny":
            color = (0, 0, 255)       # red
        elif ai_status in ("medium", "risk"):
            color = (0, 140, 255)     # orange
        else:
            color = (0, 220, 0)       # green

        cv2.rectangle(frame, (left, top), (right, bottom), color, 2)

        label = f"{name} | {access.upper()}"
        if dwell_secs >= 10:
            label += f" | {int(dwell_secs)}s"
        if anomaly_type:
            label += f" | ⚠{anomaly_type}"

        cv2.putText(frame, label, (left, top - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

    # --------------------------------------------------------
    # MAIN LOOP  (enhanced with AI anomaly detection)
    # --------------------------------------------------------

    def run(self):
        print(f"[CAMERA] Starting {self.source}")
        cap = self.open_camera(self.source)

        if not cap.isOpened():
            print(f"[ERROR] Cannot open {self.source}")
            return

        frame_counter = 0
        last_ai_result = {"status":"normal","anomaly_type":None,"description":""}

        while (
            not self.stop_signal.is_set()
            and not self.state.should_stop()
        ):
            success, frame = cap.read()

            if not success:
                print(f"[WARNING] Reconnecting {self.source}")
                cap.release()
                time.sleep(2)
                cap = self.open_camera(self.source)
                continue

            if not is_frame_valid(frame):
                continue

            frame_counter += 1

            # Process every 2nd frame (same as original)
            if frame_counter % 2 != 0:
                continue

            self._frame_count += 1

            try:
                small_frame = cv2.resize(frame, (0,0), fx=FRAME_RESIZE, fy=FRAME_RESIZE)
                rgb         = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
                faces       = self.recognizer.detect(rgb)
                persons     = load_persons()

                known_people = [
                    {"id": pid, "name": data["name"], "encoding": data["encoding"]}
                    for pid, data in persons.items()
                ]

                matched_tracks = set()
                active_person_ids = []

                for face in faces:
                    location = face["location"]
                    encoding = face["encoding"]
                    center   = centroid(location)

                    track_index = self.find_track(center)

                    if track_index is not None:
                        # Update existing track
                        track = self.tracks[track_index]
                        matched_tracks.add(track_index)
                        track.center      = center
                        track.lost_frames = 0
                        track.frame_count += 1
                        person_id = track.person_id
                        name      = track.name
                        dwell_secs = track.dwell_seconds()

                    else:
                        # New detection — recognize or register
                        match = self.recognizer.best_match(encoding, known_people)

                        if match:
                            person_id = match["id"]
                            name      = match["name"]
                        else:
                            person_id = str(uuid.uuid4())
                            name      = f"Person-{person_id[:8]}"

                            face_path = save_face(frame, location, name, person_id)
                            if face_path is None:
                                continue

                            persons[person_id] = {
                                "id":          person_id,
                                "name":        name,
                                "encoding":    encoding.tolist(),
                                "face_image":  face_path,
                                "created_at":  datetime.datetime.now().isoformat()
                            }
                            save_persons(persons)
                            set_access(person_id, name, "allow")
                            log_event(person_id, name, "NEW_PERSON")
                            print(f"[NEW PERSON] {name}")

                        new_track = Track(
                            person_id=person_id,
                            name=name,
                            center=center
                        )
                        self.tracks.append(new_track)
                        matched_tracks.add(len(self.tracks) - 1)
                        dwell_secs = 0.0

                    active_person_ids.append(person_id)

                    # ── LOITERING CHECK ─────────────────────
                    if dwell_secs >= LOITER_SECONDS:
                        if person_id not in loiter_alerted:
                            with dwell_lock:
                                loiter_alerted.add(person_id)
                            log_event(person_id, name, "LOITERING",
                                      f"Dwell time: {int(dwell_secs)}s")
                            log_alert(person_id, name, "LOITERING",
                                      f"Person loitering for {int(dwell_secs)}s")
                            add_strike(person_id, "LOITERING")
                            print(f"[⏱  LOITERING] {name} — {int(dwell_secs)}s")

                    access = get_access(person_id)

                    self.draw_overlay(
                        frame, location, name, access, dwell_secs,
                        last_ai_result["status"],
                        last_ai_result.get("anomaly_type") if access != "deny" else None
                    )

                # ── AI ANOMALY DETECTION (every N frames) ───
                if self._frame_count % ANOMALY_EVERY_N_FRAMES == 0 and faces:
                    ai_result = self.ai_detector.analyze(frame, len(faces))
                    last_ai_result = ai_result

                    if ai_result["status"] in ("medium", "risk"):
                        evidence_path = save_evidence(
                            frame,
                            ai_result.get("anomaly_type","unknown") or "unknown"
                        )
                        print(
                            f"[🚨 AI ALERT] Status={ai_result['status'].upper()} "
                            f"Anomaly={ai_result['anomaly_type']} | "
                            f"{ai_result['description'][:80]}"
                        )

                        # Link alert to visible persons
                        for pid in active_person_ids:
                            persons_db = load_persons()
                            pname = persons_db.get(pid, {}).get("name", "Unknown")
                            log_event(pid, pname, f"AI_{ai_result['status'].upper()}",
                                      ai_result["description"])
                            log_alert(pid, pname,
                                      ai_result.get("anomaly_type","UNKNOWN"),
                                      ai_result["description"],
                                      evidence_path)

                            if ai_result["status"] == "risk":
                                add_strike(pid, ai_result.get("anomaly_type","RISK"))

                # ── DRAW AI STATUS BANNER ────────────────────
                status = last_ai_result["status"]
                banner_color = {
                    "normal": (30, 120, 30),
                    "medium": (20, 100, 180),
                    "risk":   (0, 0, 200)
                }.get(status, (30,30,30))

                banner_text = (
                    f"AI: {status.upper()}"
                    + (f" | {last_ai_result['anomaly_type']}"
                       if last_ai_result.get("anomaly_type") else "")
                    + f"  |  Faces: {len(faces)}"
                    + f"  |  Model: {OLLAMA_MODEL}"
                )
                cv2.rectangle(frame, (0, 0), (frame.shape[1], 28), banner_color, -1)
                cv2.putText(frame, banner_text, (8, 18),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)

                # ── CLEAN STALE TRACKS ───────────────────────
                for i, track in enumerate(self.tracks):
                    if i not in matched_tracks:
                        track.lost_frames += 1

                self.tracks = [t for t in self.tracks if t.lost_frames < TRACK_LOST_FRAMES]

                self.state.set_frame(self.source, frame)

            except Exception as e:
                print(f"[ERROR] {e}")

            time.sleep(0.03)

        cap.release()

    def stop(self):
        self.stop_signal.set()

# ============================================================
# WORKER HELPERS  (unchanged)
# ============================================================

def start_workers(state):
    workers = []
    for src in CAMERA_SOURCES:
        w = CameraWorker(src, state)
        w.start()
        workers.append(w)
    return workers

def stop_workers(workers):
    for w in workers: w.stop()
    for w in workers: w.join(timeout=2)

# ============================================================
# MAIN  (unchanged pattern)
# ============================================================

if __name__ == "__main__":
    print("\n" + "="*50)
    print(" AI CCTV FACE SECURITY SYSTEM — VLM ENHANCED")
    print("="*50)
    print(f" Cameras     : {CAMERA_SOURCES}")
    print(f" Face Model  : {FACE_MODEL}")
    print(f" AI Model    : {OLLAMA_MODEL}")
    print(f" Strike Limit: {STRIKE_LIMIT}")
    print(f" Loiter Secs : {LOITER_SECONDS}")
    print(f" AI Every N  : {ANOMALY_EVERY_N_FRAMES} frames")
    print("="*50 + "\n")

    state   = AppState()
    workers = start_workers(state)

    try:
        while not state.should_stop():
            frames = state.get_frames()
            for source, frame in frames.items():
                cv2.imshow(f"AI CCTV — {source}", frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), 27):
                state.stop()
            time.sleep(0.01)

    except KeyboardInterrupt:
        state.stop()

    finally:
        stop_workers(workers)
        cv2.destroyAllWindows()
        print("\nSystem stopped.\n")
