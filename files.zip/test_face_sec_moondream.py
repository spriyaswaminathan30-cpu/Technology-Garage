#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║  FACE SECURITY TEST — moondream:latest (1.8B)               ║
║  Scenario: Building entrance / access control CCTV          ║
║  Device  : Jetson Orin Nano 4GB                             ║
║  Speed   : ⚡⚡⚡⚡  |  Accuracy: ★★★☆☆               ║
╚══════════════════════════════════════════════════════════════╝

TESTS COVERED:
  1. Model availability
  2. Face presence detection
  3. Access control — authorized person
  4. Access control — denied/blocked person
  5. Tailgating detection
  6. Loitering detection
  7. Aggression / suspicious behavior
  8. Multiple persons scene
  9. Structured output format
  10. Speed benchmark

RUN:
  ollama pull moondream:latest
  python3 test_face_sec_moondream.py
  python3 test_face_sec_moondream.py --image /path/to/cctv_frame.jpg
"""

import ollama
import base64
import time
import sys
import argparse
from datetime import datetime
from PIL import Image, ImageDraw
from io import BytesIO

MODEL = "moondream:latest"
G, R, Y, B, BOLD, DIM, RESET = (
    "\033[92m","\033[91m","\033[93m","\033[94m",
    "\033[1m","\033[2m","\033[0m"
)

# ─── PROMPT (tuned for face-recognition entrance scenario) ───

PROMPT = """You are monitoring a building entrance security camera.
People have ID badges. Authorized people have green badges. Denied people may act suspiciously.

Look at this CCTV frame and describe in 2 sentences what is happening.

Then write one of:
STATUS: NORMAL
STATUS: MEDIUM
STATUS: RISK

If MEDIUM or RISK add:
ANOMALY: TAILGATING
or ANOMALY: LOITERING
or ANOMALY: AGGRESSION
or ANOMALY: SUSPICIOUS
or ANOMALY: TRESPASSING
"""

# ─── SYNTHETIC FRAME GENERATOR ────────────────────────────────

def make_frame(scenario: str) -> Image.Image:
    """Create labeled CCTV test frames for entrance/lobby scenario."""
    w, h = 640, 480
    bg = {
        "authorized":   (40, 55, 40),
        "denied":       (70, 30, 30),
        "tailgating":   (55, 50, 30),
        "loitering":    (50, 50, 70),
        "aggression":   (80, 25, 25),
        "multi_person": (40, 50, 45),
        "empty":        (25, 25, 25),
    }.get(scenario, (40, 55, 40))

    img = Image.new("RGB", (w, h), bg)
    d   = ImageDraw.Draw(img)

    # CCTV header
    d.rectangle([0, 0, w, 42], fill=(0, 0, 0))
    d.text((8, 7),  f"ENTRANCE CAM-01   {datetime.now().strftime('%H:%M:%S')}   LOBBY", fill="white")
    d.text((8, 24), f"TEST: {scenario.upper()}", fill=(255, 220, 50))

    # Floor / walls
    d.rectangle([0, h-70, w, h],    fill=(55, 45, 38))
    d.line([(0, h-70), (w, h-70)],  fill=(160, 140, 120), width=2)
    # Door frame
    d.rectangle([270, 60, 380, h-70], fill=(30, 30, 35), outline=(180, 160, 130), width=3)
    d.text((285, 65), "ENTRANCE", fill=(200, 180, 100))

    def person(cx, cy, badge="green", pose="stand"):
        skin  = (210, 175, 140)
        shirt = (80, 90, 160) if badge == "green" else (160, 60, 60)
        d.ellipse([cx-22, cy-62, cx+22, cy-12], fill=skin, outline="white")
        d.rectangle([cx-16, cy-12, cx+16, cy+80], fill=shirt, outline="white")
        d.line([(cx-16, cy+8),  (cx-42, cy+52)], fill=skin, width=4)
        d.line([(cx+16, cy+8),  (cx+42, cy+52)], fill=skin, width=4)
        d.rectangle([cx-18, cy+80, cx-4,  cy+148], fill=(35, 35, 35))
        d.rectangle([cx+4,  cy+80, cx+18, cy+148], fill=(35, 35, 35))
        # Badge
        badge_color = (0, 200, 80) if badge == "green" else (220, 40, 40)
        d.rectangle([cx-10, cy+5, cx+10, cy+25], fill=badge_color, outline="white")
        d.text((cx-7, cy+8), "ID", fill="white")

    if scenario == "authorized":
        person(320, 180, "green")
        d.text((290, 380), "ACCESS: ALLOWED", fill=(0, 220, 80))

    elif scenario == "denied":
        person(320, 180, "red")
        d.text((280, 380), "ACCESS: DENIED", fill=(220, 40, 40))
        d.rectangle([290, 390, 360, 415], fill=(200, 30, 30))
        d.text((295, 395), "BLOCKED", fill="white")

    elif scenario == "tailgating":
        person(300, 175, "green")
        person(360, 200, "red")   # close behind
        d.text((230, 380), "⚠ POSSIBLE TAILGATING", fill=(255, 160, 0))

    elif scenario == "loitering":
        person(160, 195, "red")
        d.text((100, 380), "⏱ LOITERING NEAR ENTRANCE", fill=(255, 160, 0))

    elif scenario == "aggression":
        person(255, 180, "green")
        person(385, 180, "red")
        # Raised arm indicator
        d.line([(370, 145), (415, 110)], fill=(210, 175, 140), width=5)
        d.text((215, 380), "⚠ AGGRESSIVE BEHAVIOR", fill=(255, 50, 50))

    elif scenario == "multi_person":
        person(180, 185, "green")
        person(320, 190, "green")
        person(460, 185, "green")
        d.text((210, 380), "3 AUTHORIZED PERSONS", fill=(0, 200, 80))

    d.text((5, 463), "Synthetic test frame — replace with real CCTV for production", fill=(120,120,120))
    return img

def encode(img):
    buf = BytesIO()
    img.save(buf, format="JPEG", quality=85)
    return base64.b64encode(buf.getvalue()).decode()

def query(prompt, img=None):
    start  = time.time()
    kwargs = dict(model=MODEL, prompt=prompt)
    if img: kwargs["images"] = [encode(img)]
    resp = ollama.generate(**kwargs)
    return resp.get("response","").strip(), time.time()-start

def parse(text):
    status, anomaly = "normal", None
    t = text.upper()
    if "STATUS: RISK"   in t: status = "risk"
    elif "STATUS: MEDIUM" in t: status = "medium"
    for line in text.splitlines():
        if line.upper().strip().startswith("ANOMALY:"):
            anomaly = line.split(":",1)[1].strip()
    return {"status": status, "anomaly": anomaly}

def show(label, passed, resp, elapsed, expected="", notes=""):
    icon  = "✅" if passed else "❌"
    color = G if passed else R
    print(f"{color}{icon} {label}{RESET}")
    if expected: print(f"   📌 Expected : {expected}")
    print(f"   ⏱  Time    : {elapsed:.2f}s")
    print(f"   📝 Response : {resp[:240]}{'...' if len(resp)>240 else ''}")
    if notes: print(f"   💡 Notes   : {notes}")
    print()

# ─── TESTS ────────────────────────────────────────────────────

def run(img_path=None):
    print(f"\n{B}{'═'*62}")
    print(f"  🤖 FACE SECURITY TEST — {MODEL}")
    print(f"  Scenario: Building Entrance / Access Control")
    print(f"  Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'═'*62}{RESET}\n")

    # Check availability
    print(f"{B}[TEST 0] Model availability{RESET}")
    try:
        models = ollama.list()
        names  = [m.get("name","") for m in models.get("models",[])]
        if not any("moondream" in n for n in names):
            print(f"  {R}❌ Not installed. Run: ollama pull {MODEL}{RESET}\n")
            sys.exit(1)
        print(f"  {G}✅ {MODEL} ready{RESET}\n")
    except Exception as e:
        print(f"  {R}❌ Ollama not running: {e}{RESET}\n")
        sys.exit(1)

    results = {}

    # T1: Basic
    print(f"{B}[TEST 1] Basic text response{RESET}")
    r, t = query("Reply: MOONDREAM_READY")
    ok   = len(r) > 2
    show("Basic Text", ok, r, t, "MOONDREAM_READY")
    results["basic"] = ok

    # T2: Face in frame
    print(f"{B}[TEST 2] Person detection{RESET}")
    r, t = query("Is there a person in this image? Reply YES or NO.", make_frame("authorized"))
    ok   = "YES" in r.upper() or "person" in r.lower() or "individual" in r.lower()
    show("Person Presence", ok, r, t, "YES / mentions a person",
         "Moondream should confirm a person is visible")
    results["person_detect"] = ok

    # T3: Authorized (normal)
    print(f"{B}[TEST 3] Authorized person → STATUS: NORMAL{RESET}")
    img = Image.open(img_path) if img_path else make_frame("authorized")
    r, t = query(PROMPT, img)
    p    = parse(r)
    ok   = p["status"] == "normal"
    show("Authorized Person (NORMAL)", ok, r, t, "STATUS: NORMAL", f"Got: {p['status'].upper()}")
    results["authorized"] = ok

    # T4: Denied person
    print(f"{B}[TEST 4] Denied/blocked person → STATUS: MEDIUM or RISK{RESET}")
    img  = Image.open(img_path) if img_path else make_frame("denied")
    r, t = query(PROMPT, img)
    p    = parse(r)
    ok   = p["status"] in ("medium","risk") or "deny" in r.lower() or "block" in r.lower()
    show("Denied Person", ok, r, t, "STATUS: MEDIUM/RISK or mentions denied/blocked",
         f"Got: {p['status'].upper()} | ⚠️ Synthetic frame — moondream may not detect red badge")
    results["denied"] = ok

    # T5: Tailgating
    print(f"{B}[TEST 5] Tailgating detection{RESET}")
    img  = make_frame("tailgating")
    r, t = query(PROMPT, img)
    p    = parse(r)
    ok   = p["status"] in ("medium","risk") or "tailgat" in r.lower() or "follow" in r.lower()
    show("Tailgating", ok, r, t, "STATUS: MEDIUM/RISK + ANOMALY: TAILGATING",
         f"Got: {p['status'].upper()} | Moondream often misses tailgating on synthetic frames")
    results["tailgating"] = ok

    # T6: Loitering
    print(f"{B}[TEST 6] Loitering near entrance{RESET}")
    img  = make_frame("loitering")
    r, t = query(PROMPT, img)
    p    = parse(r)
    ok   = p["status"] in ("medium","risk") or "loiter" in r.lower() or "standing" in r.lower()
    show("Loitering", ok, r, t, "STATUS: MEDIUM/RISK + ANOMALY: LOITERING",
         f"Got: {p['status'].upper()}")
    results["loitering"] = ok

    # T7: Aggression
    print(f"{B}[TEST 7] Aggression detection{RESET}")
    img  = make_frame("aggression")
    r, t = query(PROMPT, img)
    p    = parse(r)
    ok   = p["status"] in ("medium","risk") or "aggress" in r.lower() or "confron" in r.lower()
    show("Aggression", ok, r, t, "STATUS: RISK + ANOMALY: AGGRESSION",
         f"Got: {p['status'].upper()}")
    results["aggression"] = ok

    # T8: Multi-person
    print(f"{B}[TEST 8] Multi-person scene{RESET}")
    img  = make_frame("multi_person")
    r, t = query("How many people do you see? Reply with a number.", img)
    ok   = any(str(n) in r for n in range(1,7))
    show("Multi-Person Count", ok, r, t, "A number (ideally 3)",
         "Moondream is fast but less accurate at counting vs Qwen2.5-VL")
    results["multi_person"] = ok

    # T9: Format
    print(f"{B}[TEST 9] Structured output compliance{RESET}")
    r, t = query(PROMPT, make_frame("authorized"))
    ok   = "STATUS:" in r.upper()
    show("Format (STATUS: line)", ok, r, t, "Response containing STATUS:",
         "⚠️ Moondream sometimes skips format — prompt may need tuning")
    results["format"] = ok

    # T10: Speed
    print(f"{B}[TEST 10] Speed benchmark (5 frames){RESET}")
    img   = make_frame("authorized")
    times = []
    for i in range(5):
        _, t = query("One word: is this normal or suspicious?", img)
        times.append(t)
        print(f"   Frame {i+1}: {t:.1f}s")
    avg = sum(times)/len(times)
    n   = max(8, int(30*avg))
    ok  = avg < 12.0
    print()
    show(f"Speed ({avg:.1f}s avg | {1/avg:.2f} FPS equiv)",
         ok, str([f"{t:.1f}s" for t in times]), avg,
         "< 12s/frame on Orin Nano 4GB",
         f"Set ANOMALY_EVERY_N_FRAMES = {n} in ai_cctv_face_security.py")
    results["speed"] = ok

    # ─── SUMMARY ──────────────────────────────────────────────
    print(f"\n{B}{'═'*62}")
    print(f"  📊 RESULTS — {MODEL}")
    print(f"{'═'*62}{RESET}")
    passed = sum(1 for v in results.values() if v is True)
    total  = len(results)
    for k,v in results.items():
        color = G if v else R
        icon  = "✅" if v else "❌"
        print(f"  {color}{icon} {k.replace('_',' ').title()}{RESET}")
    print(f"\n  Score: {passed}/{total}")

    avg_all = sum(times)/len(times)
    n       = max(8, int(30*avg_all))
    print(f"\n{B}  💡 CONFIG FOR ai_cctv_face_security.py:{RESET}")
    print(f'{BOLD}     OLLAMA_MODEL           = "{MODEL}"{RESET}')
    print(f'{BOLD}     ANOMALY_EVERY_N_FRAMES  = {n}{RESET}')
    print(f"\n{B}  ⚠️  MOONDREAM NOTES:{RESET}")
    print(f"     - Best for Orin Nano 4GB (only model that fits)")
    print(f"     - May miss subtle threats (tailgating, badge color)")
    print(f"     - Use real CCTV frames for accurate detection rates")
    print(f"     - Upgrade to qwen2.5vl:3b on 8GB for better results\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", type=str, help="Real CCTV frame path")
    args = parser.parse_args()
    import argparse
    run(args.image)
