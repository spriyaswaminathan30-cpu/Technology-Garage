#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║  FACE SECURITY TEST — qwen2.5vl:3b (RECOMMENDED)           ║
║  Scenario: Building entrance / access control CCTV          ║
║  Device  : Jetson Orin Nano 8GB  ← BEST CHOICE             ║
║  Speed   : ⚡⚡⚡☆  |  Accuracy: ★★★★☆               ║
╚══════════════════════════════════════════════════════════════╝

TESTS COVERED:
  1.  Model availability
  2.  Basic image description
  3.  Person count accuracy
  4.  Authorized person → STATUS: NORMAL
  5.  Denied/blocked person → STATUS: RISK
  6.  Tailgating detection → ANOMALY: TAILGATING
  7.  Loitering detection → ANOMALY: LOITERING
  8.  Aggression detection → ANOMALY: AGGRESSION
  9.  Badge color reasoning (Qwen strength)
  10. Spatial position reasoning (Qwen strength)
  11. Structured output compliance
  12. Speed benchmark (5 frames)

EXPECTED OUTPUTS:
  T4 Authorized   → "An individual is entering... STATUS: NORMAL"
  T5 Denied       → "A person with a denied badge... STATUS: RISK\nANOMALY: SUSPICIOUS"
  T6 Tailgating   → "Two people near the entrance... STATUS: RISK\nANOMALY: TAILGATING"
  T7 Loitering    → "A person is standing... STATUS: MEDIUM\nANOMALY: LOITERING"
  T8 Aggression   → "Two individuals... raised arm... STATUS: RISK\nANOMALY: AGGRESSION"

RUN:
  ollama pull qwen2.5vl:3b
  python3 test_face_sec_qwen25.py
  python3 test_face_sec_qwen25.py --image /path/to/real_cctv.jpg
"""

import ollama
import base64
import time
import sys
import argparse
from datetime import datetime
from PIL import Image, ImageDraw
from io import BytesIO

MODEL = "qwen2.5vl:3b"
G, R, Y, B, BOLD, DIM, RESET = (
    "\033[92m","\033[91m","\033[93m","\033[94m",
    "\033[1m","\033[2m","\033[0m"
)

# ─── PROMPT (Qwen handles structured output very reliably) ───

PROMPT = """You are an AI security system monitoring a building entrance camera.

This is a CCTV frame from a face recognition access control system.
Green badges = authorized access. Red badges = denied / blocked person.

Carefully analyze the frame and describe in exactly 2 sentences what you observe.

Then on a NEW LINE write EXACTLY one of:
STATUS: NORMAL
STATUS: MEDIUM
STATUS: RISK

Definitions:
- NORMAL  = authorized people, normal entry/exit behavior
- MEDIUM  = potentially suspicious, needs monitoring (slow entry, unusual pause)
- RISK    = immediate alert required (tailgating, denied person active, aggression, trespassing)

If STATUS is MEDIUM or RISK, write on the NEXT LINE:
ANOMALY: TAILGATING
or ANOMALY: LOITERING
or ANOMALY: AGGRESSION
or ANOMALY: SUSPICIOUS
or ANOMALY: TRESPASSING
"""

COUNT_PROMPT = "How many people are visible in this image? Reply with ONLY a number."
BADGE_PROMPT = "Are any of the people wearing red badges? Reply YES or NO and explain briefly."
SPATIAL_PROMPT = "Describe the position of each person in the frame (left/center/right, near/far from entrance)."

# ─── SCENE GENERATOR ─────────────────────────────────────────

def make_frame(scenario: str) -> Image.Image:
    w, h = 640, 480
    bg = {
        "authorized":   (40, 58, 40),
        "denied":       (72, 28, 28),
        "tailgating":   (58, 52, 30),
        "loitering":    (48, 48, 72),
        "aggression":   (82, 22, 22),
        "multi_person": (40, 52, 45),
        "empty":        (22, 22, 22),
    }.get(scenario, (40, 58, 40))

    img = Image.new("RGB", (w, h), bg)
    d   = ImageDraw.Draw(img)

    d.rectangle([0, 0, w, 44],   fill=(0,0,0))
    d.text((8, 7),  f"ENTRANCE CAM-01   {datetime.now().strftime('%H:%M:%S')}   BUILDING LOBBY", fill="white")
    d.text((8, 26), f"QWEN TEST: {scenario.upper()}", fill=(100, 210, 255))

    # Floor, wall, door
    d.rectangle([0, h-72, w, h], fill=(55, 44, 36))
    d.line([(0, h-72), (w, h-72)], fill=(160, 140, 118), width=2)
    d.rectangle([268, 58, 382, h-72], fill=(25, 25, 32), outline=(175, 155, 125), width=3)
    d.text((285, 65), "ENTRANCE", fill=(200, 178, 95))
    # Door handle
    d.ellipse([358, 260, 372, 278], fill=(180,160,100), outline="white")

    def person(cx, cy, badge="green", action="stand"):
        skin  = (212, 178, 142)
        shirt = (78, 92, 165) if badge == "green" else (165, 55, 55)
        # Head
        d.ellipse([cx-23, cy-64, cx+23, cy-14], fill=skin, outline="white")
        # Body
        d.rectangle([cx-17, cy-14, cx+17, cy+82], fill=shirt, outline="white")
        # Arms
        if action == "raised_arm":
            d.line([(cx+17, cy+6), (cx+52, cy-30)], fill=skin, width=5)   # raised
            d.line([(cx-17, cy+6), (cx-42, cy+50)], fill=skin, width=4)
        else:
            d.line([(cx-17, cy+6), (cx-44, cy+52)], fill=skin, width=4)
            d.line([(cx+17, cy+6), (cx+44, cy+52)], fill=skin, width=4)
        # Legs
        d.rectangle([cx-19, cy+82, cx-5, cy+150], fill=(32,32,32))
        d.rectangle([cx+5,  cy+82, cx+19, cy+150], fill=(32,32,32))
        # Badge
        bc = (0, 205, 80) if badge == "green" else (215, 38, 38)
        d.rectangle([cx-11, cy+4, cx+11, cy+26], fill=bc, outline="white")
        d.text((cx-8, cy+7), "ID", fill="white")

    if scenario == "authorized":
        person(322, 182, "green")
        d.text((278, 375), "✅ ACCESS ALLOWED", fill=(0, 220, 80))

    elif scenario == "denied":
        person(322, 182, "red")
        d.rectangle([245, 380, 415, 408], fill=(200, 28, 28), outline="white", width=1)
        d.text((258, 387), "🚫 ACCESS DENIED — BLOCKED", fill="white")

    elif scenario == "tailgating":
        person(292, 175, "green")
        person(362, 198, "red")
        d.text((225, 375), "⚠️ TAILGATING DETECTED", fill=(255, 165, 0))
        d.line([(292+22, 175-14), (362-23, 198-14)], fill=(255,165,0), width=2)

    elif scenario == "loitering":
        person(155, 195, "red")
        d.text((90, 375), "⏱️ LOITERING — 8+ MINUTES", fill=(255, 165, 0))
        d.text((90, 395), "Near entrance, no badge scan", fill=(200, 150, 80))

    elif scenario == "aggression":
        person(248, 178, "green")
        person(392, 178, "red", action="raised_arm")
        d.rectangle([215, 378, 445, 406], fill=(200, 28, 28))
        d.text((222, 385), "⚠️ AGGRESSIVE BEHAVIOR", fill="white")

    elif scenario == "multi_person":
        person(152, 186, "green")
        person(322, 188, "green")
        person(492, 186, "green")
        d.text((192, 375), "3 AUTHORIZED PERSONS", fill=(0, 210, 80))

    d.text((5, 463), "Synthetic test frame — use real CCTV images for production testing", fill=(118,118,118))
    return img

def encode(img):
    buf = BytesIO()
    img.save(buf, format="JPEG", quality=85)
    return base64.b64encode(buf.getvalue()).decode()

def query(prompt, img=None):
    start  = time.time()
    kwargs = dict(model=MODEL, prompt=prompt)
    if img: kwargs["images"] = [encode(img)]
    resp = ollama.generate(**kwargs)
    return resp.get("response","").strip(), time.time()-start

def parse(text):
    status, anomaly = "normal", None
    t = text.upper()
    if "STATUS: RISK"    in t: status = "risk"
    elif "STATUS: MEDIUM" in t: status = "medium"
    for line in text.splitlines():
        if line.upper().strip().startswith("ANOMALY:"):
            anomaly = line.split(":",1)[1].strip()
    return {"status": status, "anomaly": anomaly}

def show(label, passed, resp, elapsed, expected="", notes=""):
    icon  = "✅" if passed else "❌"
    color = G if passed else R
    print(f"{color}{icon} {label}{RESET}")
    if expected: print(f"   📌 Expected  : {expected}")
    print(f"   ⏱  Time     : {elapsed:.2f}s")
    print(f"   📝 Response  : {resp[:280]}{'...' if len(resp)>280 else ''}")
    if notes: print(f"   💡 Notes    : {notes}")
    print()

# ─── TESTS ────────────────────────────────────────────────────

def run(img_path=None):
    print(f"\n{B}{'═'*62}")
    print(f"  🤖 FACE SECURITY TEST — {MODEL}  (RECOMMENDED)")
    print(f"  Scenario: Building Entrance / Access Control CCTV")
    print(f"  Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  ✨ Best for Jetson Orin Nano 8GB")
    print(f"{'═'*62}{RESET}\n")

    # T0: Available
    print(f"{B}[TEST 0] Model availability{RESET}")
    try:
        models = ollama.list()
        names  = [m.get("name","") for m in models.get("models",[])]
        if not any("qwen2.5vl" in n or "qwen2.5" in n for n in names):
            print(f"  {R}❌ Not installed. Run: ollama pull {MODEL}{RESET}\n")
            sys.exit(1)
        print(f"  {G}✅ {MODEL} ready{RESET}\n")
    except Exception as e:
        print(f"  {R}❌ Ollama error: {e}{RESET}\n"); sys.exit(1)

    results = {}

    # T1
    print(f"{B}[TEST 1] Basic response{RESET}")
    r, t = query("Reply: QWEN_READY")
    ok = len(r) > 2
    show("Basic Text", ok, r, t, "QWEN_READY"); results["basic"] = ok

    # T2
    print(f"{B}[TEST 2] Image scene description{RESET}")
    r, t = query("Describe this image in one sentence.", make_frame("authorized"))
    ok = len(r) > 15
    show("Image Description", ok, r, t,
         "A sentence describing the entrance/lobby scene",
         "Qwen2.5-VL should identify the entrance context accurately")
    results["description"] = ok

    # T3: Person count (Qwen strength)
    print(f"{B}[TEST 3] Person count — multi-person scene{RESET}")
    r, t = query(COUNT_PROMPT, make_frame("multi_person"))
    ok = any(str(n) in r for n in range(1, 7))
    show("Person Count (expect 3)", ok, r, t, "3",
         "Qwen2.5-VL excels at accurate counting")
    results["count"] = ok

    # T4: Authorized
    print(f"{B}[TEST 4] Authorized person → STATUS: NORMAL{RESET}")
    img  = Image.open(img_path) if img_path else make_frame("authorized")
    r, t = query(PROMPT, img)
    p    = parse(r)
    ok   = p["status"] == "normal"
    show("Authorized (NORMAL)", ok, r, t, "STATUS: NORMAL", f"Got: {p['status'].upper()}")
    results["authorized"] = ok

    # T5: Denied
    print(f"{B}[TEST 5] Denied/blocked person → STATUS: RISK{RESET}")
    img  = Image.open(img_path) if img_path else make_frame("denied")
    r, t = query(PROMPT, img)
    p    = parse(r)
    ok   = p["status"] in ("medium", "risk")
    show("Denied Person (RISK)", ok, r, t, "STATUS: RISK + ANOMALY: SUSPICIOUS",
         f"Got: {p['status'].upper()} ANOMALY={p['anomaly']}")
    results["denied"] = ok

    # T6: Tailgating
    print(f"{B}[TEST 6] Tailgating → STATUS: RISK + ANOMALY: TAILGATING{RESET}")
    r, t = query(PROMPT, make_frame("tailgating"))
    p    = parse(r)
    ok   = p["status"] in ("medium","risk") or "tailgat" in r.lower() or "follow" in r.lower()
    show("Tailgating", ok, r, t, "STATUS: RISK + ANOMALY: TAILGATING",
         f"Got: {p['status'].upper()} | Qwen2.5-VL detects proximity between people")
    results["tailgating"] = ok

    # T7: Loitering
    print(f"{B}[TEST 7] Loitering → STATUS: MEDIUM + ANOMALY: LOITERING{RESET}")
    r, t = query(PROMPT, make_frame("loitering"))
    p    = parse(r)
    ok   = p["status"] in ("medium","risk") or "loiter" in r.lower() or "standing" in r.lower()
    show("Loitering", ok, r, t, "STATUS: MEDIUM + ANOMALY: LOITERING",
         f"Got: {p['status'].upper()}")
    results["loitering"] = ok

    # T8: Aggression
    print(f"{B}[TEST 8] Aggression → STATUS: RISK + ANOMALY: AGGRESSION{RESET}")
    r, t = query(PROMPT, make_frame("aggression"))
    p    = parse(r)
    ok   = p["status"] in ("medium","risk") or "aggress" in r.lower() or "raised" in r.lower()
    show("Aggression", ok, r, t, "STATUS: RISK + ANOMALY: AGGRESSION",
         f"Got: {p['status'].upper()} | Qwen detects raised arm posture")
    results["aggression"] = ok

    # T9: Badge color (Qwen strength — visual detail reasoning)
    print(f"{B}[TEST 9] Badge color reasoning (Qwen visual strength){RESET}")
    r, t = query(BADGE_PROMPT, make_frame("denied"))
    ok   = "yes" in r.lower() or "red" in r.lower()
    show("Badge Color Reasoning", ok, r, t, "YES — mentions red badge",
         "Qwen2.5-VL can reason about visual details like badge color")
    results["badge_color"] = ok

    # T10: Spatial reasoning (Qwen strength)
    print(f"{B}[TEST 10] Spatial position reasoning{RESET}")
    r, t = query(SPATIAL_PROMPT, make_frame("multi_person"))
    ok   = any(w in r.lower() for w in ["left","right","center","entrance","near","far"])
    show("Spatial Reasoning", ok, r, t, "Describes left/right/center positions",
         "Qwen2.5-VL is strong at spatial understanding — useful for zone tracking")
    results["spatial"] = ok

    # T11: Format compliance
    print(f"{B}[TEST 11] Structured output format{RESET}")
    r, t = query(PROMPT, make_frame("authorized"))
    ok   = "STATUS:" in r.upper()
    show("Format (STATUS: line)", ok, r, t, "Response with STATUS: line",
         "Qwen2.5-VL follows structured instructions reliably (~95%)")
    results["format"] = ok

    # T12: Speed
    print(f"{B}[TEST 12] Speed benchmark (5 frames){RESET}")
    img   = make_frame("authorized")
    times = []
    for i in range(5):
        _, t = query("One sentence: what's happening at this entrance?", img)
        times.append(t)
        bar = "█" * min(20, int(t)) + "░" * max(0, 20-int(t))
        print(f"   Frame {i+1}: {t:5.1f}s  [{bar}]")
    avg = sum(times)/len(times)
    n   = max(8, int(30*avg))
    ok  = avg < 25.0
    print()
    show(f"Speed ({avg:.1f}s avg | {1/avg:.3f} FPS equiv)",
         ok, str([f"{t:.1f}s" for t in times]), avg, "< 25s/frame on Orin Nano 8GB",
         f"Set ANOMALY_EVERY_N_FRAMES = {n}")
    results["speed"] = ok

    # ─── SUMMARY ──────────────────────────────────────────────
    print(f"\n{B}{'═'*62}")
    print(f"  📊 RESULTS — {MODEL}")
    print(f"{'═'*62}{RESET}")
    passed = sum(1 for v in results.values() if v is True)
    total  = len(results)
    for k, v in results.items():
        color = G if v else R
        print(f"  {color}{'✅' if v else '❌'} {k.replace('_',' ').title()}{RESET}")
    print(f"\n  Score: {passed}/{total} {'🏆' if passed == total else ''}")

    print(f"\n{BOLD}  💡 PASTE INTO ai_cctv_face_security.py:{RESET}")
    print(f'{BOLD}     OLLAMA_MODEL           = "{MODEL}"{RESET}')
    print(f'{BOLD}     ANOMALY_EVERY_N_FRAMES  = {n}{RESET}')
    print(f'{BOLD}     LOITER_SECONDS          = 60{RESET}')
    print(f'{BOLD}     STRIKE_LIMIT            = 3{RESET}')

    print(f"\n{B}  🏆 QWEN2.5VL:3B ADVANTAGES FOR FACE SECURITY:{RESET}")
    print(f"     ✅ Detects badge colors (visual detail reasoning)")
    print(f"     ✅ Accurate person counting for multi-track scenarios")
    print(f"     ✅ Spatial reasoning for zone-based alerts")
    print(f"     ✅ Reliable STATUS:/ANOMALY: structured output")
    print(f"     ✅ Understands proximity (tailgating detection)")
    print(f"     ✅ Fits in Orin Nano 8GB within 3GB VRAM\n")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", type=str)
    args = parser.parse_args()
    run(args.image)
