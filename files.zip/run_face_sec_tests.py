#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║  FACE SECURITY — ALL MODELS COMPARISON RUNNER               ║
║  Tests all installed models against same scenarios          ║
╚══════════════════════════════════════════════════════════════╝

RUN:
  python3 run_face_sec_tests.py              # test all installed
  python3 run_face_sec_tests.py --model qwen # one model only
  python3 run_face_sec_tests.py --image f.jpg # use real frame
  python3 run_face_sec_tests.py --guide       # setup guide only
"""

import ollama
import base64
import time
import sys
import json
import argparse
from datetime import datetime
from PIL import Image, ImageDraw
from io import BytesIO

G,R,Y,B,BOLD,DIM,RESET=(
    "\033[92m","\033[91m","\033[93m","\033[94m",
    "\033[1m","\033[2m","\033[0m"
)

MODELS = {
    "moondream": {
        "tag":      "moondream:latest",
        "params":   "1.8B",
        "vram_gb":  1.5,
        "devices":  ["Orin Nano 4GB", "Orin Nano 8GB", "AGX Orin"],
        "pull":     "ollama pull moondream:latest",
        "speed":    "⚡⚡⚡⚡",
        "accuracy": "★★★☆☆",
        "notes":    "Fast but misses badge details. Orin Nano 4GB only option.",
        "prompt":   "simple",
    },
    "qwen": {
        "tag":      "qwen2.5vl:3b",
        "params":   "3B",
        "vram_gb":  3.0,
        "devices":  ["Orin Nano 8GB", "AGX Orin"],
        "pull":     "ollama pull qwen2.5vl:3b",
        "speed":    "⚡⚡⚡☆",
        "accuracy": "★★★★☆",
        "notes":    "BEST: badge color detection, spatial reasoning, reliable format.",
        "prompt":   "structured",
    },
    "llava": {
        "tag":      "llava:7b",
        "params":   "7B",
        "vram_gb":  6.5,
        "devices":  ["AGX Orin 32GB", "AGX Orin 64GB", "Desktop 8GB GPU"],
        "pull":     "ollama pull llava:7b",
        "speed":    "⚡⚡☆☆",
        "accuracy": "★★★★☆",
        "notes":    "Verbose descriptions, hallucinates occasionally.",
        "prompt":   "llava",
    },
    "gemma3": {
        "tag":      "gemma3:4b",
        "params":   "4B",
        "vram_gb":  3.5,
        "devices":  ["Orin Nano 8GB", "AGX Orin"],
        "pull":     "ollama pull gemma3:4b",
        "speed":    "⚡⚡⚡☆",
        "accuracy": "★★★★☆",
        "notes":    "Strong instruction-following, good alternative to Qwen.",
        "prompt":   "structured",
    },
}

PROMPTS = {
    "structured": """You are an AI security system at a building entrance.
Green badges = authorized. Red badges = DENIED/BLOCKED.

Describe what you see in 2 sentences.
Then write EXACTLY one of:
STATUS: NORMAL
STATUS: MEDIUM
STATUS: RISK

If MEDIUM or RISK, write:
ANOMALY: TAILGATING
or ANOMALY: LOITERING
or ANOMALY: AGGRESSION
or ANOMALY: SUSPICIOUS
""",
    "simple": """Security camera at a building entrance.
Authorized people have green badges. Denied people have red badges.
Describe in 2 sentences. Then: STATUS: NORMAL or STATUS: MEDIUM or STATUS: RISK
""",
    "llava": """<image>
Building entrance security camera. Green=authorized, Red=denied/blocked.
Describe in 2 sentences. Then write:
STATUS: NORMAL or STATUS: MEDIUM or STATUS: RISK
If not NORMAL, write ANOMALY: TAILGATING or LOITERING or AGGRESSION or SUSPICIOUS
""",
}

# SCENARIOS tested for each model
SCENARIOS = {
    "authorized":   ("Normal entry",        "normal"),
    "denied":       ("Blocked person",      "risk"),
    "tailgating":   ("Tailgating",          "risk"),
    "loitering":    ("Loitering",           "medium"),
    "aggression":   ("Aggressive behavior", "risk"),
}

def make_frame(scenario):
    w,h=640,480
    bg={"authorized":(40,58,40),"denied":(72,28,28),"tailgating":(58,52,30),
        "loitering":(48,48,72),"aggression":(82,22,22)}.get(scenario,(40,58,40))
    img=Image.new("RGB",(w,h),bg)
    d=ImageDraw.Draw(img)
    d.rectangle([0,0,w,44],fill=(0,0,0))
    d.text((8,7),  f"ENTRANCE CAM   {datetime.now().strftime('%H:%M:%S')}",fill="white")
    d.text((8,26), f"SCENARIO: {scenario.upper()}",fill=(255,220,50))
    d.rectangle([0,h-72,w,h],fill=(55,44,36))
    d.line([(0,h-72),(w,h-72)],fill=(160,140,118),width=2)
    d.rectangle([268,58,382,h-72],fill=(25,25,32),outline=(175,155,125),width=3)
    d.text((285,65),"DOOR",fill=(195,175,90))

    def person(cx,cy,badge="green",arm_up=False):
        skin=(212,178,142)
        shirt=(78,92,165) if badge=="green" else (165,55,55)
        d.ellipse([cx-22,cy-62,cx+22,cy-12],fill=skin,outline="white")
        d.rectangle([cx-16,cy-12,cx+16,cy+80],fill=shirt,outline="white")
        if arm_up:
            d.line([(cx+16,cy+6),(cx+50,cy-28)],fill=skin,width=5)
            d.line([(cx-16,cy+6),(cx-42,cy+50)],fill=skin,width=4)
        else:
            d.line([(cx-16,cy+6),(cx-44,cy+52)],fill=skin,width=4)
            d.line([(cx+16,cy+6),(cx+44,cy+52)],fill=skin,width=4)
        d.rectangle([cx-19,cy+80,cx-5,cy+148],fill=(32,32,32))
        d.rectangle([cx+5,cy+80,cx+19,cy+148],fill=(32,32,32))
        bc=(0,205,80) if badge=="green" else (215,38,38)
        d.rectangle([cx-11,cy+4,cx+11,cy+26],fill=bc,outline="white")
        d.text((cx-8,cy+8),"ID",fill="white")

    if scenario=="authorized": person(322,182,"green")
    elif scenario=="denied":   person(322,182,"red")
    elif scenario=="tailgating": person(292,175,"green"); person(362,198,"red")
    elif scenario=="loitering":  person(155,195,"red")
    elif scenario=="aggression": person(248,178,"green"); person(392,178,"red",arm_up=True)
    d.text((5,463),"Synthetic frame",fill=(115,115,115))
    return img

def encode(img):
    buf=BytesIO(); img.save(buf,format="JPEG",quality=85)
    return base64.b64encode(buf.getvalue()).decode()

def parse(text):
    status,anomaly="normal",None
    t=text.upper()
    if "STATUS: RISK" in t: status="risk"
    elif "STATUS: MEDIUM" in t: status="medium"
    for line in text.splitlines():
        if line.upper().strip().startswith("ANOMALY:"):
            anomaly=line.split(":",1)[1].strip()
    return {"status":status,"anomaly":anomaly}

def check_installed(tag):
    try:
        models=ollama.list()
        names=[m.get("name","") for m in models.get("models",[])]
        base=tag.split(":")[0]
        return any(base in n for n in names)
    except: return False

def test_model(key, img_path=None):
    cfg    = MODELS[key]
    tag    = cfg["tag"]
    prompt = PROMPTS[cfg["prompt"]]
    result = {"model":tag,"available":False,"scenarios":{},"avg_time":None}

    print(f"\n{B}{'─'*62}")
    print(f"  🤖 {BOLD}{tag}{RESET}{B}  ({cfg['params']} | {cfg['vram_gb']}GB VRAM)")
    print(f"{'─'*62}{RESET}")

    if not check_installed(tag):
        print(f"  {Y}⚠️  Not installed. Install: {cfg['pull']}{RESET}")
        print(f"  {DIM}Devices: {', '.join(cfg['devices'])}{RESET}")
        return result
    result["available"]=True

    times=[]
    for scenario,(label,expected_status) in SCENARIOS.items():
        img = Image.open(img_path) if img_path else make_frame(scenario)
        start=time.time()
        try:
            resp=ollama.generate(model=tag,prompt=prompt,images=[encode(img)])
            text=resp.get("response","").strip()
        except Exception as e:
            text=f"ERROR: {e}"
        elapsed=time.time()-start
        times.append(elapsed)

        p=parse(text)
        if expected_status=="normal":
            passed=(p["status"]=="normal")
        else:
            passed=(p["status"] in ("medium","risk"))

        result["scenarios"][scenario]={
            "passed":passed,"elapsed":elapsed,
            "status":p["status"],"anomaly":p["anomaly"],"response":text[:180]
        }
        icon="✅" if passed else "❌"
        color=G if passed else R
        print(f"  {color}{icon}{RESET} {label:<28} {elapsed:5.1f}s  "
              f"Expected:{expected_status.upper():<8} Got:{p['status'].upper()}")
        if p["anomaly"]: print(f"       ANOMALY: {p['anomaly']}")

    result["avg_time"]=sum(times)/len(times) if times else 0
    passed_count=sum(1 for s in result["scenarios"].values() if s["passed"])
    print(f"\n  Score: {passed_count}/{len(SCENARIOS)} | Avg: {result['avg_time']:.1f}s/frame")
    return result

def print_summary(all_results):
    print(f"\n\n{B}{'═'*72}")
    print(f"  📊 FACE SECURITY — MODEL COMPARISON")
    print(f"{'═'*72}{RESET}\n")
    print(f"  {'Model':<22} {'Params':<8} {'VRAM':<8} {'Score':<10} {'Avg Time':<12} {'Speed'}")
    print(f"  {'─'*22} {'─'*8} {'─'*8} {'─'*10} {'─'*12} {'─'*10}")

    best_model=None
    for key,cfg in MODELS.items():
        res=next((r for r in all_results if cfg["tag"] in r["model"]),None)
        if not res or not res["available"]:
            print(f"  {DIM}{cfg['tag']:<22} {cfg['params']:<8} {cfg['vram_gb']:<7}GB NOT INSTALLED{RESET}")
            continue
        sc      = res["scenarios"]
        passed  = sum(1 for s in sc.values() if s["passed"])
        total   = len(sc)
        avg_t   = res["avg_time"]
        score   = f"{passed}/{total}"
        n       = max(8,int(30*avg_t))
        print(f"  {BOLD}{cfg['tag']:<22}{RESET} {cfg['params']:<8} {cfg['vram_gb']:<7}GB {score:<10} {avg_t:.1f}s/frame    {cfg['speed']}")
        print(f"  {' '*22} {DIM}{cfg['notes']}{RESET}")
        if best_model is None or passed > best_model["passed"]:
            best_model={"key":key,"tag":cfg["tag"],"avg_t":avg_t,"passed":passed,"n":n}

    print(f"\n{B}{'═'*72}")
    print(f"  🎯 DEVICE → MODEL RECOMMENDATION")
    print(f"{'═'*72}{RESET}")
    recs=[
        ("Jetson Orin Nano 4GB",    "moondream:latest",  "1.5GB VRAM — only option"),
        ("Jetson Orin Nano 8GB",    "qwen2.5vl:3b",      "BEST: badge+spatial reasoning"),
        ("Jetson AGX Orin 32GB",    "qwen2.5vl:7b",      "Full 7B model, same prompts"),
        ("Jetson AGX Orin 64GB",    "llava:13b",         "Best quality, detailed reports"),
        ("Workstation 8GB GPU",     "llava:7b",          "Desktop use, verbose reports"),
    ]
    for device,model,note in recs:
        print(f"  {device:<28} → {BOLD}{model:<22}{RESET} {DIM}# {note}{RESET}")

    if best_model:
        print(f"\n{B}{'═'*72}")
        print(f"  📋 PASTE INTO ai_cctv_face_security.py")
        print(f"{'═'*72}{RESET}")
        print(f"\n  {BOLD}# Best available model: {best_model['tag']}{RESET}")
        print(f"  OLLAMA_MODEL           = \"{best_model['tag']}\"")
        print(f"  ANOMALY_EVERY_N_FRAMES = {best_model['n']}   # ~1 AI check / {best_model['avg_t']:.0f}s")
        print(f"  LOITER_SECONDS         = 60")
        print(f"  STRIKE_LIMIT           = 3")
        print(f"  FACE_MATCH_THRESHOLD   = 0.50\n")

def print_guide():
    print(f"\n{B}{'═'*72}")
    print(f"  🛠  JETSON SETUP GUIDE")
    print(f"{'═'*72}{RESET}\n")
    steps=[
        ("1. Install Ollama",          "curl -fsSL https://ollama.com/install.sh | sh"),
        ("2. Start server",            "ollama serve &"),
        ("3. Pull model (Nano 8GB)",   "ollama pull qwen2.5vl:3b"),
        ("4. Pull model (Nano 4GB)",   "ollama pull moondream:latest"),
        ("5. Install Python packages", "pip3 install face_recognition opencv-python ollama pillow numpy websockets --break-system-packages"),
        ("6. Install face_recognition deps", "sudo apt install cmake libdlib-dev -y"),
        ("7. Monitor GPU",             "sudo pip3 install jetson-stats && jtop"),
        ("8. Run all tests",           "python3 run_face_sec_tests.py"),
        ("9. Start the system",        "python3 ai_cctv_face_security.py"),
    ]
    for name,cmd in steps:
        print(f"  {G}▶{RESET} {name}")
        print(f"    {BOLD}{cmd}{RESET}\n")

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--model", choices=list(MODELS.keys()))
    parser.add_argument("--image", type=str)
    parser.add_argument("--guide", action="store_true")
    args=parser.parse_args()

    print(f"\n{B}{'═'*72}")
    print(f"  🎥 FACE SECURITY SYSTEM — ALL MODELS TEST")
    print(f"  Building Entrance / Access Control Scenario")
    print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'═'*72}{RESET}")

    if args.guide:
        print_guide(); return

    try: ollama.list()
    except:
        print(f"\n{R}❌ Ollama not running! Start: ollama serve{RESET}")
        print_guide(); sys.exit(1)

    keys=([args.model] if args.model else list(MODELS.keys()))
    all_results=[test_model(k, args.image) for k in keys]
    print_summary(all_results)
    if not args.model: print_guide()

    # Save JSON report
    with open("face_sec_test_report.json","w") as f:
        json.dump({"timestamp":datetime.now().isoformat(),"results":all_results},f,indent=2)
    print(f"  {DIM}Report saved: face_sec_test_report.json{RESET}\n")

if __name__=="__main__":
    main()
