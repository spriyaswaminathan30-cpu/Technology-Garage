import os
from pymongo import MongoClient
from langchain_community.document_loaders.csv_loader import CSVLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import MongoDBAtlasVectorSearch
from langchain_openai import OpenAIEmbeddings
from dotenv import load_dotenv


# loading the environment variables
load_dotenv()

MONGO_URI = "mongodb+srv://tgdev:technology-1@cluster0.0pefygc.mongodb.net/"
MONGO_DBNAME = "TgAi"
MONGO_COLLECTION = "TgFormData1"
MONGO_vSEARCH = "vector_indexs"

OPENAI_API_KEY = "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"

# initialize MongoDB python client
client = MongoClient(MONGO_URI)
MONGODB_COLLECTION = client[MONGO_DBNAME][MONGO_COLLECTION]

# loading csv file which containing the foods receipes
# loading csv file which containing the foods recipes
loader = CSVLoader("C:\\Users\\Technology Garage\\OneDrive - Technology Garage\\Documents\\emb\\main.csv", encoding='utf-8')
data = loader.load()


# creating the text spillter into chunks
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150)
docs = text_splitter.split_documents(data)

# insert the documents in MongoDB Atlas with their embedding
vector_search = MongoDBAtlasVectorSearch.from_documents(
    documents=docs,
    embedding=OpenAIEmbeddings(disallowed_special=(), api_key=OPENAI_API_KEY),
    collection=MONGODB_COLLECTION,
    index_name=MONGO_vSEARCH,
)


# import os
# from pymongo import MongoClient
# from langchain_community.document_loaders.csv_loader import CSVLoader
# from langchain.text_splitter import RecursiveCharacterTextSplitter
# from langchain_community.vectorstores import MongoDBAtlasVectorSearch
# from dotenv import load_dotenv

# # Load environment variables
# load_dotenv()

# # Define MongoDB connection parameters
# MONGO_URI = "mongodb+srv://tgdev:technology-1@cluster0.0pefygc.mongodb.net/"
# MONGO_DBNAME = "TgAi"
# MONGO_COLLECTION = "test"
# MONGO_vSEARCH = "vector_indexs"

# # Define OpenAI API key
# OPENAI_API_KEY = "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"

# def initialize_embeddings():
#     try:
#         # Initialize MongoDB python client
#         client = MongoClient(MONGO_URI)

#         # Loading CSV file containing the food recipes
#         loader = CSVLoader("C:\\Users\\Technology Garage\\OneDrive - Technology Garage\\Documents\\emb\\main.csv", encoding='utf-8')
#         data = loader.load()

#         # Creating the text splitter into chunks
#         text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150)
#         docs = text_splitter.split_documents(data)

#         # Insert the documents in MongoDB Atlas with their embedding
#         vector_search = MongoDBAtlasVectorSearch.from_documents(
#             documents=docs,
#             embedding=TheCorrectClassOrFunction(api_key=OPENAI_API_KEY),
#             collection=client[MONGO_DBNAME][MONGO_COLLECTION],
#             index_name=MONGO_vSEARCH,
#         )

#         print("Embeddings initialized successfully.")

#     except Exception as e:
#         print("Error initializing embeddings:", e)

# # Call the method to initialize embeddings
# initialize_embeddings()
