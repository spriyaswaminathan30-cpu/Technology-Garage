from pymongo import MongoClient
from transformers import AutoTokenizer, AutoModel
import torch
from langchain.embeddings.openai import OpenAIEmbeddings

EMBEDDING_COLLECTION = "Embeddings"  # New collection for storing embeddings
EMBEDDING_FIELD_NAME = "text_embedding"
DATABASE = "GenTrichy"
COLLECTION = "User"
model_name = 'bert-base-uncased'


openai_api_key = "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" 
embed = OpenAIEmbeddings(
    model=model_name,
    openai_api_key=openai_api_key
)
ATLAS_URI = "mongodb+srv://trichy-ai:kIM50OoQ5zsSYy08@cluster0.0pefygc.mongodb.net/"

# Connect to MongoDB
client = MongoClient(ATLAS_URI)
db = client[DATABASE]
user_collection = db[COLLECTION]
embedding_collection = db[EMBEDDING_COLLECTION]  # Create or use an existing collection for embeddings

# Load tokenizer and model
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModel.from_pretrained(model_name)

# Function to embed text
def embed_text(text):
    tokens = tokenizer(text, return_tensors="pt")
    with torch.no_grad():
        output = model(**tokens)
    return output.last_hidden_state.mean(dim=1).squeeze().tolist()

documents = user_collection.find()

for doc in documents:
    # Extract the key-value pairs you want to embed
    key_value_pairs = [doc.get("name", ""), doc.get("address", ""), doc.get("specialization", "")]

    text_to_embed = " ".join(map(str, key_value_pairs))

    # Embed the text
    embedding_vector = embed_text(text_to_embed)

    # Create a new document for embeddings
    embedding_doc = {
        "user_id": doc["_id"],
        EMBEDDING_FIELD_NAME: embedding_vector
    }

    # Insert the document into the Embeddings collection
    embedding_collection.insert_many(embedding_doc)

    print(f"Embedding created for user_id: {doc['_id']}")

client.close()
