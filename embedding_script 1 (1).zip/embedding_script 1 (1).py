
import pymongo
from transformers import BertModel, BertTokenizer
import torch

# Connect to your MongoDB database
client = pymongo.MongoClient("mongodb+srv://trichy-ai:kIM50OoQ5zsSYy08@cluster0.0pefygc.mongodb.net/")
db = client["TrichyGen"]
collection = db["User"]

# Load pre-trained BERT model and tokenizer
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
bert_model = BertModel.from_pretrained('bert-base-uncased')

# Function to tokenize and embed text using BERT
def embed_text(text):
    tokens = tokenizer(text, return_tensors='pt', truncation=True, padding=True)
    outputs = bert_model(**tokens)
    embedding_vector = torch.mean(outputs.last_hidden_state, dim=1).squeeze().detach().numpy()
    return embedding_vector.tolist()

# Function to process each record in the MongoDB collection
def process_records():
    for record in collection.find():
        record_id = record["_id"]

         # Extract the fields you want to embed
        name = record.get("name", "")
        address = record.get("address", "")
        specialization = record.get("specialization", "")

        # Concatenate fields into a text string
        text_to_embed = f"{name} {address} {specialization}"

        # Tokenize and embed text
        embedding_vector = embed_text(text_to_embed)

        # Update the record in MongoDB with the embedding
        update_result = collection.update_one(
            {"_id": record_id},
            {"$set": {"embedding": embedding_vector}}
        )

        # Print the key-value pair "embedding": "vector value"
        print(f"Record {record_id} updated with embedding: {embedding_vector}")

if __name__ == "__main__":
    process_records()
