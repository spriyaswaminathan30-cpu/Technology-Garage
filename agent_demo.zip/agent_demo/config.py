from dotenv import load_dotenv
import os

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")

# OpenAI model configuration
MODEL_NAME = "gpt-3.5-turbo"
TEMPERATURE = 0.7
