from langchain.schema import HumanMessage
from workflow import create_workflow

async def main():
    # Create the workflow
    workflow = create_workflow()
    
    # Initialize the chat
    messages = [
        HumanMessage(content="New York")  # Example location
    ]
    
    # Run the workflow
    result = await workflow.ainvoke(messages)
    
    # Print the final result
    print(result[-1].content)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
