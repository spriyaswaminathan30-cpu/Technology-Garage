def write:
    donut=