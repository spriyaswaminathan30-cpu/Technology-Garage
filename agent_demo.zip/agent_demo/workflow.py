from typing import Dict, Annotated
from langgraph.graph import Graph
from agents.weather_agent import WeatherAgent
from agents.event_planner_agent import EventPlannerAgent

def create_workflow() -> Graph:
    weather_agent = WeatherAgent()
    event_planner = EventPlannerAgent()

    workflow = Graph()

    @workflow.node("get_weather")
    async def get_weather(messages: list[BaseMessage]) -> Dict:
        return await weather_agent.run(messages)

    @workflow.node("plan_event")
    async def plan_event(messages: list[BaseMessage]) -> Dict:
        return await event_planner.run(messages)

    # Define the workflow
    workflow.add_node("get_weather")
    workflow.add_node("plan_event")
    
    # Connect the nodes
    workflow.add_edge("get_weather", "plan_event")

    return workflow
