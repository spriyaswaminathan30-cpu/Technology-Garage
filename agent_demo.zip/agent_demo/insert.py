from pymongo import MongoClient

# ---- MongoDB Connection ----
client = MongoClient("mongodb+srv://tg-dev:technology-1@tg-com.nvn5wo5.mongodb.net/")   # <-- replace with your URI
db = client["Online_Session"]            # <-- your database name
collection = db["slots"]             # <-- your collection name

# ---- Documents to Insert ----
documents = [
    {
        "day": "Sunday",
        "slot": "7:30 PM - 8:15 PM",
        "students": []
    },
    {
        "day": "Sunday",
        "slot": "8:15 PM - 9:00 PM",
        "students": []
    }
]

# ---- Insert into MongoDB ----
result = collection.insert_many(documents)

print("Inserted IDs:", result.inserted_ids)
