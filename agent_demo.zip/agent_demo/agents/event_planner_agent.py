from typing import Dict
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import BaseMessage
from config import MODEL_NAME, TEMPERATURE

class EventPlannerAgent:
    def __init__(self):
        self.llm = ChatOpenAI(model_name=MODEL_NAME, temperature=TEMPERATURE)
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", "You are an event planner. Based on the weather information provided, suggest suitable activities and plans."),
            ("user", "{input}"),
            ("assistant", "Based on the weather data: {weather_data}")
        ])

    async def run(self, messages: list[BaseMessage]) -> Dict:
        weather_data = messages[-1]
        
        response = await self.llm.agenerate([
            self.prompt.format_messages(
                input=messages[-2].content,
                weather_data=weather_data
            )
        ])

        return {
            "messages": messages + [response.generations[0][0].message],
            "type": "event_plan"
        }
