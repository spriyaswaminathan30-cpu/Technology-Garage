from typing import Dict
import requests
from langchain.agents import AgentExecutor
from langchain.schema import BaseMessage
from langgraph.prebuilt import ToolInvocation
from config import WEATHER_API_KEY

class WeatherAgent:
    def __init__(self):
        self.api_key = WEATHER_API_KEY
        self.base_url = "http://api.weatherapi.com/v1"

    async def get_weather(self, location: str) -> Dict:
        endpoint = f"{self.base_url}/current.json"
        params = {
            "key": self.api_key,
            "q": location
        }
        response = requests.get(endpoint, params=params)
        return response.json()

    async def run(self, messages: list[BaseMessage]) -> Dict:
        # Extract location from the last message
        location = messages[-1].content
        weather_data = await self.get_weather(location)
        
        return {
            "messages": messages + [weather_data],
            "type": "weather_info"
        }
